package maybe_c.happy.api.module;

import org.jetbrains.annotations.NotNull;

/**
 * 一个可独立开关的功能模块。
 *
 * <p>FakeHappy 自己的每个 feature 都是一个模块，
 * 小游戏插件也可以把自己注册成模块，从而共享同一套开关、热重载和清理保证。
 *
 * <p><b>为什么要有这层</b>：旧版本所有 feature 在 {@code onEnable} 里手工 new、
 * 手工 registerEvents、手工在 {@code onDisable} 里逐个判空关掉，漏一个就是一次内存泄漏
 * 或者一次「reload 后监听器注册了两遍」。走 {@link ModuleContext} 注册的东西
 * 会在模块关闭时被框架整体回收，不需要每个模块自己记账。
 *
 * <h2>约定</h2>
 * <ul>
 *   <li>{@link #onEnable} 里<b>只</b>通过 ctx 注册监听器 / 任务 / 命令，不要直接调
 *       {@code Bukkit.getPluginManager().registerEvents}，否则框架收不回来。</li>
 *   <li>{@link #onEnable} 抛异常 = 该模块进 {@link ModuleState#FAILED}，
 *       其余模块不受影响。所以不要在里面吞异常来「保平安」，让它抛出来更好排查。</li>
 *   <li>{@link #onDisable} 必须幂等，且不能假设 {@link #onEnable} 跑完过。</li>
 *   <li>{@link #onReload} 默认实现是 disable + enable。只有热重载成本高（比如要重连
 *       数据库、要重建缓存）时才值得自己实现一个增量版本。</li>
 * </ul>
 */
public interface HappyModule {

    /**
     * 模块唯一 ID，小写短横线风格（如 {@code lobby-protect}）。
     * 同时是 config.yml 里该模块配置段的 key 和 {@code /fh module <id>} 的参数。
     */
    @NotNull String id();

    /**
     * 控制「这个模块要不要被加载」的配置路径，默认 {@code modules.<id>.enabled}。
     *
     * <p><b>刻意和模块自己的配置段分开。</b>「模块加不加载」和「功能生不生效」
     * 是两件事：很多老 feature 是无条件注册监听器、再在每个处理函数里判一次
     * 自己的 {@code enabled} 标志。如果这两者共用一个键，
     * 把功能关掉就会连带模块也不加载，其他依赖这个模块拿服务实例的模块就会一起挂掉。
     *
     * <p>所以：模块开关放 {@code modules.*} 下，功能开关沿用各自原来的键，
     * 由 {@link #enabledByDefault()} 去读。
     */
    default @NotNull String configKey() {
        return "modules." + id() + ".enabled";
    }

    /** 给 OP 看的中文名。默认回落到 {@link #id()}。 */
    default @NotNull String displayName() {
        return id();
    }

    /**
     * {@link #configKey()} 指向的键没配时的默认值。
     *
     * <p>迁移旧 feature 时，在这里读它原来那个开关（比如
     * {@code getConfig().getBoolean("ServerSpawn", true)}），
     * 这样运维不用改 config.yml 就能保持原有行为。
     */
    default boolean enabledByDefault() {
        return true;
    }

    /**
     * 依赖的其他模块 ID。列出的模块会先于本模块启用；其中任何一个是 FAILED / DISABLED，
     * 本模块也不会启用（会记一条 warning 说明原因，而不是静默跳过）。
     */
    default @NotNull String[] dependsOn() {
        return new String[0];
    }

    /**
     * 启用。所有需要清理的东西都从 {@code ctx} 走。
     *
     * @throws Exception 抛出即视为启用失败，模块进 FAILED，不影响别的模块
     */
    void onEnable(@NotNull ModuleContext ctx) throws Exception;

    /**
     * 关闭。ctx 注册过的监听器 / 任务 / 命令 / cleanup 回调会在本方法<b>返回之后</b>
     * 由框架统一回收，所以这里只处理框架管不到的东西（比如把玩家从游戏里踢出来、
     * 回滚地图、flush 缓存到数据库）。
     */
    default void onDisable() {
    }

    /**
     * 热重载。默认走「关掉再开一遍」，对绝大多数模块都是对的。
     *
     * @return true = 已自行处理；false = 交给框架做 disable + enable
     */
    default boolean onReload(@NotNull ModuleContext ctx) {
        return false;
    }
}
