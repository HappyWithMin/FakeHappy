package maybe_c.happy.api;

import org.bukkit.Bukkit;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/**
 * {@link HappyApi} 的静态取用点。
 *
 * <pre>{@code
 * // 硬依赖（plugin.yml: depend: [FakeHappy]）——一定拿得到
 * HappyApi api = Happy.api();
 *
 * // 软依赖（softdepend）——判空
 * HappyApi api = Happy.apiOrNull();
 * if (api != null) { ... }
 * }</pre>
 *
 * <p>内部走 Bukkit 的 ServicesManager，查到后缓存。FakeHappy 重载 / 卸载时会
 * 调用 {@link #invalidate()} 清缓存，所以不要把返回值长期存成字段 —— 每次用每次取，
 * 开销只是一次 volatile 读。
 */
public final class Happy {

    private static volatile HappyApi cached;

    private Happy() {}

    /**
     * @throws IllegalStateException FakeHappy 未加载或未启用。硬依赖场景下不会发生。
     */
    public static @NotNull HappyApi api() {
        HappyApi api = apiOrNull();
        if (api == null) {
            throw new IllegalStateException(
                    "FakeHappy 尚未启用。请在 plugin.yml 里加 depend: [FakeHappy]，"
                            + "或改用 Happy.apiOrNull() 做软依赖。");
        }
        return api;
    }

    /** 拿不到就返回 null，不抛异常。软依赖用这个。 */
    public static @Nullable HappyApi apiOrNull() {
        HappyApi local = cached;
        if (local != null) return local;
        // 双检锁没必要：重复查一次 ServicesManager 是幂等且便宜的
        local = Bukkit.getServicesManager().load(HappyApi.class);
        cached = local;
        return local;
    }

    /** 由 FakeHappy 在 enable / disable 时调用。第三方插件不要碰。 */
    public static void invalidate() {
        cached = null;
    }
}
