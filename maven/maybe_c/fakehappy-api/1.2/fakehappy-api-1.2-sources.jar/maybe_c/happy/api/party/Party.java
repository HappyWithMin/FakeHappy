package maybe_c.happy.api.party;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * 一支全服队伍的<b>快照</b> —— 《舰长服小游戏制作规范》术语定义：
 * 「跨子服存在的持久性队伍，由全服组队系统维护」。
 *
 * <p><b>是快照，不是活对象。</b>队伍状态的权威在跨服层上，因为舰长服是
 * 多 velocity 多节点：队友完全可能挂在另一个代理下的另一个子服上。
 * 拿到这个对象之后队伍可能已经变了，需要最新的就再查一次
 * {@link PartyService#partyOf}。
 *
 * @param id        队伍 ID
 * @param leader    队长
 * @param members   全部成员，<b>队长排第一</b>，其余按加入顺序
 * @param createdAt 创建时间（毫秒时间戳）
 * @param sessions  成员 → 本次上线的起始时间戳。队长转让按这个挑「在线时长最长」的
 */
public record Party(
        @NotNull UUID id,
        @NotNull UUID leader,
        @NotNull List<UUID> members,
        long createdAt,
        @NotNull Map<UUID, Long> sessions
) {

    public Party {
        members = List.copyOf(members);
        sessions = Map.copyOf(sessions);
    }

    public int size() {
        return members.size();
    }

    public boolean contains(@NotNull UUID id) {
        return members.contains(id);
    }

    public boolean isLeader(@NotNull UUID id) {
        return leader.equals(id);
    }

    /** 除队长以外的成员。 */
    public @NotNull List<UUID> followers() {
        return members.stream().filter(m -> !m.equals(leader)).toList();
    }

    /**
     * 按规范 5.4 挑下一任队长：<b>同队中在线时长最长的</b>。
     *
     * <p>「在线时长」取的是本次上线到现在的时长，所以 {@code sessions} 里
     * <b>时间戳最小</b>的那个人就是在线最久的。切子服不会重置它 ——
     * 玩家从大厅走到小游戏服，在他自己看来是一次连续的在线。
     *
     * @return 队伍只剩队长一人时返回 null（那时该解散而不是转让）
     */
    public @Nullable UUID nextLeader() {
        UUID best = null;
        long bestSince = Long.MAX_VALUE;
        for (UUID m : members) {
            if (m.equals(leader)) continue;
            long since = sessions.getOrDefault(m, Long.MAX_VALUE);
            if (since < bestSince) {
                bestSince = since;
                best = m;
            }
        }
        return best;
    }

    /** 空队伍（成员只剩零人）。用于判断是否该解散。 */
    public boolean isEmpty() {
        return members.isEmpty();
    }

    /** 按成员顺序建一个可变副本，实现层内部用。 */
    public @NotNull Map<UUID, Long> mutableSessions() {
        return new LinkedHashMap<>(sessions);
    }
}
