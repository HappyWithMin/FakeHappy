package maybe_c.happy.api.text;

/**
 * 解析一段文本时的信任级别。<b>这是插件的一条安全边界，不是样式选项。</b>
 *
 * <p>MiniMessage 的 {@code <click:run_command>} / {@code <hover:show_item>} 等标签
 * 能构造出「点一下就以点击者身份执行任意命令」的聊天内容。只要有一处把玩家可控的字符串
 * （聊天、告示牌、物品名、外部来源的昵称、队伍名、地图名……）按 SYSTEM 级别解析，
 * 就等于开了一个提权口子。所以：<b>凡是来源含玩家输入的，一律用 PLAYER 或 LITERAL。</b>
 */
public enum TextTrust {

    /**
     * 完全信任：配置文件、插件源码里的常量。
     * 允许全部 MiniMessage 标签，含 click / hover / insertion。
     */
    SYSTEM,

    /**
     * 半信任：玩家可控但希望保留配色的场景（自定义队名、房间名等）。
     * 走 MiniMessage 的 {@code NON_INTERACTABLE} 预设 —— 颜色、渐变、
     * sprite、shadow 都还在，但 click / hover / insertion / selector / nbt / score
     * 这些能带出副作用或泄露信息的标签会被剥掉。
     */
    PLAYER,

    /**
     * 不信任：聊天正文、玩家名、外部 API 返回的字符串。
     * 所有标签和颜色码都当普通字符显示，等价于 {@code Component.text(raw)}。
     */
    LITERAL
}
