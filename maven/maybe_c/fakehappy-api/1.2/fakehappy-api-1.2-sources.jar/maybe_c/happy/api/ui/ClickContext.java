package maybe_c.happy.api.ui;

import net.kyori.adventure.text.Component;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.ClickType;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;
import java.util.OptionalDouble;

/**
 * 一次菜单点击的上下文。箱子界面和 Dialog 共用这一个类型，
 * 所以同一个 {@link MenuButton} 的处理逻辑在两种呈现下都能跑。
 *
 * <p><b>线程</b>：永远在主线程回调。要做 IO 就自己丢异步，别在这里阻塞。
 *
 * <p><b>失效</b>：ctx 只在本次回调期间有效，不要存成字段。
 */
public interface ClickContext {

    @NotNull Player player();

    /** 触发本次点击的菜单。 */
    @NotNull Menu menu();

    /**
     * 点击类型。Dialog 没有左右键之分，恒为 {@link ClickType#LEFT}；
     * 想让逻辑在两种呈现下都成立，就不要依赖这个值。
     */
    @NotNull ClickType clickType();

    /** 箱子界面里的槽位；Dialog 下为 -1。 */
    int slot();

    // ------------------------------------------------ Dialog 输入控件取值
    // 箱子界面下这些方法一律返回空值，不抛异常。

    /** 取文本输入框的值。 */
    @NotNull Optional<String> text(@NotNull String inputKey);

    /** 取开关的值，取不到时返回 def。 */
    boolean bool(@NotNull String inputKey, boolean def);

    /** 取数字滑条的值。 */
    @NotNull OptionalDouble number(@NotNull String inputKey);

    /** 取单选框选中的 option id。 */
    @NotNull Optional<String> option(@NotNull String inputKey);

    // ------------------------------------------------ 导航

    /** 关掉当前菜单。 */
    void close();

    /**
     * 用最新数据重绘当前菜单（不关闭再开，所以不会闪）。
     *
     * <p><b>只重绘 {@link #player()} 那一份</b>，等价于 {@code menu().refreshFor(player())}。
     * 要让所有观看者都跟着变（倒计时、在线人数这类），显式写
     * {@code menu().refresh()} —— 见 {@link Menu#refreshFor(org.bukkit.entity.Player)}
     * 里关于「Dialog 没有关闭事件」的那一段。
     */
    void refresh();

    /**
     * 回到上一层菜单。框架给每个玩家维护一个导航栈，
     * 所以子菜单的「返回」按钮直接写 {@code ctx::back} 就行，不用自己记来路。
     *
     * <p>栈空时等价于 {@link #close()}。
     */
    void back();

    /** 打开另一个菜单，并把当前菜单压进导航栈（于是新菜单里的 back 能回来）。 */
    void open(@NotNull Menu next);

    /** 打开另一个菜单并<b>替换</b>栈顶（新菜单里的 back 会跳过当前这层）。 */
    void replace(@NotNull Menu next);

    // ------------------------------------------------ 反馈

    /** 发一条带统一前缀的提示。 */
    void tell(@NotNull Component message);

    /** 发一条带统一前缀的提示（走 SYSTEM 级解析）。 */
    void tell(@NotNull String rawMessage);

    /**
     * 播放统一音效。常用 id：click / success / deny。
     * 点击成功的音效框架已经自动放过了，这里只在需要覆盖时调。
     */
    void feedback(@NotNull String feedbackId);

    /**
     * 拒绝本次点击：播 deny 音效 + 发一条错误色提示，菜单保持打开。
     * 权限不足、条件不满足统一走这个，玩家体验才一致。
     */
    void deny(@Nullable String reason);
}
