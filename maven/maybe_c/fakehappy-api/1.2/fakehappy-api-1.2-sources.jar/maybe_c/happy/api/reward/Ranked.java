package maybe_c.happy.api.reward;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.UUID;

/**
 * 排行榜上的一行。
 *
 * @param rank  名次，从 1 起
 * @param uuid  玩家
 * @param name  查询时数据库里存的名字。玩家改名后没重新登录过就还是旧名字 ——
 *              展示时优先用 {@code Bukkit.getOfflinePlayer(uuid).getName()}，
 *              拿不到再回落到这个
 * @param value 排序依据（经验 / 积分）
 * @param level 对应的等级，省得展示层再算一次
 */
public record Ranked(int rank, @NotNull UUID uuid, @Nullable String name, long value, int level) {
}
