package maybe_c.happy.api.game;

/**
 * 一局小游戏的状态机。
 *
 * <p>全服所有小游戏共用这一套状态，这样大厅 UI、OP 场控面板、跨服排队
 * 才能用同一段代码理解「这局现在能不能进人」。自定义的细分阶段请放在
 * 你自己游戏的内部字段里，不要往这个枚举里加。
 *
 * <pre>
 *   IDLE ──→ WAITING ──→ STARTING ──→ RUNNING ──→ ENDING ──→ RESETTING ──┐
 *    ↑                                                                   │
 *    └───────────────────────────────────────────────────────────────────┘
 * </pre>
 */
public enum GameState {

    /** 空闲。没人、没在收人。大厅里显示为「未开放」。 */
    IDLE(false, false),

    /** 收人中。可以加入，人满或倒计时结束进入 STARTING。 */
    WAITING(true, false),

    /** 开局倒计时。<b>仍然可以加入</b>（很多小游戏允许最后几秒挤进来）。 */
    STARTING(true, false),

    /** 进行中。默认不能加入；允许中途加入的游戏自己覆写 {@code canJoin}。 */
    RUNNING(false, true),

    /** 结算中。放烟花、发奖励、显示 MVP。不能加入。 */
    ENDING(false, true),

    /** 重置中。回滚地图、清实体。不能加入，完成后回 IDLE 或 WAITING。 */
    RESETTING(false, false),

    /** 被 OP 关停或出错停用。要人工介入才能恢复。 */
    DISABLED(false, false);

    private final boolean joinable;
    private final boolean inProgress;

    GameState(boolean joinable, boolean inProgress) {
        this.joinable = joinable;
        this.inProgress = inProgress;
    }

    /** 这个状态下默认允许玩家加入吗。具体还要看 {@link MiniGame#canJoin}。 */
    public boolean joinable() {
        return joinable;
    }

    /**
     * 是不是「已经在打了」。
     * 可见性隔离、大厅保护豁免、禁止传送等判断都看这个，而不是逐个枚举状态。
     */
    public boolean inProgress() {
        return inProgress;
    }

    /** 是不是一个静止状态（不会自己往下走，要外部触发）。 */
    public boolean terminal() {
        return this == IDLE || this == DISABLED;
    }
}
