package maybe_c.happy.api.data;

import org.jetbrains.annotations.NotNull;

/**
 * 一局打完之后要往战绩上加的增量。
 *
 * <p><b>为什么是增量而不是「写入最终值」</b>：同一个玩家可能同时在两个子服上有
 * 数据要写（切服的瞬间），读-改-写会丢更新。增量走 SQL 的
 * {@code ON DUPLICATE KEY UPDATE col = col + ?}，由数据库保证原子性。
 *
 * <pre>{@code
 * api.data().stats().record(playerId, "miner",
 *         StatDelta.builder().play().win().score(1200).playtime(elapsedMs).build());
 * }</pre>
 */
public final class StatDelta {

    private final int plays;
    private final int wins;
    private final int losses;
    private final int kills;
    private final int deaths;
    private final long score;
    private final long playtimeMs;

    private StatDelta(Builder b) {
        this.plays = b.plays;
        this.wins = b.wins;
        this.losses = b.losses;
        this.kills = b.kills;
        this.deaths = b.deaths;
        this.score = b.score;
        this.playtimeMs = b.playtimeMs;
    }

    public static @NotNull Builder builder() {
        return new Builder();
    }

    public int plays() { return plays; }
    public int wins() { return wins; }
    public int losses() { return losses; }
    public int kills() { return kills; }
    public int deaths() { return deaths; }
    public long score() { return score; }
    public long playtimeMs() { return playtimeMs; }

    /** 全是 0 的增量没必要往数据库跑一趟。 */
    public boolean isEmpty() {
        return plays == 0 && wins == 0 && losses == 0 && kills == 0
                && deaths == 0 && score == 0 && playtimeMs == 0;
    }

    public static final class Builder {
        private int plays;
        private int wins;
        private int losses;
        private int kills;
        private int deaths;
        private long score;
        private long playtimeMs;

        /** 打了一局。 */
        public @NotNull Builder play() { this.plays++; return this; }

        public @NotNull Builder win() { this.wins++; return this; }

        public @NotNull Builder loss() { this.losses++; return this; }

        public @NotNull Builder kills(int n) { this.kills += n; return this; }

        public @NotNull Builder deaths(int n) { this.deaths += n; return this; }

        /** 加分。可以是负数。 */
        public @NotNull Builder score(long n) { this.score += n; return this; }

        public @NotNull Builder playtime(long ms) { this.playtimeMs += Math.max(0, ms); return this; }

        public @NotNull StatDelta build() { return new StatDelta(this); }
    }
}
