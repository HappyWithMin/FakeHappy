package maybe_c.happy.api.ui;

import net.kyori.adventure.text.Component;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.jetbrains.annotations.NotNull;

import java.util.function.Consumer;

/**
 * 一份定义，两种呈现。
 *
 * <p>{@link #open(Player)} 时按观看者的客户端版本决定画成 Dialog 还是箱子界面，
 * 所以同一个菜单，26.x 的玩家看到的是现代对话框，经 ViaVersion 进来的
 * 老客户端玩家看到的是箱子界面，两边点同一个按钮跑的是同一段回调。
 *
 * <p>适合「一排动作按钮」型的菜单：小游戏选择、场控面板、确认框。
 * <b>不适合</b>需要输入控件的场景（箱子界面画不出文本框），那种直接用
 * {@link DialogMenu} 并自己兜一条命令行路径。
 */
public interface AdaptiveMenu extends Menu {

    /** 这个玩家会看到哪种形态。 */
    @NotNull Form formFor(@NotNull Player player);

    enum Form {
        DIALOG,
        CHEST
    }

    interface Builder {

        /** 说明文字。Dialog 下画成 body，箱子界面下塞进标题栏下方的说明格。 */
        @NotNull Builder body(@NotNull String raw);

        /**
         * 每次打开重新求值的说明文字。见
         * {@link DialogMenu.Builder#body(java.util.function.Function)}。
         *
         * <p><b>只在 Dialog 形态下生效</b> —— 箱子形态没有正文区。
         * 所以凡是「正文里的信息不可或缺」的界面，别用 adaptive：
         * 要么用 {@link DialogMenu} 并自己兜一条命令路径，
         * 要么把信息挪到按钮的 label / tooltip 上（那两个箱子形态也画得出来）。
         */
        @NotNull Builder body(@NotNull java.util.function.Function<Player, Component> perViewer);

        /**
         * 追加一个按钮。<b>顺序即布局</b>：
         * Dialog 下按 {@link #columns(int)} 排列，
         * 箱子界面下从中间一行开始居中铺开。
         */
        @NotNull Builder button(@NotNull MenuButton button);

        /** Dialog 形态下的列数。默认 1。 */
        @NotNull Builder columns(int columns);

        /**
         * 箱子形态下的行数（1~6）。默认按按钮数量自动算，
         * 只有在想留白或者按钮特别多时才需要手动指定。
         */
        @NotNull Builder rows(int rows);

        /** 箱子形态下填充空槽用的物品。Dialog 形态忽略。 */
        @NotNull Builder filler(@NotNull ItemStack filler);

        /** 加一个「返回」按钮。两种形态下都会放在约定位置，样式全服统一。 */
        @NotNull Builder withBackButton();

        /** 加一个「关闭」按钮。 */
        @NotNull Builder withCloseButton();

        @NotNull Builder onClose(@NotNull Consumer<Player> onClose);

        @NotNull Builder title(@NotNull Component title);

        /** 有人在看时的自动刷新周期（tick）。0 = 不自动刷新。 */
        @NotNull Builder autoRefresh(int periodTicks);

        @NotNull AdaptiveMenu build();
    }
}
