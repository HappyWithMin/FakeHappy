package maybe_c.happy.api.net;

import maybe_c.happy.api.game.GameState;
import org.jetbrains.annotations.NotNull;

/**
 * 别的子服上一局小游戏的状态快照，用于跨节点排队和大厅展示
 * （「争夺战 · 二号服 · 8/16 · 收人中」）。
 *
 * <p>这是<b>快照</b>，不是活对象。它反映的是对方子服最后一次上报时的样子，
 * 默认上报周期是 2 秒，所以人数可能有几秒延迟 —— 拿它做展示没问题，
 * 拿它做「还有没有空位」的最终判定不行，最终判定要由目标子服在玩家真的连过去时再做一次。
 *
 * @param serverId     房间所在子服
 * @param gameId       小游戏 ID，对应 {@code GameDescriptor.id()}
 * @param roomId       同一子服上可能有多局，用它区分
 * @param state        状态
 * @param players      当前人数
 * @param maxPlayers   人数上限
 * @param updatedAt    上报时间（毫秒时间戳）
 */
public record RemoteGameRoom(
        @NotNull String serverId,
        @NotNull String gameId,
        @NotNull String roomId,
        @NotNull GameState state,
        int players,
        int maxPlayers,
        long updatedAt
) {

    /** 看起来还能进人吗。最终判定仍由目标子服做。 */
    public boolean joinable() {
        return state.joinable() && players < maxPlayers;
    }

    /** 还剩几个位置。 */
    public int freeSlots() {
        return Math.max(0, maxPlayers - players);
    }
}
