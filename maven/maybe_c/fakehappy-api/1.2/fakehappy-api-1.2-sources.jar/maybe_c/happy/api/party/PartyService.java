package maybe_c.happy.api.party;

import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;

/**
 * 全服组队系统 —— 《舰长服小游戏制作规范》第五章。
 *
 * <h2>为什么状态不在内存里</h2>
 * 舰长服是<b>多 velocity 多节点</b>。队长在大厅、队员在小游戏二号服、
 * 两人还挂在不同的代理下 —— 这是常态而不是边界情况。
 * 把队伍放在某一个代理或某一个子服的内存里，那两个人就互相看不见了。
 *
 * <p>所以跨服层是唯一权威，各子服本地只留缓存，靠消息失效。
 *
 * <h2>小游戏要做的三件事</h2>
 * <ol>
 *   <li>玩家进房间时查 {@link #partyOf} —— 他是不是带着队来的</li>
 *   <li>用 {@link PartyPlacement#plan} 算怎么编队，照结果执行</li>
 *   <li>别的都不用管：队长转让、跨服带人、掉线处理都是框架的事</li>
 * </ol>
 *
 * <h2>降级</h2>
 * 跨服层没配时 {@link #isAvailable()} 返回 false，所有查询返回空、
 * 所有操作返回 {@link PartyResult#UNAVAILABLE}。<b>不会抛异常</b> ——
 * 单机开发环境下游戏照常跑，只是没有跨服队伍。
 */
public interface PartyService {

    /** 组队系统可用吗（要跨服层）。false 时全部降级。 */
    boolean isAvailable();

    /** 一支队伍的人数上限。默认 4（规范 5.1 的四人队）。 */
    int maxSize();

    // ---------------------------------------------------------------- 查询

    /**
     * 这个玩家在哪支全服队伍里。
     *
     * <p><b>读本地缓存，是同步的、便宜的</b>，可以在事件处理里直接调。
     * 缓存由 pub/sub 保持新鲜；极端情况下可能落后一两百毫秒，
     * 对「他是不是带队来的」这个判断没有影响。
     */
    @NotNull Optional<Party> partyOf(@NotNull UUID playerId);

    default @NotNull Optional<Party> partyOf(@NotNull Player player) {
        return partyOf(player.getUniqueId());
    }

    /** 按队伍 ID 查。跨服消息里传的是 ID。 */
    @NotNull Optional<Party> byId(@NotNull UUID partyId);

    /** 这人是不是某支队的队长。 */
    boolean isLeader(@NotNull UUID playerId);

    // ---------------------------------------------------------------- 操作
    //
    // 都返回 Future：要写跨服层。回调在异步线程，碰 Bukkit 对象要自己切回主线程。
    // 结果里带的是给玩家看的原因，直接展示即可。

    /**
     * 建一支队，创建者是队长。已经在队里的话返回 {@link PartyResult#ALREADY_IN_PARTY}。
     *
     * <p>一般不用手动调 —— {@link #invite} 会在邀请者还没有队时自动建一支。
     */
    @NotNull CompletableFuture<PartyResult> create(@NotNull UUID leader);

    /**
     * 邀请。邀请者没有队时自动建一支并当队长。
     *
     * <p>邀请有有效期（默认 60 秒），过期后被邀请者 {@link #accept} 会拿到
     * {@link PartyResult#INVITE_EXPIRED}。
     */
    @NotNull CompletableFuture<PartyResult> invite(@NotNull UUID inviter, @NotNull UUID invitee);

    /** 接受邀请。 */
    @NotNull CompletableFuture<PartyResult> accept(@NotNull UUID invitee);

    /** 拒绝邀请。 */
    @NotNull CompletableFuture<PartyResult> deny(@NotNull UUID invitee);

    /**
     * 退出队伍。
     *
     * <p><b>队长退出会触发规范 5.4 的转让</b>：队长身份自动给同队中在线时长最长的人，
     * 队伍继续存在。只剩一个人时队伍解散。
     */
    @NotNull CompletableFuture<PartyResult> leave(@NotNull UUID member);

    /** 踢人。只有队长能踢。 */
    @NotNull CompletableFuture<PartyResult> kick(@NotNull UUID leader, @NotNull UUID target);

    /** 手动转让队长。 */
    @NotNull CompletableFuture<PartyResult> transfer(@NotNull UUID leader,
                                                     @NotNull UUID newLeader);

    /** 解散。只有队长能解散。 */
    @NotNull CompletableFuture<PartyResult> disband(@NotNull UUID leader);

    /**
     * 把全队带到某个子服（规范 5：「队员将跟随队长进行子服传送」）。
     *
     * <p>队长先过去，队员随后 —— 反过来的话队员会先到一个队长还没到的地方。
     * 实际的切服由代理侧执行。
     */
    @NotNull CompletableFuture<PartyResult> warp(@NotNull UUID leader,
                                                  @NotNull String targetServerId);

    // ---------------------------------------------------------------- 会话

    /**
     * 这个玩家本次上线的起始时间戳，用于规范 5.4 的「在线时长最长」判定。
     *
     * <p><b>切子服不会重置它</b> —— 玩家从大厅走到小游戏服，
     * 在他自己看来是一次连续的在线，凭这个丢掉队长身份说不过去。
     *
     * @return 不在线或查不到时是空
     */
    @NotNull Optional<Long> onlineSince(@NotNull UUID playerId);

    /**
     * 队伍里当前<b>全网在线</b>的成员。
     *
     * <p>判据是心跳还在有效期内，<b>不是本机 {@code Bukkit.getPlayer} 查得到</b>
     * —— 队友本来就多半在别的子服上，按本机在线判会把他们全算成离线，
     * 跨服带队排队时就只会给队长一个人留位置。
     *
     * <p>掉线的人几十秒内仍然算在队里：网络抖一下不该把人踢出队伍。
     * 另一面是新上线的成员最多晚一个心跳周期才被算进来。
     *
     * @return 按成员顺序（队长在最前）；队伍不存在或组队降级时是空表
     */
    @NotNull java.util.List<UUID> onlineMembers(@NotNull UUID partyId);

    /**
     * 队伍里当前在线的成员数。
     *
     * <p>「在线」的判据是心跳还在有效期内，所以掉线的人几十秒内仍然算在队里 ——
     * 这是有意的：网络抖一下不该把人踢出队伍。
     */
    int onlineCount(@NotNull UUID partyId);

    /** 邀请还在有效期内吗。UI 上「你有一份待处理的邀请」用它。 */
    @Nullable UUID pendingInviteFrom(@NotNull UUID invitee);
}
