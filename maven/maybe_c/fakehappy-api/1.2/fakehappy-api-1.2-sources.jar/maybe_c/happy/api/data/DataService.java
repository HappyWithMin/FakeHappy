package maybe_c.happy.api.data;

import maybe_c.happy.api.net.NetworkService;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.function.BiConsumer;

/**
 * 持久化层：战绩、跨服偏好、OP 操作审计。
 *
 * <h2>降级</h2>
 * 没配数据库时 {@link #isAvailable()} 返回 false，此时：
 * <ul>
 *   <li>读操作返回<b>已完成的空结果</b>（{@link GameStats#empty}、空列表、默认值）</li>
 *   <li>写操作静默丢弃</li>
 * </ul>
 * 和 {@code NetworkService} 一样，<b>调用方不需要为「有没有数据库」写两套代码</b>。
 * 单机开发环境下这套 API 全都能调，只是数据不落盘。
 *
 * <h2>线程</h2>
 * 所有方法都可以在主线程调用，内部走异步。<b>回调在异步线程</b>，
 * 要碰 Bukkit 对象请自己切回主线程。
 *
 * <h2>为什么写操作不返回 Future</h2>
 * 「这一局的战绩写没写进去」在业务上没有分支 —— 写失败了也不会把玩家的游戏退回去。
 * 返回 Future 只会诱导调用方去 {@code .join()}，那就在主线程上阻塞了。
 * 写失败会记日志，需要对账就去查 {@code fh_game_stats}。
 */
public interface DataService {

    /** 数据库连上了吗。false 时全部降级，见类注释。 */
    boolean isAvailable();

    // ---------------------------------------------------------------- 战绩

    /**
     * 往某个玩家某个游戏的战绩上累加。异步执行，不阻塞。
     *
     * <p>增量为空时直接返回，不会白跑一趟数据库。
     */
    void record(@NotNull UUID playerId, @NotNull String gameId, @NotNull StatDelta delta);

    /** 查一个玩家在某个游戏上的战绩。查不到时返回 {@link GameStats#empty}，不是 null。 */
    @NotNull CompletableFuture<GameStats> stats(@NotNull UUID playerId, @NotNull String gameId);

    /** 查一个玩家在所有游戏上的战绩，按 gameId 索引。 */
    @NotNull CompletableFuture<Map<String, GameStats>> allStats(@NotNull UUID playerId);

    /**
     * 排行榜。
     *
     * @param gameId 小游戏 ID
     * @param sortBy 按哪个字段排（降序）
     * @param limit  取前几名。上限 100，超了会被截断 —— 排行榜没人看第 200 名，
     *               而全表排序是要花钱的
     */
    @NotNull CompletableFuture<List<GameStats>> leaderboard(@NotNull String gameId,
                                                            @NotNull StatField sortBy,
                                                            int limit);

    /** 排行榜可以按哪些字段排。对应表上已经建好索引的列。 */
    enum StatField {
        SCORE,
        WINS,
        PLAYS,
        KILLS,
        PLAYTIME
    }

    /**
     * 记录一局对局历史。用于赛后回看和申诉核对。
     *
     * @param detailJson 各游戏自定义的明细，会存进 JSON 列。传 null 表示不存明细
     */
    void recordMatch(@NotNull String gameId, @NotNull String roomId,
                     long startedAt, long finishedAt, int playerCount,
                     @Nullable UUID winner, @Nullable String detailJson);

    // ---------------------------------------------------------------- 跨服偏好

    /**
     * 读玩家的跨服偏好。
     *
     * <p>先查缓存，没有再查数据库并回填。<b>玩家进服时框架已经预热过</b>，
     * 所以在线玩家的这个调用通常是内存命中。
     *
     * @param def 查不到时的默认值
     */
    @NotNull CompletableFuture<String> pref(@NotNull UUID playerId, @NotNull String key,
                                            @NotNull String def);

    /** 同步读法：只查本地缓存，缓存没有就返回默认值。事件处理里用这个，不要在事件里等 Future。 */
    @NotNull String prefCached(@NotNull UUID playerId, @NotNull String key, @NotNull String def);

    /** 写偏好。异步落库并更新缓存，并广播给其他子服让它们丢掉自己那份。 */
    void setPref(@NotNull UUID playerId, @NotNull String key, @NotNull String value);

    /**
     * 反查：谁的这项偏好等于这个值。
     *
     * <p>用在「这个外部账号是不是已经被别人绑走了」这类唯一性检查上。
     * <b>必须用它，不要用自己在内存里攒的反查表</b> —— 内存表只认识本子服在线的人，
     * 于是「那个人此刻在别的子服」时唯一性检查会静默放行，
     * 同一个外部账号被两个 MC 号绑走，而且两边都不报错。
     *
     * <p>走 {@code fh_player_pref} 上的 {@code idx_pref_key} 覆盖索引，不回表。
     *
     * <p>理论上同一个值可能挂在多个玩家名下（历史脏数据）。这里只返回
     * <b>最近更新的那一个</b>，因为调用方要的是「现在算谁的」。
     * 要把重复的都找出来请用 {@link #prefsByKey}。
     *
     * <h2>查询失败时 future 以异常完成</h2>
     * 这是本接口里<b>唯一</b>一个不把失败降级成空结果的读方法，因为它的调用场景是
     * 唯一性检查：把「数据库读不到」当成「没人占用」，等于在数据库抖动的那一瞬间
     * 放行一次重复绑定，而且事后完全看不出来。
     *
     * <p>所以 {@code Optional.empty()} 的含义被收窄成<b>确实没人设过这个值</b>；
     * 「不知道」走异常分支。不关心这个区分的调用方写
     * {@code .exceptionally(t -> Optional.empty())} 即可，但请先想清楚为什么不关心。
     *
     * <p>没有数据库时（{@link #isAvailable()} 为 false）返回的是正常完成的空值 ——
     * 那种环境下压根没有跨服这回事，不存在「别的子服上有人占了」的可能。
     *
     * @return 没人设过这个值时是 {@code Optional.empty()}
     */
    @NotNull CompletableFuture<Optional<UUID>> playerByPref(@NotNull String key,
                                                            @NotNull String value);

    /**
     * 某个偏好键的全网清单，给管理界面用。
     *
     * <p><b>这是管理路径，不要放在热路径上。</b>即使有索引，它也是一次范围扫描，
     * 结果集随全服玩家数增长。界面该做的是「翻页时按需取」，而不是开机拉一份全量缓存
     * 然后自己维护失效 —— 后者是在给一份本来就有权威来源的数据造第二份事实。
     *
     * <p>值为空串的行会被过滤掉：解绑写的是空串而不是删行（见 {@code setPref}），
     * 所以表里会留着「设过但现在没有」的行，它们不该出现在清单里。
     *
     * <p>和 {@link #playerByPref} 一样，<b>查询失败时 future 以异常完成</b>而不是
     * 降级成空 Map：一份空清单和「数据库读不到」在界面上长得一模一样，
     * 而看到它的人要做的事完全相反 —— 前者去查为什么没人用这个功能，后者去查数据库。
     * 没有数据库时（{@link #isAvailable()} 为 false）返回正常完成的空 Map。
     *
     * @param limit 最多取多少条，上限 500。超了会被截断 ——
     *              一屏装不下五百行，需要更多的那是导表不是界面
     * @return 玩家 → 该偏好的值，按最近更新排在前面
     */
    @NotNull CompletableFuture<Map<UUID, String>> prefsByKey(@NotNull String key, int limit);

    /**
     * 订阅「某个玩家的某项偏好在<b>任意</b>节点上被改过了」。
     *
     * <p>给自己缓存了偏好的拓展用：收到之后把你那份对应的缓存丢掉，
     * 下次要用时重新走 {@link #pref} 读一遍。
     *
     * <p><b>回调在异步线程上</b>，而且同一次改动<b>发起方自己也会收到</b> ——
     * 所以回调必须是幂等的「使某某失效」，不能是「切换某某状态」。
     *
     * <p>跨服层不可用时返回一个永远不触发的订阅，不会是 null，
     * 调用方不用为「这台机器接没接跨服」写两套代码。
     *
     * @param listener (玩家, 偏好键)
     * @return 记得在插件卸载时 {@code cancel()}
     */
    @NotNull NetworkService.Subscription onPrefChanged(@NotNull BiConsumer<UUID, String> listener);

    /** 便捷布尔读写。 */
    default boolean prefBool(@NotNull Player player, @NotNull String key, boolean def) {
        return Boolean.parseBoolean(prefCached(player.getUniqueId(), key, String.valueOf(def)));
    }

    default void setPrefBool(@NotNull Player player, @NotNull String key, boolean value) {
        setPref(player.getUniqueId(), key, String.valueOf(value));
    }

    // ---------------------------------------------------------------- 审计

    /**
     * 记一条 OP 操作审计。<b>凡是能改别人服务器状态的操作都要落这张表。</b>
     *
     * <p>框架自己在处理远程场控指令时会调用它，小游戏一般只在实现了自己的
     * 管理命令时才需要手动记。
     */
    void audit(@NotNull String operator, @Nullable UUID operatorId,
               @NotNull String targetServer, @NotNull String action,
               @Nullable String subject, @NotNull String result);
}
