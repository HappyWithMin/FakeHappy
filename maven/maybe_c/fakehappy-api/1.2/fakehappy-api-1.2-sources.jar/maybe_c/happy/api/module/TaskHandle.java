package maybe_c.happy.api.module;

/**
 * 一个可取消的调度任务句柄。
 *
 * <p>刻意不直接暴露 {@code BukkitTask}：将来要迁到 Paper 的 region scheduler
 * （或者 Folia）时，只需要换 core 侧的实现，下游代码不用动。
 */
public interface TaskHandle {

    /** 取消。可重复调用。 */
    void cancel();

    /** 是否已取消或已执行完（一次性任务）。 */
    boolean isCancelled();

    /** 一个已经取消掉的空句柄，用于「条件不满足所以没真的排任务」的返回值。 */
    TaskHandle CANCELLED = new TaskHandle() {
        @Override public void cancel() {}
        @Override public boolean isCancelled() { return true; }
    };
}
