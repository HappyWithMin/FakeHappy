package maybe_c.happy.api.module;

import maybe_c.happy.api.HappyApi;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.event.Listener;
import org.bukkit.plugin.Plugin;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.logging.Logger;

/**
 * 模块启用时拿到的上下文。<b>凡是从这里注册的东西，模块关闭时都会被自动回收。</b>
 *
 * <p>这是整个框架防泄漏的核心：模块不需要自己记「我注册过哪些监听器、开过哪些定时任务」，
 * 也就不会漏。手工调 {@code Bukkit.getPluginManager().registerEvents(...)}
 * 或 {@code Bukkit.getScheduler()} 的代码框架管不到，请不要那样写。
 *
 * <p><b>生命周期</b>：ctx 只在模块 ENABLED 期间有效。模块关闭后再调用上面的注册方法
 * 会抛 {@link IllegalStateException}，避免「异步回调迟到，往一个已经关掉的模块里塞监听器」。
 */
public interface ModuleContext {

    /** FakeHappy 插件实例。注册 recipe、发 plugin message 之类需要 Plugin 的地方用它。 */
    @NotNull Plugin plugin();

    /** 服务总入口。 */
    @NotNull HappyApi api();

    /** 带模块前缀的 logger，输出形如 {@code [FakeHappy] [lobby-protect] ...}。 */
    @NotNull Logger logger();

    /**
     * 本模块自己的配置。
     *
     * <p>查找顺序：
     * <ol>
     *   <li>{@code plugins/FakeHappy/modules/<module-id>.yml} 的根 —— 有这个文件就只认它。
     *       这份文件<b>只在本模块启用时才会生成</b>，所以用不上的模块不会在子服上留下文件</li>
     *   <li>否则 config.yml 的 {@code modules.<module-id>} 段（老版本的位置，升级期回落）</li>
     *   <li>都没有 → 空 section</li>
     * </ol>
     *
     * <p>永远不返回 null，所以可以直接
     * {@code ctx.config().getBoolean("foo", true)}。<b>不要长期存成字段</b> ——
     * 每次 {@code /fh reload} 之后要重新取，否则改了配置不生效。
     */
    @NotNull ConfigurationSection config();

    // ---------------------------------------------------------------- 注册

    /**
     * 注册事件监听器，模块关闭时自动 unregister。
     *
     * @return 传入的 listener 本身，方便 {@code var l = ctx.listen(new Foo());}
     */
    <T extends Listener> @NotNull T listen(@NotNull T listener);

    /** 主线程立即执行一次（如果当前已在主线程，实现可以选择直接跑）。 */
    @NotNull TaskHandle sync(@NotNull Runnable task);

    /** 主线程延迟执行，单位 tick。 */
    @NotNull TaskHandle syncLater(@NotNull Runnable task, long delayTicks);

    /** 主线程周期任务，单位 tick。 */
    @NotNull TaskHandle syncTimer(@NotNull Runnable task, long delayTicks, long periodTicks);

    /** 异步执行一次。不要在里面碰 Bukkit 对象。 */
    @NotNull TaskHandle async(@NotNull Runnable task);

    /** 异步周期任务。 */
    @NotNull TaskHandle asyncTimer(@NotNull Runnable task, long delayTicks, long periodTicks);

    /**
     * 登记一个自定义清理动作，模块关闭时按<b>注册的逆序</b>执行。
     * 用于框架接管不了的资源：连接池、packetevents 监听器、外部库回调等。
     *
     * <p>抛出的异常会被记录但不会中断其余清理。
     */
    void onCleanup(@NotNull Runnable cleanup);

    /**
     * 注册命令执行器。命令本身必须已经在 plugin.yml 里声明过。
     *
     * @param name plugin.yml 里的命令名（不带斜杠）
     * @param executor 同时实现 {@code CommandExecutor} 和（可选）{@code TabCompleter}
     * @return false = plugin.yml 里没这个命令，已记 warning
     */
    boolean command(@NotNull String name, @NotNull Object executor);

    // ---------------------------------------------------------------- 状态

    /** ctx 是否仍然有效（模块仍在 ENABLED）。异步回调里先判这个再注册。 */
    boolean isActive();

    /** 本模块的 ID。 */
    @NotNull String moduleId();

    /**
     * 取另一个已启用模块的实例。用于模块间协作。
     * 更推荐的做法还是走 {@link HappyApi} 上的公开服务，模块直接互相引用会把耦合做死。
     *
     * @return 不存在或未启用时返回 null
     */
    <T extends HappyModule> @Nullable T sibling(@NotNull String moduleId, @NotNull Class<T> type);
}
