package maybe_c.happy.api.party;

import maybe_c.happy.api.game.PartyMode;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;

/**
 * 「这支全服队伍进这个房间，该怎么编队」的判定结果 ——
 * 《舰长服小游戏制作规范》5.1 / 5.2 / 5.3。
 *
 * <h2>为什么这段逻辑必须由框架给</h2>
 * 三种编队形态的规则不难，但<b>每个游戏都要写一遍，而且必须一模一样</b>。
 * 各写各的结果就是：A 游戏 5 人队进 4 人队房间被整体拒绝，B 游戏拆成 4+1，
 * C 游戏默默塞了 4 个人把第 5 个扔了。玩家会觉得「这服的组队是坏的」，
 * 而这三种行为里只有一种符合规范。
 *
 * <p>所以判定写在这里，是个<b>纯函数</b>，游戏只要照结果执行。
 *
 * @param decision  怎么处理
 * @param teamIndex 整体编入哪一队（{@link Decision#TOGETHER} 时有效，
 *                  是传进来的 {@code freeSlotsPerTeam} 的下标）
 * @param reason    被拒绝时给玩家看的话。{@link Decision#DENIED} 时非 null
 */
public record PartyPlacement(
        @NotNull Decision decision,
        int teamIndex,
        @Nullable String reason
) {

    public enum Decision {
        /**
         * 整体编入同一队（5.1，以及 5.2 中队伍装得下的情况）。
         * 队伍下标见 {@link PartyPlacement#teamIndex()}。
         */
        TOGETHER,

        /**
         * 队员成为独立个体，各自选队（5.2 中队伍人数超过每队上限的情况）。
         * <b>全服队伍关系依然保留</b> —— 只是这一局里不在同一队。
         */
        INDEPENDENT,

        /**
         * 进不去这个房间（5.3）。必须把 {@link PartyPlacement#reason()}
         * 原样展示给玩家，并提供「解散全服队伍后单独加入」和「更换其它房间」两个选项。
         */
        DENIED
    }

    public boolean allowed() {
        return decision != Decision.DENIED;
    }

    /**
     * 按规范判定一支队伍该怎么进这个房间。
     *
     * <h3>规则</h3>
     * <ul>
     *   <li><b>SOLO</b>：没有队伍概念，各进各的 → {@code INDEPENDENT}</li>
     *   <li><b>DELIVER_ONLY</b>：游戏自己分队，框架不给意见 → {@code INDEPENDENT}</li>
     *   <li><b>4×n</b>（5.1）：找一支空位够的队整体编入；找不到就是这个房间满了</li>
     *   <li><b>m×n</b>（5.2）：队伍人数 ≤ 每队上限就整体编入，超了就各自选队</li>
     *   <li><b>m×2</b>（5.3）：两队空位都不够就<b>拒绝进入</b>并给明确提示</li>
     * </ul>
     *
     * @param partySize        全服队伍人数
     * @param mode             这个游戏的编队形态
     * @param teamCapacity     每队人数上限
     * @param freeSlotsPerTeam 每支队伍<b>当前</b>还剩几个空位，下标即队伍编号
     */
    public static @NotNull PartyPlacement plan(int partySize, @NotNull PartyMode mode,
                                               int teamCapacity, int @NotNull [] freeSlotsPerTeam) {
        if (partySize <= 0) {
            return new PartyPlacement(Decision.INDEPENDENT, -1, null);
        }
        if (!mode.autoAssign()) {
            // SOLO：单人游戏没有「队」，全服队伍关系保留但这一局各打各的。
            // DELIVER_ONLY：游戏声明了自己分队 —— 框架不给意见。它本来就不该调进来，
            // 但真调了也得有个明确答案，不能抛
            return new PartyPlacement(Decision.INDEPENDENT, -1, null);
        }

        // m×n 且队伍装不下：规范 5.2 明说此时队员成为独立个体自行选队，
        // 全服队伍关系保留。注意这条要在找空位<b>之前</b>判 ——
        // 5 个人的队进 4 人队的游戏，就算某队正好空着 5 个位置也不该整体塞进去
        if (mode == PartyMode.M_BY_N && partySize > teamCapacity) {
            return new PartyPlacement(Decision.INDEPENDENT, -1, null);
        }

        int best = bestFit(partySize, freeSlotsPerTeam);
        if (best >= 0) {
            return new PartyPlacement(Decision.TOGETHER, best, null);
        }

        // 没有一支队装得下
        if (mode == PartyMode.M_BY_2) {
            // 规范 5.3 给了示例文案，照抄 —— 提示要说清差在哪，
            // 只说「进不去」玩家不知道该拆队还是换房间
            return new PartyPlacement(Decision.DENIED, -1,
                    "当前房间队伍剩余空位不足，无法容纳你的组队人数（" + partySize + " 人）");
        }
        // 4×n / m×n：所有队都塞不下，那就是房间真的满了
        return new PartyPlacement(Decision.DENIED, -1,
                "这个房间已经没有能容纳你们 " + partySize + " 人的队伍了");
    }

    /**
     * 挑一支装得下的队。
     *
     * <p>优先<b>空位刚好够的</b>那支 —— 把大空位留给后面可能来的大队伍，
     * 一支 2 人队塞进 4 空位的队会让下一支 4 人队无处可去。
     *
     * @return 队伍下标；没有装得下的返回 -1
     */
    private static int bestFit(int partySize, int[] freeSlotsPerTeam) {
        int best = -1;
        int bestFree = Integer.MAX_VALUE;
        for (int i = 0; i < freeSlotsPerTeam.length; i++) {
            int free = freeSlotsPerTeam[i];
            if (free >= partySize && free < bestFree) {
                bestFree = free;
                best = i;
            }
        }
        return best;
    }

    /** 便捷重载：直接传队伍。 */
    public static @NotNull PartyPlacement plan(@NotNull Party party, @NotNull PartyMode mode,
                                               int teamCapacity, int @NotNull [] freeSlotsPerTeam) {
        return plan(party.size(), mode, teamCapacity, freeSlotsPerTeam);
    }

    /**
     * 被 {@link Decision#DENIED} 时，规范 5.3 要求提供的两个选项。
     * 做成常量是为了各游戏的提示文案一致。
     */
    public static @NotNull List<String> denyOptions() {
        return List.of("解散全服队伍后单独加入", "更换其它房间");
    }
}
