package maybe_c.happy.api.module;

/** 模块的生命周期状态。 */
public enum ModuleState {
    /** 已注册但还没启用（被配置关掉，或依赖不满足）。 */
    DISABLED,
    /** 正在 enable。此状态下不允许递归 enable。 */
    ENABLING,
    /** 正常运行中。 */
    ENABLED,
    /** 正在 disable。 */
    DISABLING,
    /** enable 抛异常，已被隔离。不会再被 reload 触发，除非手动 /fh module enable。 */
    FAILED
}
