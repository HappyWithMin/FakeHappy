package maybe_c.happy.api.game;

/**
 * 房间类型 —— 《舰长服小游戏制作规范》第六章。
 *
 * <p><b>这不是一个装饰性的标签</b>：「自定义房间不发放石粒币与经验」是
 * 规范 6.2 和 12.2.6 的硬性验收项，而判定它唯一的依据就是房间类型。
 * 房间没有类型 = 这条验收项无法通过。
 */
public enum RoomType {

    /**
     * 普通房间（6.1）。无特殊规则，开局条件由系统自动接管，
     * 正常结算并发放局外奖励。
     */
    NORMAL("普通", true),

    /**
     * 自定义房间（6.2）。房主手动开局，<b>不发放任何局外奖励</b>
     * （含石粒币与经验）。玩家自娱、赛前练习用。
     *
     * <p>这也是「与岷同乐」私人房走的类型。
     */
    CUSTOM("自定义", false),

    /**
     * 比赛房间（6.3）。房主手动开局，正常结算并发放局外奖励。
     * 创建应限制在具备相应权限的账号。
     */
    MATCH("比赛", true);

    private final String display;
    private final boolean rewards;

    RoomType(String display, boolean rewards) {
        this.display = display;
        this.rewards = rewards;
    }

    public String display() {
        return display;
    }

    /**
     * 这类房间发不发局外奖励（石粒币 + 经验）。
     *
     * <p>结算时<b>必须</b>查这个再决定发不发 —— 别自己 if 房间名判断。
     */
    public boolean grantsRewards() {
        return rewards;
    }

    /** 需要房主手动触发开局的类型（6.2 / 6.3）。 */
    public boolean manualStart() {
        return this != NORMAL;
    }
}
