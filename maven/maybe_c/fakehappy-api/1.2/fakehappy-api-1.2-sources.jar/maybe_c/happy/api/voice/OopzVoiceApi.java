package maybe_c.happy.api.voice;

import org.jetbrains.annotations.NotNull;

import java.util.Set;
import java.util.UUID;

/**
 * 小游戏自己托管语音分组的入口。注册在 Bukkit 的 {@code ServicesManager} 里。
 *
 * <h2>什么时候需要它</h2>
 * 默认情况下本拓展会自动分房（局内队伍 → 全服队伍 → 游戏），多数游戏什么都不用做。
 * 但有些游戏的分组口径框架推不出来 —— 比如「观战者按阵营分开、死了的人留在原队伍频道里、
 * 赛后所有人合并成一间」。这种游戏可以自己算出「这一拍谁该和谁在一起」，用这个接口交进来。
 *
 * <h2>怎么用</h2>
 * <pre>{@code
 * // 只依赖 fakehappy-api；plugin.yml 里 softdepend: [FakeHappyOopz]
 * RegisteredServiceProvider<OopzVoiceApi> rsp =
 *         getServer().getServicesManager().getRegistration(OopzVoiceApi.class);
 * OopzVoiceApi voice = rsp == null ? null : rsp.getProvider();   // 没装拓展就是 null
 *
 * // 自己的对账循环里，每拍声明一次当前意图
 * if (voice != null && voice.available()) {
 *     voice.submitGroup("league:room7:red", "7 号房 红队", redTeamUuids);
 *     voice.submitGroup("league:room7:blue", "7 号房 蓝队", blueTeamUuids);
 * }
 * // 散场
 * voice.releaseGroup("league:room7:red");
 * }</pre>
 *
 * <h2>声明式，不是命令式</h2>
 * {@link #submitGroup} 说的是「这一拍这个分组该有这些人」，不是「把这些人拖过去」。
 * 同一个 key 反复提交只会更新成员，不会重复建频道；成员里少了一个人，那个人下一拍就被送回大厅。
 * 所以<b>安全的写法是定时全量提交</b>，而不是在每个「玩家加入队伍」事件里调一次 ——
 * 后者漏一个事件就会留下一个错位的人，而且永远自己好不了。
 *
 * <h2>和自动分房的关系</h2>
 * 被你点名的人，自动分房那一轮就不碰了，所以两套不会打架，
 * 也<b>不需要</b>再去 descriptor 里声明 {@code voiceManaged(false)}
 * （声明了也没坏处，那是给「语音压根不走 Oopz」的游戏用的）。
 *
 * <h2>拿不到 / 用不了的时候</h2>
 * 拓展没装 → {@code getRegistration} 返回 null。装了但 Oopz 连不上、或者运维没配频道池
 * 又没开自动建频道 → {@link #available()} 是 false，这时候提交不会报错，只是什么都不会发生。
 * <b>两种情况你的游戏都得照常能跑</b> —— 语音是加分项，不能变成故障点。
 */
public interface OopzVoiceApi {

    /**
     * 现在提交分组有没有意义。
     *
     * <p>false 的原因可能是：Oopz 还没登录上 / 域没配好 / 运维一个语音频道都没放进池子
     * 又没开 {@code voice.auto-create}。这时候提交是安全的空操作。
     */
    boolean available();

    /**
     * 托管一个分组：<b>这一拍</b>这些人该在同一个语音频道里。
     *
     * <p>同一个 key 反复调只更新成员，不会重复建频道。成员里不在线的人会被忽略；
     * 没绑定 Oopz 账号的人拖不动（接口只能拖「已经在语音里的人」），
     * 拓展会隔一分钟提示他一次。
     *
     * <p>可以从任意线程调。
     *
     * @param key     稳定的分组标识，建议 {@code "<插件>:<房间>:<队伍>"}。
     *                拓展内部会再加一层前缀，所以不会和自动分房的分组撞车
     * @param label   频道显示名，<b>原样</b>用（不套配置里的 {@code name-format}）
     * @param members 这一拍该在这个频道里的人
     */
    void submitGroup(@NotNull String key, @NotNull String label, @NotNull Set<UUID> members);

    /**
     * 解散一个分组：频道还回池子，里面的人送回大厅频道。
     *
     * <p>忘了调也不会永远漏 —— 一个分组里的人全下线超过 5 分钟后会被自动收掉。
     * 但那是兜底，不是可以不调的理由：散场到超时之间那几分钟，频道一直占着。
     *
     * @return 本来就没有这个分组时返回 false
     */
    boolean releaseGroup(@NotNull String key);

    /**
     * 这个人绑没绑 Oopz 账号。
     *
     * <p>没绑的人分组分不动 —— 拿他做「语音里怎么怎么样」的判断之前先问这个。
     */
    boolean isBound(@NotNull UUID playerId);
}
