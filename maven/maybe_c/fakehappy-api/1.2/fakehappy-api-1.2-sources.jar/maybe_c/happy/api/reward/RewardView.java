package maybe_c.happy.api.reward;

import org.jetbrains.annotations.NotNull;

/**
 * 一档升级奖励在<b>某个玩家眼里</b>的样子。取出来那一刻的快照，不会自己更新。
 *
 * <p>给领取界面和「列出我的奖励」这类展示用。真正的档位定义在 core 里
 * （{@code RewardDef}，权威在服务端），这个 record 是它的公开投影 ——
 * 小游戏插件要画自己的界面，只拿得到这一份。
 *
 * @param key        记账键，也是 {@link RewardService#claimOne} 的参数
 * @param pointsSide 这一档属于<b>积分那条曲线</b>还是等级那条。
 *                   <b>必须带着走，不能靠 key 反查</b> —— 两条曲线共用一个 key 空间，
 *                   撞名时按 key 查永远命中等级那条，积分那一档点了没反应而且不报错
 * @param level      解锁需要几级（是哪条曲线的级，看 {@code pointsSide}）
 * @param currency   附带多少货币，0 表示不给
 * @param announce   领取时发给玩家的那行字（MiniMessage）。空表示不发
 * @param display    格子上的显示名。空时调用方自己回落成「奖励 Lv.N」
 * @param icon       图标的 Material 名。api 模块不 import Bukkit 的类型，
 *                   由展示端自己 {@code Material.matchMaterial}，解析不出来回落 CHEST
 * @param state      这个玩家当前处在哪一态
 */
public record RewardView(@NotNull String key,
                         boolean pointsSide,
                         int level,
                         double currency,
                         @NotNull String announce,
                         @NotNull String display,
                         @NotNull String icon,
                         @NotNull State state) {

    /** 一档奖励对某个玩家的三种状态。 */
    public enum State {
        /** 已经领过了。 */
        CLAIMED,
        /** 等级够了、还没领。 */
        CLAIMABLE,
        /** 等级还不够。 */
        LOCKED
    }

    public boolean claimable() {
        return state == State.CLAIMABLE;
    }

    /** 显示名，没配就回落成「奖励 Lv.10」这种。 */
    public @NotNull String displayOr() {
        return display.isBlank() ? "奖励 Lv." + level : display;
    }
}
