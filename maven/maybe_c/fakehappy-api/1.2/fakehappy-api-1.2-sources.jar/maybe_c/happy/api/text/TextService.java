package maybe_c.happy.api.text;

import net.kyori.adventure.audience.Audience;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.tag.resolver.TagResolver;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.Map;

/**
 * 全服唯一的文本管线。
 *
 * <h2>一段文本里可以同时混写四种语法</h2>
 * <ol>
 *   <li>MiniMessage 标签：{@code <red>} {@code <gradient:#ff0000:#0000ff>} {@code <bold>}</li>
 *   <li>旧版 &amp; 颜色 / 格式码：{@code &a} {@code &l} {@code &r}（以及 § 码）</li>
 *   <li>旧版十六进制：{@code &#2ecc71}</li>
 *   <li>高版本特性：{@code <sprite:gui:hud/heart/full>} 内联贴图、
 *       {@code <shadow:#20000080>} 文字投影</li>
 * </ol>
 *
 * 实现会先把 2、3 归一化成 MiniMessage 标签，再交给 MiniMessage 一次性解析，所以
 * {@code &c<bold>血量 <sprite:gui:hud/heart/full> <shadow:#20000080>10</shadow>}
 * 这种混写是合法的。
 *
 * <h2>sprite / shadow 的坑（下面每条都在 Adventure 5.2.0 上实测过）</h2>
 * <ul>
 *   <li><b>sprite 必须带图集名。</b>省略图集时默认图集是 {@code minecraft:blocks}，
 *       而 GUI 贴图在 {@code minecraft:gui} 图集里。所以
 *       {@code <sprite:hud/heart/full>} 查不到东西，正确写法是
 *       {@code <sprite:gui:hud/heart/full>}。</li>
 *   <li><b>不要写 {@code <sprite:minecraft:gui:hud/heart/full>}。</b>
 *       MiniMessage 按冒号切参数，这么写会被切成
 *       atlas={@code minecraft:minecraft}、sprite={@code minecraft:gui} ——
 *       <b>不报错，静默出错</b>。真要写全限定名就加引号：
 *       {@code <sprite:'minecraft:gui':'minecraft:hud/heart/full'>}。</li>
 *   <li>sprite key = 客户端贴图路径去掉 {@code textures/gui/sprites/} 前缀和
 *       {@code .png} 后缀。例：
 *       {@code assets/minecraft/textures/gui/sprites/hud/heart/full.png}
 *       → {@code <sprite:gui:hud/heart/full>}。</li>
 *   <li>{@code <shadow:...>} 接受 {@code #RGB}、{@code #RRGGBB}、{@code #RRGGBBAA}、
 *       颜色名、{@code 颜色名:alpha} 五种写法。</li>
 *   <li><b>关掉投影用 {@code <!shadow>}，不是 {@code <shadow:none>}。</b>
 *       {@code none} 不是合法颜色，标签解析不了，会原样当普通文字显示出来。</li>
 *   <li>sprite 要客户端 1.21.9+，shadow 要 1.21.6+。经 ViaVersion 进来的低版本客户端
 *       看到的是降级结果，所以关键信息不要只放在 sprite 里。</li>
 * </ul>
 *
 * <h2>安全</h2>
 * 含玩家可控内容的字符串必须显式传 {@link TextTrust#PLAYER} 或
 * {@link TextTrust#LITERAL}。不带 trust 参数的重载一律按 {@link TextTrust#SYSTEM} 处理，
 * 只用于插件自己的配置和代码常量。理由见 {@link TextTrust}。
 *
 * <p><b>不要自己 new 一个 {@code MiniMessage.miniMessage(Preset.NON_INTERACTABLE)}
 * 就当它安全。</b>实测该预设只挡 click / hover / insert，
 * {@code <selector>}、{@code <score>}、{@code <nbt>} 三个标签照样生效 ——
 * 其中 {@code <nbt>} 能把任意方块 / 实体的 NBT 读进聊天。本服的
 * {@link TextTrust#PLAYER} 走的是显式白名单而不是那个预设，所以请统一走本接口，
 * 不要在自己的小游戏里另起炉灶。
 */
public interface TextService {

    // ------------------------------------------------------------ 解析

    /** 按 {@link TextTrust#SYSTEM} 解析。只用于配置文件 / 代码常量。 */
    @NotNull Component parse(@Nullable String raw);

    /** 按指定信任级别解析。 */
    @NotNull Component parse(@Nullable String raw, @NotNull TextTrust trust);

    /**
     * 解析并注入占位符。占位符在模板里写成 MiniMessage 的 {@code <key>} 形式。
     *
     * <p>值一律按 {@link TextTrust#LITERAL} 插入 —— 就算模板本身是 SYSTEM 级，
     * 玩家名里的 {@code <click:...>} 也不会被当标签解析。这是有意为之，别绕过它。
     */
    @NotNull Component parse(@Nullable String raw, @NotNull TextTrust trust,
                             @NotNull Map<String, String> placeholders);

    /** 需要自定义 TagResolver（比如小游戏自己的 {@code <team_name>}）时用这个。 */
    @NotNull Component parse(@Nullable String raw, @NotNull TextTrust trust,
                             @NotNull TagResolver... resolvers);

    /** 解析一整个列表（lore、多行说明）。null 元素跳过，不会变成空行。 */
    @NotNull List<Component> parseAll(@Nullable List<String> raw, @NotNull TextTrust trust);

    // ------------------------------------------------------------ 反向

    /** 去掉所有颜色 / 标签，得到纯文本。用于日志、长度校验、敏感词匹配。 */
    @NotNull String plain(@Nullable String raw);

    /** 把 Component 转成纯文本。 */
    @NotNull String plain(@Nullable Component component);

    /**
     * 转义一段字符串里的 MiniMessage 标签和 &amp; 码，让它作为字面量安全地嵌进模板。
     * 自己手拼模板时用；走
     * {@link #parse(String, TextTrust, Map)} 的话框架已经替你转义过了。
     */
    @NotNull String escape(@Nullable String raw);

    /**
     * 估算一段文本在默认字体下的<b>像素宽度</b>（不含阴影）。
     * 做 TAB / 计分板 / HUD 对齐时用。sprite 和自定义字体字符按 服务端的样式配置 里登记的宽度算，
     * 没登记的按默认字宽估算 —— 是估算，不是精确值。
     */
    int pixelWidth(@Nullable Component component);

    // ------------------------------------------------------------ 发送

    /** 按 SYSTEM 解析后发送，不加前缀。 */
    void send(@NotNull Audience to, @Nullable String raw);

    /** 加统一前缀后发送。系统提示统一走这个，玩家看到的前缀才会全服一致。 */
    void sendPrefixed(@NotNull Audience to, @Nullable String raw);

    void sendPrefixed(@NotNull Audience to, @NotNull Component body);

    // ------------------------------------------------------------ 语义化反馈
    //
    // 全服所有「成功 / 失败 / 警告」的反馈都走这四个，不要自己拼 §a §c。
    // 这样图标、颜色、前缀、语气是一套的，玩家换个小游戏也认得出是同一个服。
    //
    // 文案写法（这是硬要求，不是建议）：
    //   · 主语开头，别写「标签：值」—— 「Steve 不在线」，不是「玩家不在线：Steve」
    //   · 不要句号。一行反馈不是一句话，是一个状态
    //   · 不解释「为什么」和「怎么办」。那些放 hover 或另起一行 muted，别塞进主句
    //   · 能省的字都省掉 —— 「已重置你的隐藏状态为"显示"」→「已显示全部玩家」

    /** ✔ 成功。 */
    void ok(@NotNull Audience to, @Nullable String raw);

    /** ⚠ 需要注意，但事情办成了 / 还能继续。 */
    void warn(@NotNull Audience to, @Nullable String raw);

    /** ✖ 失败、拒绝、条件不满足。 */
    void error(@NotNull Audience to, @Nullable String raw);

    /** » 中性信息，不表示成败。 */
    void info(@NotNull Audience to, @Nullable String raw);

    /** 上面四个的 Component 版，给菜单 lore / 计分板 / 拼接场景用。 */
    @NotNull Component okLine(@Nullable String raw);

    @NotNull Component warnLine(@Nullable String raw);

    @NotNull Component errorLine(@Nullable String raw);

    @NotNull Component infoLine(@Nullable String raw);

    /**
     * 渐变标题行，给 {@code /xx help}、面板抬头、分段标题用。
     *
     * <p>比手写分隔线好在：全服的标题长得一样，而且改 服务端的样式配置 就能一次性换掉。
     */
    @NotNull Component heading(@Nullable String raw);

    /** 动作栏。 */
    void actionBar(@NotNull Audience to, @Nullable String raw);

    /**
     * 标题。时间单位是 tick。
     *
     * @param subtitle 可为 null
     */
    void title(@NotNull Audience to, @Nullable String title, @Nullable String subtitle,
               int fadeInTicks, int stayTicks, int fadeOutTicks);

    /**
     * 播放统一音效反馈。音效在 服务端的样式配置 里按语义登记
     * （{@code click} / {@code success} / {@code deny} / {@code countdown}），
     * 这样全服所有小游戏的「点错了」听起来是同一个声音。
     *
     * <p>未登记的 id 静默忽略，不抛异常 —— 音效缺失不该让一局游戏崩掉。
     */
    void feedback(@NotNull Player to, @NotNull String feedbackId);

    // ------------------------------------------------------------ 风格

    @NotNull TextStyle style();

    /**
     * 本服调色板对应的 MiniMessage 标签集：
     * {@code <brand>} {@code <accent>} {@code <body>} {@code <muted>}
     * {@code <ok>} {@code <warn>} {@code <error>}，以及 {@code <icon:xxx>}。
     *
     * <p>走 {@link #parse} 的话这些标签<b>本来就可用</b>，不需要自己取。
     * 这个方法是给<b>已经有自己一套文本管线的插件</b>用的 —— 比如惊天矿工团
     * 的 {@code Text} 支持 {@code &x&a&1&b&2&c&3} 这种本框架不处理的旧版十六进制，
     * 让它整个换掉不划算。把这个 resolver 挂到它自己的 MiniMessage 上，
     * 它就能在保留原有能力的同时用上本服配色。
     *
     * <pre>{@code
     * MiniMessage mm = MiniMessage.builder()
     *         .editTags(t -> t.resolver(api.text().styleTags()))
     *         .build();
     * }</pre>
     *
     * <p><b>不要缓存返回值</b>：服务端的样式配置 热重载后会换一个新的，
     * 缓存住的那个仍然指向旧配色。每次用每次取。
     *
     * <p>这些标签只能改颜色和插入预先登记过的图标，产生不了副作用，
     * 所以挂到处理玩家输入的管线上也是安全的。
     */
    @NotNull TagResolver styleTags();
}
