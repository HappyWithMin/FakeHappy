package maybe_c.happy.api.economy;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.math.BigDecimal;

/**
 * 一笔资金变动的结果。
 *
 * <p><b>永远不要只看 {@link #ok()} 就当成功。</b>上一代经济系统最贵的那个 bug
 * 就是这么来的：商店插件先给东西、再调扣款、<b>不看返回值</b>，
 * 于是数据库那边失败了它也照样说「已扣款」。
 *
 * @param status  结果类型
 * @param applied 实际变动了多少（正数为入账，负数为扣款）。失败时是 0
 * @param balance 这一笔之后的余额。失败时是当前余额，不是 0 ——
 *                调用方常拿它去刷界面，返回 0 会让玩家以为自己破产了
 * @param message 给人看的失败原因；成功时为 null
 */
public record TxnResult(@NotNull Status status,
                        @NotNull BigDecimal applied,
                        @NotNull BigDecimal balance,
                        @Nullable String message) {

    public enum Status {
        /** 成功。 */
        SUCCESS,
        /** 余额不够。<b>钱一分没动</b> —— 不存在「扣了一部分」这种中间状态。 */
        INSUFFICIENT,
        /** 金额非法（零、负数、或者精度化之后变成零）。 */
        BAD_AMOUNT,
        /** 后端不可用（数据库没连上）。<b>和「余额不足」必须分开</b>： */
        UNAVAILABLE
    }

    public boolean ok() {
        return status == Status.SUCCESS;
    }

    public static @NotNull TxnResult success(@NotNull BigDecimal applied, @NotNull BigDecimal balance) {
        return new TxnResult(Status.SUCCESS, applied, balance, null);
    }

    public static @NotNull TxnResult insufficient(@NotNull BigDecimal balance) {
        return new TxnResult(Status.INSUFFICIENT, BigDecimal.ZERO, balance, "余额不足");
    }

    public static @NotNull TxnResult badAmount(@NotNull BigDecimal balance) {
        return new TxnResult(Status.BAD_AMOUNT, BigDecimal.ZERO, balance, "金额必须大于 0");
    }

    public static @NotNull TxnResult unavailable() {
        return new TxnResult(Status.UNAVAILABLE, BigDecimal.ZERO, BigDecimal.ZERO, "经济后端不可用");
    }
}
