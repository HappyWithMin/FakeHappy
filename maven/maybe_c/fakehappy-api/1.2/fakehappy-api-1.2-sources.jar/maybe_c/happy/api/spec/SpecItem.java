package maybe_c.happy.api.spec;

import maybe_c.happy.api.game.GameDescriptor;
import org.jetbrains.annotations.NotNull;

import java.util.function.Predicate;

/**
 * 《舰长服小游戏制作规范》里的一条检查项。
 *
 * @param id        稳定 ID，报告和配置里用它引用。规范改版时 ID 不要变
 * @param chapter   出处章节，例如 {@code "6.2"}。开发者看到报告要能立刻翻到原文
 * @param level     强制程度
 * @param title     一句话说清「要做到什么」
 * @param how       没做到时该怎么做 —— 报告里最有用的就是这一栏
 * @param check     框架能不能自己验
 * @param appliesTo 这条对哪些游戏适用。见 {@link #appliesTo()}
 */
public record SpecItem(
        @NotNull String id,
        @NotNull String chapter,
        @NotNull Level level,
        @NotNull String title,
        @NotNull String how,
        @NotNull Check check,
        @NotNull Predicate<GameDescriptor> appliesTo
) {

    /** 对所有游戏都适用的检查项。 */
    public SpecItem(@NotNull String id, @NotNull String chapter, @NotNull Level level,
                    @NotNull String title, @NotNull String how, @NotNull Check check) {
        this(id, chapter, level, title, how, check, d -> true);
    }

    /**
     * 有些「必须」项是<b>有条件</b>的。
     *
     * <p>规范 5.3 那条「m×2 游戏中两队空位都不足时要给明确提示」，对一个 4×n 的游戏
     * 根本无从谈起 —— 它压根没有「两支队伍」。不做这个区分的话，
     * 每个游戏的报告里都会挂着几条它这辈子也满足不了的必须项，
     * 而报告一旦永远不可能全绿，就没人会认真看了。
     *
     * <p>判定依据只能是 {@link GameDescriptor} 里已声明的东西（编队形态、是否支持旁观
     * 之类），因为检查发生在注册那一刻，除此之外框架什么都还不知道。
     */
    @Override
    public @NotNull Predicate<GameDescriptor> appliesTo() {
        return appliesTo;
    }

    /** 强制程度。规范第一章定义的三档。 */
    public enum Level {
        /** 必须：强制要求，未达成不允许上线。 */
        MUST("必须"),
        /** 应当：强烈建议，无正当理由不得省略。 */
        SHOULD("应当"),
        /** 可选：视游戏具体需求决定。 */
        MAY("可选");

        private final String display;

        Level(String display) {
            this.display = display;
        }

        public String display() {
            return display;
        }
    }

    /**
     * 这条项框架能验到什么程度。
     *
     * <p><b>这个区分很重要，别让报告看起来比实际更可信。</b>
     * 框架能看到「你有没有覆写 pause()」，看不到「你的暂停有没有真的冻住实体」。
     * 把两者混在一起报「全部通过」，验收的人就会以为不用人工看了。
     */
    public enum Check {
        /**
         * 框架自己能验：反射看有没有实现、descriptor 字段填没填、房间有没有类型。
         * 这类项的结论是可信的。
         */
        AUTO("自动检测"),

        /**
         * 框架验不了，只能看开发者在 {@code GameCompliance} 里怎么声明。
         * 声明为「已实现」也<b>只代表他这么说</b>，仍然要人工验收。
         */
        DECLARED("需声明"),

        /**
         * 纯人工：美术原创度、文案有没有侵权、Tab 排版好不好看。
         * 框架只负责在清单里列出来提醒验收的人别漏。
         */
        MANUAL("人工验收"),

        /**
         * <b>框架已经做了，游戏什么都不用管。</b>这类项恒为通过。
         *
         * <h2>为什么留在清单里而不是删掉</h2>
         * 规范正文里有这些条，删掉的话验收的人翻到那一章会问「检查器怎么没有这项」，
         * 然后去翻代码找。留着并标明「框架负责」，一眼就知道不用管。
         *
         * <h2>为什么不能标成 DECLARED</h2>
         * 这是给<b>写代码的 AI</b> 准备的区分。DECLARED 的意思是「你做了就声明一下」，
         * AI 看到会老老实实去声明 —— 声明一件它没做、也不需要做的事。
         * 更糟的是它可能真的去实现一遍（比如自己写一套队长转让），
         * 和框架那套打架。
         *
         * <p>典型：队员跟随队长切服、队长退出后转让 —— 那是
         * {@code PartyService} 的职责，游戏一行代码都不用写。
         */
        FRAMEWORK("框架负责");

        private final String display;

        Check(String display) {
            this.display = display;
        }

        public String display() {
            return display;
        }
    }
}
