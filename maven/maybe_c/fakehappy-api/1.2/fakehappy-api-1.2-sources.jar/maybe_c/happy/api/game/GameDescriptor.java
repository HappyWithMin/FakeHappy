package maybe_c.happy.api.game;

import net.kyori.adventure.text.Component;
import org.bukkit.inventory.ItemStack;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;

/**
 * 一个小游戏的静态元数据 —— 大厅 UI、OP 场控面板、跨服排队都靠它来展示和决策，
 * 所以哪怕游戏还没开一局，这些信息也必须是齐的。
 *
 * <p>不可变。用 {@link #builder(String, Component)} 构造。
 */
public final class GameDescriptor {

    private final String id;
    private final Component displayName;
    private final List<Component> description;
    private final ItemStack icon;
    private final String iconSprite;
    private final int minPlayers;
    private final int maxPlayers;
    private final String category;
    private final boolean spectatable;
    private final boolean crossServer;
    private final boolean isolateVisibility;
    private final GameStage stage;
    private final PartyMode partyMode;
    private final double sigma;
    private final int baseCoins;
    private final boolean competitive;
    private final maybe_c.happy.api.game.settlement.SettlementMode settlementMode;
    private final boolean scoreboardExempt;
    private final boolean voiceManaged;
    private final boolean spectatorTakeover;

    private GameDescriptor(Builder b) {
        this.id = b.id;
        this.displayName = b.displayName;
        this.description = List.copyOf(b.description);
        this.icon = b.icon == null ? null : b.icon.clone();
        this.iconSprite = b.iconSprite;
        this.minPlayers = b.minPlayers;
        this.maxPlayers = b.maxPlayers;
        this.category = b.category;
        this.spectatable = b.spectatable;
        this.crossServer = b.crossServer;
        this.isolateVisibility = b.isolateVisibility;
        this.stage = b.stage;
        this.partyMode = b.partyMode;
        this.sigma = b.sigma;
        this.baseCoins = b.baseCoins;
        this.competitive = b.competitive;
        this.settlementMode = b.settlementMode;
        this.scoreboardExempt = b.scoreboardExempt;
        this.voiceManaged = b.voiceManaged;
        this.spectatorTakeover = b.spectatorTakeover;
    }

    public static @NotNull Builder builder(@NotNull String id, @NotNull Component displayName) {
        return new Builder(id, displayName);
    }

    /** 全网唯一 ID，小写短横线（如 {@code spleef}）。跨服消息也用它当 key。 */
    public @NotNull String id() {
        return id;
    }

    public @NotNull Component displayName() {
        return displayName;
    }

    /** 多行说明，给大厅 UI 的 lore / tooltip 用。 */
    public @NotNull List<Component> description() {
        return description;
    }

    /** 箱子界面里的图标物品。返回副本。 */
    public @Nullable ItemStack icon() {
        return icon == null ? null : icon.clone();
    }

    /**
     * sprite 形态的图标，写完整 MiniMessage 标签，例如
     * {@code <sprite:gui:icon/checkmark>}。Dialog 和聊天里用它。
     * 注意 sprite 要客户端 1.21.9+，所以 {@link #icon()} 仍然要给。
     */
    public @Nullable String iconSprite() {
        return iconSprite;
    }

    public int minPlayers() {
        return minPlayers;
    }

    /** 上限。{@link Integer#MAX_VALUE} 表示不限。 */
    public int maxPlayers() {
        return maxPlayers;
    }

    /** 分类，用于大厅 UI 分页。如 {@code pvp} / {@code parkour} / {@code party}。 */
    public @NotNull String category() {
        return category;
    }

    /** 支持旁观吗。 */
    public boolean spectatable() {
        return spectatable;
    }

    /**
     * 这个游戏参与跨服排队吗。
     * 为 true 时框架会把本机房间状态上报到跨服层，代理侧才能把人分配过来。
     */
    public boolean crossServer() {
        return crossServer;
    }

    /**
     * 开局时是否要把参与者与场外玩家互相隐藏。
     * 大厅里的小游戏基本都要（不然场外围观的人会挡视野），
     * 独占子服的小游戏不需要。
     */
    public boolean isolateVisibility() {
        return isolateVisibility;
    }

    /**
     * 开发阶段（规范 3.1 / 12.1）。合规检查的严格度按它走。
     * 不声明时默认 {@link GameStage#ALPHA}。
     */
    public @NotNull GameStage stage() {
        return stage;
    }

    /**
     * 编队形态（规范第五章）。<b>没声明时返回 null</b> ——
     * 全服组队系统据此判断「这个游戏还没适配组队」，合规检查会报缺失。
     */
    public @Nullable PartyMode partyMode() {
        return partyMode;
    }

    /**
     * 石粒币差距控制系数 σ（规范 11.1）。
     *
     * <p><b>没声明时是 NaN</b> —— 规范 12.2.6 要求「σ 取值有书面记录」，
     * 声明在这里就是那份记录。娱乐 0.5~1.0 / 竞技 1.5~2.5 / 赢家通吃 ≥3.0。
     */
    public double sigma() {
        return sigma;
    }

    /**
     * 人均基础石粒币 {@code a}。一局的总奖池 = 参与人数 × a。
     *
     * <p>{@code < 0} 表示没声明 —— 走框架结算时必须声明，
     * 否则框架不知道该发多少（那时会拒绝结算并说清楚缺什么，
     * 而不是默默发 0）。
     */
    public int baseCoins() {
        return baseCoins;
    }

    public boolean hasBaseCoins() {
        return baseCoins >= 0;
    }

    /**
     * 是不是竞技游戏。影响两件事：
     *
     * <ul>
     *   <li><b>聊天</b>（规范 10.2）：默认队伍频道，<b>禁止全局</b> ——
     *       不然对手能听见你报点</li>
     *   <li>σ 的合理区间：竞技 1.5~2.5，娱乐 0.5~1.0</li>
     * </ul>
     */
    public boolean competitive() {
        return competitive;
    }

    /**
     * 结算由谁做。默认 {@code CUSTOM}（沿用旧行为，你自己结算）。
     *
     * <p>声明 {@code FRAMEWORK} 之后，规范里五条和结算 / 发奖相关的
     * 「必须」项由框架保证，检查器直接判通过。
     */
    public @NotNull maybe_c.happy.api.game.settlement.SettlementMode settlementMode() {
        return settlementMode;
    }

    public boolean hasSigma() {
        return !Double.isNaN(sigma);
    }

    /**
     * 原版 Tab / 记分板被玩法占用了吗（规范第九章的例外）。
     *
     * <p>规范原文：「若被玩法占用如地图类游戏，则本章不做强制」。
     * 声明 true 之后，合规检查不再要求 Tab 底部和记分板首尾那两项。
     *
     * <p><b>别拿它当偷懒的口子</b> —— 它是给「玩法真的把计分板当画布用了」
     * 的游戏留的，不是给「我懒得接」的。验收时会看。
     */
    public boolean scoreboardExempt() {
        return scoreboardExempt;
    }

    /**
     * 框架的语音分房管不管这个游戏里的人。默认 true。
     *
     * <p>声明 false 之后，语音拓展看见这局里的人就当没看见：
     * 不给他们开频道、不拖人、散场也不往大厅赶。这是给<b>自己已经有一套语音方案</b>
     * 的游戏留的口子 —— 两套都在拖人的时候，玩家会被来回拽，而且两边都觉得自己是对的。
     *
     * <p>声明在这里而不是各子服的语音配置里：那种名单换一台机器就得再维护一份，
     * 而且漏了不会报错，只会表现成「这个游戏的语音偶尔抽风」。
     */
    public boolean voiceManaged() {
        return voiceManaged;
    }

    /**
     * 进入观战时，框架要不要接管这个人的<b>游戏模式和可见性</b>。默认 true。
     *
     * <p>为 true 时框架做两件事：强制切成原版 {@code SPECTATOR}（规范 8.1 的
     * 「默认第三人称、可切视角」），以及把他对局内玩家隐藏（8.1 的「对玩家不可见、不可干扰」）。
     *
     * <p>为 false 时这两件事框架都不做，<b>但仍然把他登记进观战索引</b> ——
     * 聊天隔离、跨服重连、语音那边的「观战者闭麦」认的都是那个索引。
     * 这条口子是给<b>自己已经有一套观战实现</b>的游戏留的：它们往往有自己的
     * 可见性服务和自己的观战视角（自由镜头、导播位），两套接管会互相打架，
     * 结果是游戏只能连观战索引一起不用，反而把框架那些只认索引的功能也弄丢了。
     *
     * <p><b>别拿它当偷懒的口子。</b>声明 false 之后，规范 8.1 的视角与不可见两条
     * 从「框架负责」变成你自查声明（{@code spectate.self-managed}），验收时会看。
     */
    public boolean spectatorTakeover() {
        return spectatorTakeover;
    }

    public static final class Builder {
        private final String id;
        private final Component displayName;
        private final List<Component> description = new ArrayList<>(3);
        private ItemStack icon;
        private String iconSprite;
        private int minPlayers = 2;
        private int maxPlayers = Integer.MAX_VALUE;
        private String category = "misc";
        private boolean spectatable = true;
        private boolean crossServer = false;
        private boolean isolateVisibility = true;
        private GameStage stage = GameStage.ALPHA;
        private PartyMode partyMode = null;
        private double sigma = Double.NaN;
        private int baseCoins = -1;
        private boolean competitive;
        /**
         * 默认自行结算 —— 已经写好的游戏不会因为升级框架就被改掉发奖逻辑。
         * 新游戏建议显式声明 FRAMEWORK。
         */
        private maybe_c.happy.api.game.settlement.SettlementMode settlementMode =
                maybe_c.happy.api.game.settlement.SettlementMode.CUSTOM;
        private boolean scoreboardExempt = false;
        private boolean voiceManaged = true;
        private boolean spectatorTakeover = true;

        private Builder(String id, Component displayName) {
            if (id == null || id.isBlank()) {
                throw new IllegalArgumentException("小游戏 id 不能为空");
            }
            if (!id.equals(id.toLowerCase(java.util.Locale.ROOT))) {
                throw new IllegalArgumentException("小游戏 id 必须全小写: " + id);
            }
            this.id = id;
            this.displayName = displayName;
        }

        public @NotNull Builder description(@NotNull Component line) {
            this.description.add(line);
            return this;
        }

        public @NotNull Builder description(@NotNull List<Component> lines) {
            this.description.addAll(lines);
            return this;
        }

        public @NotNull Builder icon(@Nullable ItemStack icon) {
            this.icon = icon;
            return this;
        }

        public @NotNull Builder iconSprite(@Nullable String spriteTag) {
            this.iconSprite = spriteTag;
            return this;
        }

        public @NotNull Builder players(int min, int max) {
            if (min < 1) throw new IllegalArgumentException("minPlayers 至少为 1");
            if (max < min) throw new IllegalArgumentException("maxPlayers 不能小于 minPlayers");
            this.minPlayers = min;
            this.maxPlayers = max;
            return this;
        }

        public @NotNull Builder category(@NotNull String category) {
            this.category = category;
            return this;
        }

        public @NotNull Builder spectatable(boolean spectatable) {
            this.spectatable = spectatable;
            return this;
        }

        public @NotNull Builder crossServer(boolean crossServer) {
            this.crossServer = crossServer;
            return this;
        }

        public @NotNull Builder isolateVisibility(boolean isolate) {
            this.isolateVisibility = isolate;
            return this;
        }

        /**
         * 开发阶段（规范 3.1 / 12.1）。不设默认 ALPHA。
         *
         * <p>设成 {@link GameStage#RELEASE} 之后，合规检查里没过的「必须」项
         * 会在启动日志里给出醒目警告 —— 那是有意的，正式上线就该满足全部硬要求。
         */
        public @NotNull Builder stage(@NotNull GameStage stage) {
            this.stage = stage;
            return this;
        }

        /** 编队形态（规范第五章）。<b>每个游戏都要声明</b>，单人游戏声明 SOLO。 */
        public @NotNull Builder partyMode(@NotNull PartyMode mode) {
            this.partyMode = mode;
            return this;
        }

        /**
         * 声明「原版 Tab / 记分板被玩法占用了」（规范第九章例外）。
         * 只有地图类这种真把计分板当画布用的游戏才该设 true。
         */
        public @NotNull Builder scoreboardExempt(boolean exempt) {
            this.scoreboardExempt = exempt;
            return this;
        }

        /**
         * 语音交给框架管吗。默认 true。
         *
         * <p>只有真的自带语音方案（Simple Voice Chat 这类）才设 false ——
         * 设了之后框架不再碰这局里的人，「散场拖回大厅」那一步也不做，
         * 队伍怎么分、谁听得见谁，全归你自己。
         */
        public @NotNull Builder voiceManaged(boolean managed) {
            this.voiceManaged = managed;
            return this;
        }

        /**
         * 观战时框架要不要接管游戏模式与可见性。默认 true。
         *
         * <p>设成 false 只免掉「强制 SPECTATOR」和「对局内玩家隐藏」这两件事，
         * <b>观战索引照样登记</b>，所以聊天隔离、语音闭麦这些只认索引的功能还在。
         *
         * <p>只有自己已经写了一套观战（自己的可见性服务、自己的视角控制）才该设 false ——
         * 两套都在设游戏模式和 hidePlayer 的话，谁后跑谁赢，表现成「观战偶尔抽风」。
         * 设了之后规范 8.1 的那两条归你，在 {@code compliance()} 里声明
         * {@code done("spectate.self-managed")}。
         */
        public @NotNull Builder spectatorTakeover(boolean takeover) {
            this.spectatorTakeover = takeover;
            return this;
        }

        /**
         * 石粒币差距控制系数 σ（规范 11.1）。
         *
         * @throws IllegalArgumentException σ 必须 &gt; 0
         */
        /**
         * 竞技游戏。默认 false（娱乐向）。
         *
         * <p>开了之后框架自动按规范 10.2 处理聊天：默认队伍频道、禁全局。
         * <b>前提是你覆写了 {@code MiniGame.teamOf(...)}</b> ——
         * 没有队伍信息的话队伍频道无从隔离，框架会在注册时警告。
         */
        public @NotNull Builder competitive(boolean competitive) {
            this.competitive = competitive;
            return this;
        }

        /**
         * 人均基础石粒币 {@code a}。总奖池 = 人数 × a。
         *
         * <p>走框架结算（{@link #settlement}）时必须声明。
         */
        public @NotNull Builder baseCoins(int a) {
            if (a < 0) throw new IllegalArgumentException("人均基础石粒币不能为负，收到 " + a);
            this.baseCoins = a;
            return this;
        }

        /**
         * 结算由谁做。<b>新游戏建议声明 {@code FRAMEWORK}</b> ——
         * 币、经验、衰减、自定义房不发奖、结算界面、回游戏大厅全部由框架做，
         * 对应的五条规范「必须」项自动通过。
         */
        public @NotNull Builder settlement(
                @NotNull maybe_c.happy.api.game.settlement.SettlementMode mode) {
            this.settlementMode = mode;
            return this;
        }

        public @NotNull Builder sigma(double sigma) {
            if (!(sigma > 0) || !Double.isFinite(sigma)) {
                throw new IllegalArgumentException("σ 必须是大于 0 的有限数，收到 " + sigma);
            }
            this.sigma = sigma;
            return this;
        }

        public @NotNull GameDescriptor build() {
            return new GameDescriptor(this);
        }
    }
}
