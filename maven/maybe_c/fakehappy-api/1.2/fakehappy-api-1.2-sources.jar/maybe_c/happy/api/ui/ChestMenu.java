package maybe_c.happy.api.ui;

import net.kyori.adventure.text.Component;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.function.Consumer;
import java.util.function.Supplier;

/**
 * 箱子形态的菜单。所有客户端版本都能看，是 UI 的保底形态。
 *
 * <p>框架已经处理好的事情（不用自己写）：
 * <ul>
 *   <li>点击一律取消，物品拿不走、塞不进，也没法 shift 快速移动</li>
 *   <li>拖拽、数字键换位、双击收集、快捷键丢弃全部拦掉</li>
 *   <li>玩家退出 / 传送 / 死亡时自动摘除观看者，不会留下悬空引用</li>
 *   <li>服务器关闭或模块卸载时自动关掉所有打开的界面，不会把玩家卡在一个死界面里</li>
 * </ul>
 */
public interface ChestMenu extends Menu {

    /** 行数（1~6）。 */
    int rows();

    /** 总槽位数，等于 {@code rows() * 9}。 */
    default int size() {
        return rows() * 9;
    }

    /**
     * 运行时替换某个槽位。会自动触发对该槽位的重绘。
     *
     * @param button null = 清空该槽位
     */
    void set(int slot, @Nullable MenuButton button);

    interface Builder {

        /** 行数，1~6。默认 3。 */
        @NotNull Builder rows(int rows);

        /**
         * 放一个按钮。
         *
         * @param slot 0 起算，从左上到右下
         * @throws IndexOutOfBoundsException slot 超出 {@code rows*9}
         */
        @NotNull Builder set(int slot, @NotNull MenuButton button);

        /**
         * 放一个每次重绘都重新求值的按钮。
         *
         * <p>内容会变的格子（在线人数、倒计时、当前配置值）用这个，
         * 不要自己起定时任务去 {@code set()} —— 那样会在菜单没人看的时候
         * 也一直算，还容易忘了取消。
         */
        @NotNull Builder dynamic(int slot, @NotNull Supplier<MenuButton> supplier);

        /**
         * 按<b>观看者</b>求值的动态按钮。
         *
         * <p>与上面那个的区别：这里能拿到「正在看这个菜单的是谁」。
         * 需要逐人状态的场景用它 —— 比如场控面板里「当前选中的小游戏」
         * 是每个 OP 各自一份的，两个 OP 同时开面板不该互相打架。
         *
         * <p>{@code visibleIf} / {@code enabledIf} 解决不了这类问题：
         * 那两个只能决定「显不显示」，改不了按钮的内容。
         */
        @NotNull Builder dynamic(int slot, @NotNull java.util.function.Function<Player, MenuButton> perViewer);

        /** 按 (行, 列) 放，行列都从 0 起算。比手算 slot 好读。 */
        @NotNull Builder at(int row, int col, @NotNull MenuButton button);

        /** 把剩余空槽全部填成同一个装饰物品。一般在最后调。 */
        @NotNull Builder fillEmpty(@NotNull ItemStack filler);

        /** 在四周描一圈边框。 */
        @NotNull Builder border(@NotNull ItemStack filler);

        /**
         * 关闭回调。玩家主动关、被 {@link Menu#close} 关、退出游戏都会触发，
         * <b>每次关闭只触发一次</b>。
         *
         * <p>注意：从本菜单 {@code ctx.open(other)} 跳到另一个菜单时，
         * 客户端层面确实关了一次箱子，但框架识别为「导航」而<b>不</b>触发这个回调，
         * 免得你在这里写的「玩家退出游戏」逻辑被子菜单误触发。
         */
        @NotNull Builder onClose(@NotNull Consumer<Player> onClose);

        /**
         * 每次重绘前调用，用来刷新那些不适合放进 {@link #dynamic} 的整体状态。
         * 参数是即将看到这次重绘的玩家。
         */
        @NotNull Builder beforeRefresh(@NotNull Consumer<Player> hook);

        /**
         * 自动刷新周期（tick）。设了之后框架会在<b>有人在看的时候</b>按周期调
         * {@link Menu#refresh()}，没人看就不跑。0 = 不自动刷新（默认）。
         */
        @NotNull Builder autoRefresh(int periodTicks);

        /** 覆盖标题。不调则用 {@code UiService.chest(title, rows)} 传的那个。 */
        @NotNull Builder title(@NotNull Component title);

        @NotNull ChestMenu build();
    }
}
