package maybe_c.happy.api.reward;

import org.jetbrains.annotations.NotNull;

/**
 * 一次要发的东西。三项都可以是 0。
 *
 * <p>不可变，可以安全地当常量复用（比如「每日首胜奖励」建一个静态字段）。
 *
 * <pre>{@code
 * // 小游戏结算：按规范 11.1/11.2 算完直接发
 * int[] coins = RewardFormula.payout(n, a, descriptor.sigma());
 * int exp = RewardFormula.exp(base, rate, minutes, cap, won, mvp);
 * api.rewards().grant(uuid, RewardBundle.of(coins[rank - 1], exp), "miner:win");
 * }</pre>
 */
public record RewardBundle(double currency, long exp, int points) {

    /** 什么都不发。用于「这局是自定义房间」这类分支，省得写 if。 */
    public static final RewardBundle NOTHING = new RewardBundle(0, 0, 0);

    public RewardBundle {
        // 负数会让「发奖励」悄悄变成「扣东西」。扣要走 RewardService 上明确的接口，
        // 不能藏在 grant 里 —— 不然一个算错的公式能把玩家余额清空
        if (currency < 0) throw new IllegalArgumentException("currency 不能为负: " + currency);
        if (exp < 0) throw new IllegalArgumentException("exp 不能为负: " + exp);
        if (points < 0) throw new IllegalArgumentException("points 不能为负: " + points);
        if (Double.isNaN(currency) || Double.isInfinite(currency)) {
            throw new IllegalArgumentException("currency 不是有限数: " + currency);
        }
    }

    public static @NotNull RewardBundle of(double currency, long exp) {
        return new RewardBundle(currency, exp, 0);
    }

    public static @NotNull RewardBundle of(double currency, long exp, int points) {
        return new RewardBundle(currency, exp, points);
    }

    public static @NotNull RewardBundle currency(double amount) {
        return new RewardBundle(amount, 0, 0);
    }

    public static @NotNull RewardBundle exp(long amount) {
        return new RewardBundle(0, amount, 0);
    }

    public static @NotNull RewardBundle points(int amount) {
        return new RewardBundle(0, 0, amount);
    }

    /** 三项全是 0。发之前判一下可以省掉一次异步调度。 */
    public boolean isEmpty() {
        return currency <= 0 && exp <= 0 && points <= 0;
    }

    public double amountOf(@NotNull RewardKind kind) {
        return switch (kind) {
            case CURRENCY -> currency;
            case EXP -> exp;
            case POINTS -> points;
        };
    }

    /**
     * 整体按比例缩放，用于连续开局衰减（规范 11.4）。
     *
     * <p>货币保留小数，经验和积分向下取整 —— 宁可少给一点，
     * 也不要因为四舍五入让「全场之和 = n×a」这条验收项失败。
     */
    public @NotNull RewardBundle scale(double factor) {
        if (factor == 1.0) return this;
        if (factor <= 0) return NOTHING;
        return new RewardBundle(currency * factor, (long) (exp * factor), (int) (points * factor));
    }

    public @NotNull RewardBundle plus(@NotNull RewardBundle other) {
        return new RewardBundle(currency + other.currency, exp + other.exp, points + other.points);
    }
}
