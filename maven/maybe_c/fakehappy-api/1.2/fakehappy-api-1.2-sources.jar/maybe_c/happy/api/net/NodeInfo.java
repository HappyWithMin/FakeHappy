package maybe_c.happy.api.net;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/**
 * 网络里一个子服节点的快照。
 *
 * @param serverId     子服 ID，与 velocity.toml 里的 key 一致
 * @param displayName  中文显示名，取自代理侧的 serverDisplayNames 映射；没有映射时等于 serverId
 * @param proxyId      它当前挂在哪个 velocity 代理节点下。单代理环境恒为同一个值
 * @param role         子服角色
 * @param onlinePlayers 在线人数
 * @param maxPlayers   人数上限，-1 表示未知 / 不限
 * @param lastHeartbeat 最后一次心跳的毫秒时间戳
 * @param online       心跳是否还在有效期内
 */
public record NodeInfo(
        @NotNull String serverId,
        @NotNull String displayName,
        @Nullable String proxyId,
        @NotNull String role,
        int onlinePlayers,
        int maxPlayers,
        long lastHeartbeat,
        boolean online
) {

    /** 距上次心跳过了多久（毫秒）。 */
    public long staleness(long nowMillis) {
        return nowMillis - lastHeartbeat;
    }

    /** 满了吗。maxPlayers 未知时恒为 false。 */
    public boolean full() {
        return maxPlayers > 0 && onlinePlayers >= maxPlayers;
    }
}
