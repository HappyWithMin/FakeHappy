package maybe_c.happy.api.data;

import org.jetbrains.annotations.NotNull;

import java.util.UUID;

/**
 * 一个玩家在一个小游戏上的累计战绩。
 *
 * @param playerId   玩家
 * @param gameId     小游戏 ID
 * @param plays      打过几局
 * @param wins       赢了几局
 * @param losses     输了几局
 * @param kills      击杀
 * @param deaths     死亡
 * @param score      自定义积分。各游戏含义自定，排行榜默认按它排
 * @param playtimeMs 累计游玩时长（毫秒）
 * @param lastPlayed 最后一次游玩的毫秒时间戳
 */
public record GameStats(
        @NotNull UUID playerId,
        @NotNull String gameId,
        int plays,
        int wins,
        int losses,
        int kills,
        int deaths,
        long score,
        long playtimeMs,
        long lastPlayed
) {

    /** 一条空记录，用于「查不到就当他没打过」。 */
    public static @NotNull GameStats empty(@NotNull UUID id, @NotNull String gameId) {
        return new GameStats(id, gameId, 0, 0, 0, 0, 0, 0L, 0L, 0L);
    }

    /** 胜率。没打过时返回 0，不是 NaN —— 直接拿去格式化不会印出 "NaN%"。 */
    public double winRate() {
        return plays == 0 ? 0.0 : (double) wins / plays;
    }

    public double kd() {
        return deaths == 0 ? kills : (double) kills / deaths;
    }
}
