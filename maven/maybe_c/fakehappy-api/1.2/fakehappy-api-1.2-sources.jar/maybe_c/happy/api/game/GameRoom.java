package maybe_c.happy.api.game;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/**
 * 本机上一局正在跑的游戏。
 *
 * <h2>为什么 MiniGame 之外还要有这个</h2>
 * 有的小游戏一个子服同时只开一局（惊天矿工团这种：全场共用一个竞技场，
 * 一局打完再开下一局）；有的同时开好几局（每局各占一块场地，
 * 几块场地就是几局在同时跑）。
 * 如果把 {@link MiniGame} 直接当成「一局」，后一种就没法建模了。
 *
 * <p>所以分成两层：{@link MiniGame} 是<b>这个子服上的这个游戏</b>，
 * {@link GameRoom} 是<b>它当前开着的某一局</b>。单局制的游戏
 * {@link MiniGame#rooms()} 就返回一个元素，不用为此多写代码。
 *
 * <p>跨服排队分配到的是<b>房间</b>而不是游戏，大厅 UI 上「争夺战 · 二号服 · 8/16」
 * 那一行说的也是房间。
 *
 * <h2>字段对应规范 6.4</h2>
 * 「房间列表必须展示：房间名/编号、当前人数/容量、地图（若适用）、状态」——
 * 这条验收项要求的四项这里都有。地图名不适用的游戏传 null。
 *
 * @param roomId     同一子服内唯一，<b>长度不超过 16 字符</b>（规范 6.4）。
 *                   用地皮号、竞技场名之类稳定的东西，不要用自增计数器 ——
 *                   重启后会和跨服层里的残留对不上
 * @param type       房间类型（规范第六章）。<b>决定这一局发不发局外奖励</b>
 * @param state      这一局的状态
 * @param players    当前人数
 * @param maxPlayers 这一局的人数上限（可能小于 {@code descriptor().maxPlayers()}，
 *                   后者说的是整个子服的总容量）
 * @param minPlayers 开局所需最少人数
 * @param mapName    地图名，没有地图概念的游戏传 null
 */
public record GameRoom(
        @NotNull String roomId,
        @NotNull RoomType type,
        @NotNull GameState state,
        int players,
        int maxPlayers,
        int minPlayers,
        @Nullable String mapName
) {

    /** 规范 6.4 要求的房间名长度上限。 */
    public static final int MAX_ROOM_ID_LENGTH = 16;

    public GameRoom {
        if (roomId.isBlank()) {
            throw new IllegalArgumentException("房间 ID 不能为空");
        }
    }

    /**
     * 普通房间的简写 —— 单局制、没有地图概念的游戏用这个。
     */
    public static @NotNull GameRoom normal(@NotNull String roomId, @NotNull GameState state,
                                           int players, int maxPlayers, int minPlayers) {
        return new GameRoom(roomId, RoomType.NORMAL, state, players, maxPlayers, minPlayers, null);
    }

    /** 看起来还能进人吗。跨服分配的最终判定不在这里，见 NetworkService 的预约位机制。 */
    public boolean joinable() {
        return state.joinable() && players < maxPlayers;
    }

    public int freeSlots() {
        return Math.max(0, maxPlayers - players);
    }

    /**
     * 这一局结束时该不该发石粒币和经验（规范 6.2 / 11.4）。
     *
     * <p>结算前查这个，<b>别自己按房间名判断</b>。
     */
    public boolean grantsRewards() {
        return type.grantsRewards();
    }

    /** roomId 是否符合规范 6.4 的长度要求。合规检查用。 */
    public boolean roomIdWithinLimit() {
        return roomId.length() <= MAX_ROOM_ID_LENGTH;
    }
}
