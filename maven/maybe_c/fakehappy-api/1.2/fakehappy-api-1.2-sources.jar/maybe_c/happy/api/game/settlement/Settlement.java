package maybe_c.happy.api.game.settlement;

import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * 一局的结算数据。交给 {@link SettlementService#settle} 之后，框架负责：
 *
 * <ol>
 *   <li>按规范 11.1 算石粒币（总额恒等于 {@code n × a}，不会多也不会少）</li>
 *   <li>按规范 11.3 算经验（胜利 +30%、MVP +50%，正确叠加）</li>
 *   <li>按规范 11.4 套同房连开衰减，并把中途退出的人按 50% 经验、无币处理</li>
 *   <li>自定义房间<b>一分不发</b>（规范 6.2 / 11.4）</li>
 *   <li>画结算界面：名次、你填的数据、实际到账的奖励</li>
 *   <li>把人送回<b>游戏大厅</b>（规范 4.6），不停在等待大厅直接开下一把</li>
 * </ol>
 *
 * <h2>为什么把这些收进框架</h2>
 * 这六件事在规范里是六条「必须」项，而它们全是<b>机械的</b> ——
 * 没有哪个游戏需要用不一样的方式算总额守恒。留给每个游戏自己做的结果是
 * 每个游戏都做对一部分：这个忘了衰减、那个自定义房照发、
 * 还有一个结算完直接开下一局。
 *
 * <p>交给框架之后，这几条从「你要记得做」变成「你调了就有」。
 *
 * <h2>你仍然可以自己做</h2>
 * 在 {@code GameDescriptor} 里声明 {@code settlementMode(CUSTOM)}，
 * 那这几条规范项回到「需声明」，由你自己实现并自查。
 * 适合那些结算形态特殊到框架界面表达不了的游戏。
 *
 * @param placements  全部参与者的名次。<b>包括中途退出的</b>
 * @param minutes     本局时长（分钟）。经验按它算
 * @param baseCoins   人均基础石粒币 {@code a}，总奖池 = 人数 × a。
 *                    传 {@code null} 用 {@code GameDescriptor.baseCoins()}
 * @param roomId      本局所在房间。框架用它判断房间类型（自定义房不发奖）
 *                    和同房连开衰减；传 null 表示「不属于任何房间」，按普通房处理
 * @param returnToHub 结算展示完把人送回游戏大厅。<b>默认 true</b> ——
 *            规范 4.6 要求如此，除非你的游戏根本不在房间体系里
 */
@ApiStatus.Experimental
public record Settlement(
        @NotNull List<Placement> placements,
        double minutes,
        @Nullable Integer baseCoins,
        @Nullable String roomId,
        boolean returnToHub
) {

    public Settlement {
        placements = List.copyOf(placements);
        if (placements.isEmpty()) {
            throw new IllegalArgumentException("结算名单不能为空");
        }
        if (minutes < 0) {
            throw new IllegalArgumentException("时长不能为负，收到 " + minutes);
        }
    }

    public static @NotNull Builder builder() {
        return new Builder();
    }

    public static final class Builder {

        private final List<Placement> placements = new ArrayList<>();
        private double minutes;
        private Integer baseCoins;
        private String roomId;
        private boolean returnToHub = true;

        private Builder() {
        }

        public @NotNull Builder add(@NotNull Placement placement) {
            placements.add(placement);
            return this;
        }

        public @NotNull Builder add(@NotNull Placement.Builder placement) {
            return add(placement.build());
        }

        /** 便捷写法：只有名次，没有额外数据。 */
        public @NotNull Builder add(@NotNull UUID player, int rank) {
            return add(Placement.of(player, rank).build());
        }

        /** 本局打了多久（分钟）。经验按它算，所以别忘了填。 */
        public @NotNull Builder minutes(double minutes) {
            this.minutes = minutes;
            return this;
        }

        /** 人均基础石粒币。不填则用 descriptor 里声明的。 */
        public @NotNull Builder baseCoins(int a) {
            this.baseCoins = a;
            return this;
        }

        public @NotNull Builder room(@Nullable String roomId) {
            this.roomId = roomId;
            return this;
        }

        /**
         * 结算完不要把人送回游戏大厅。
         *
         * <p><b>想清楚再用。</b>规范 4.6 明确要求结算后回游戏大厅，
         * 让玩家有明确的退出与再选择机会 —— 停在等待大厅直接开下一把是被禁的。
         * 这个开关是给「压根不在房间体系里」的玩法留的口子。
         */
        public @NotNull Builder stayHere() {
            this.returnToHub = false;
            return this;
        }

        public @NotNull Settlement build() {
            return new Settlement(placements, minutes, baseCoins, roomId, returnToHub);
        }
    }
}
