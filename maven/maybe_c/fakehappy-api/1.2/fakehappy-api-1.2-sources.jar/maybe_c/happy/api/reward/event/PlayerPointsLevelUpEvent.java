package maybe_c.happy.api.reward.event;

import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;
import org.jetbrains.annotations.NotNull;

/**
 * 积分等级提升（舰长服叫「贡献等级」，别的服可能叫别的）。
 * <b>在主线程触发。</b>
 *
 * <p>和 {@link PlayerLevelUpEvent} 一样：跨多级只触发一次，不可取消。
 *
 * <p>积分等级从 0 起 —— 第一次拿到积分是 {@code from=0, to=1}。
 */
public class PlayerPointsLevelUpEvent extends Event {

    private static final HandlerList HANDLERS = new HandlerList();

    private final Player player;
    private final int from;
    private final int to;
    private final int totalPoints;

    public PlayerPointsLevelUpEvent(@NotNull Player player, int from, int to, int totalPoints) {
        this.player = player;
        this.from = from;
        this.to = to;
        this.totalPoints = totalPoints;
    }

    public @NotNull Player player() {
        return player;
    }

    public int from() {
        return from;
    }

    public int to() {
        return to;
    }

    public int levelsGained() {
        return to - from;
    }

    public int totalPoints() {
        return totalPoints;
    }

    @Override
    public @NotNull HandlerList getHandlers() {
        return HANDLERS;
    }

    public static @NotNull HandlerList getHandlerList() {
        return HANDLERS;
    }
}
