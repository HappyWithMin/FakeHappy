package maybe_c.happy.api.ui;

import net.kyori.adventure.text.Component;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

import java.util.Set;
import java.util.UUID;

/**
 * 一个已构建好的菜单。{@link ChestMenu} 和 {@link DialogMenu} 都是它。
 *
 * <p><b>菜单实例可以被多个玩家同时打开</b>，按钮的 visibleIf / enabledIf
 * 是按观看者逐个求值的，所以「同一个管理菜单，OP 看到 12 个按钮、
 * 助管看到 4 个」不需要建两份菜单。
 *
 * <p><b>清理</b>：菜单本身不持有玩家强引用（内部只存 UUID）。玩家退出、
 * 换世界、被踢，框架都会把他从 viewers 里摘掉。但如果你的按钮回调里
 * 闭包捕获了 Player / 实体 / 世界对象，那是你自己的泄漏，框架管不了 ——
 * 闭包里请只捕获 UUID 或不可变数据。
 */
public interface Menu {

    /** 菜单标题。 */
    @NotNull Component title();

    /**
     * 给玩家打开，<b>立即生效</b>。会把该玩家已打开的本框架菜单压进导航栈。
     *
     * <p>用于<b>玩家主动触发</b>的场景：点了按钮、敲了命令。这种时候顶掉他当前的
     * 界面正是他要的结果，不该推迟。
     *
     * <p>玩家主动弹窗（进服提示、活动通知、传送确认）请改用 {@link #openWhenFree}。
     */
    void open(@NotNull Player player);

    /**
     * 给玩家打开，但<b>等他手头的界面关掉之后</b>再开。
     *
     * <p>用于<b>服务端主动</b>弹给玩家的东西。玩家可能正在填资源包确认框、
     * 正在看别的插件的 GUI —— 这时候硬塞一个菜单过去会把对方的操作打断，
     * 资源包确认框被顶掉更是会直接导致他进不了服。
     *
     * <p>等待有上限（约 2 分钟），超时后仍会打开，不会永久卡着不弹。
     */
    void openWhenFree(@NotNull Player player);

    /** 关掉指定玩家的这个菜单。他没在看就什么也不做。 */
    void close(@NotNull Player player);

    /** 关掉所有观看者。 */
    void closeAll();

    /**
     * 用最新数据重绘所有观看者的界面。
     *
     * <p>箱子界面是原地改 ItemStack，不会关窗口，所以不会闪、不会打断拖拽。
     * Dialog 会重新 show 一次（客户端表现为内容更新）。
     *
     * <p>可以安全地放进定时任务里每秒调一次；没有观看者时直接返回，开销为零。
     */
    void refresh();

    /**
     * 只重绘<b>一个</b>观看者看到的那一份。
     *
     * <h2>为什么必须有这个</h2>
     * {@link #refresh()} 重绘的是<b>全部</b>观看者。对箱子界面那是对的
     * （原地改 ItemStack，别人那份不受影响也不会闪）；但对 Dialog 是
     * 「给每个观看者重发一次 {@code showDialog}」，而 <b>Dialog 没有可靠的关闭事件</b>
     * （玩家按 ESC 时服务端收不到任何包），所以观看者集合里躺着的是
     * 「开服以来打开过这个菜单、还没退出游戏的所有人」。
     *
     * <p>于是「异步查完数据回来刷新一下」这个再正常不过的写法，会：
     * <ul>
     *   <li>把别人正在填的输入框清空 —— 输入控件按 {@code input(Function)} 重建，
     *       他打了一半的字不在任何快照里；</li>
     *   <li>把几十分钟前就关掉界面、正在挖矿的人凭空拽回一个对话框。</li>
     * </ul>
     * 两种都不报错，而且只有在<b>同时有第二个人用这个功能</b>时才出现。
     *
     * <p><b>所以：凡是「我这次异步取数完了，把我这一份画出来」，一律用这个方法。</b>
     * {@code refresh()} 留给「数据本身变了，所有人看到的都该跟着变」——
     * 比如倒计时、在线人数。
     *
     * <p>玩家不在看这个菜单时什么都不做。
     */
    void refreshFor(@NotNull Player player);

    boolean isViewing(@NotNull Player player);

    /** 当前观看者的 UUID 快照。 */
    @NotNull Set<UUID> viewers();

    /**
     * 主动作废这个菜单：关掉所有观看者并解绑框架内部的注册。
     *
     * <p>一次性菜单（比如某局游戏的结算界面）在用完后调一下，
     * 免得它一直挂在框架的活动菜单表里。模块关闭时框架会自动 dispose
     * 该模块创建的所有菜单，所以常规情况下不用手动调。
     */
    void dispose();

    /** 是否已 {@link #dispose()}。已作废的菜单再 open 会被忽略并记一条 warning。 */
    boolean isDisposed();
}
