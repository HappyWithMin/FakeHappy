package maybe_c.happy.api.ui;

import net.kyori.adventure.text.Component;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.function.Function;

/**
 * 小游戏的侧边栏计分板。底层是 FastBoard，无闪烁。
 *
 * <h2>为什么由框架提供而不是各写各的</h2>
 * 《舰长服小游戏制作规范》9.1 对首尾三处有<b>硬性格式要求</b>：
 * Tab 底部 {@code ==游戏名称==}（§6）、记分板顶部游戏名（§6）、
 * 记分板底部 {@code play.zimin.fan}（§7）。
 *
 * <p>十个游戏各写一遍，就会有十种写法慢慢走样 —— 有人忘了双等号、
 * 有人用了 §e、有人把底部行写在了中间。所以这三处<b>不开放给开发者设置</b>：
 * 你只提供中间内容，首尾由框架按规范拼。
 *
 * <h2>每个观看者一份</h2>
 * 内容通过 {@code Function<Player, List<Component>>} 提供，
 * 所以「你的队伍」「你的击杀数」这类逐人内容是天然支持的。
 *
 * <h2>不适用的情况</h2>
 * 规范 9 章原文：「若被玩法占用如地图类游戏，则本章不做强制」。
 * 那种游戏在 {@code GameDescriptor} 里 {@code scoreboardExempt(true)}，
 * 合规检查就不会要求这两项。
 */
public interface GameBoard {

    /** 规范 9.2：单行文本不应超过的字符数。 */
    int MAX_LINE_LENGTH = 32;

    /** 规范 9.2：记分板总行数不宜超过的行数（含框架加的首尾）。 */
    int MAX_TOTAL_LINES = 15;

    /** 中间内容最多几行 —— 总行数减掉框架占的底部行。 */
    int MAX_MIDDLE_LINES = MAX_TOTAL_LINES - 1;

    /** 规范 9.1：记分板底部固定这一行。 */
    String FOOTER_TEXT = "play.zimin.fan";

    /** 给这个玩家显示。同一个玩家重复调用是幂等的。 */
    void show(@NotNull Player player);

    /** 对这个玩家隐藏。 */
    void hide(@NotNull Player player);

    void hideAll();

    boolean isShownTo(@NotNull Player player);

    @NotNull Set<UUID> viewers();

    /**
     * 立刻用最新数据重绘所有观看者。
     *
     * <p>设了 {@code autoRefresh} 的话不用手动调。没有观看者时直接返回，开销为零。
     */
    void refresh();

    /**
     * 作废。会对所有观看者隐藏并解绑框架内部登记。
     *
     * <p>模块 / 插件卸载时框架会自动 dispose 它创建的所有计分板，
     * 常规情况下不用手动调。
     */
    void dispose();

    boolean isDisposed();

    interface Builder {

        /**
         * 中间内容，每次重绘按观看者求值。
         *
         * <p><b>只给中间部分</b> —— 顶部的游戏名和底部的 {@code play.zimin.fan}
         * 由框架按规范加，你不用管也改不了。
         *
         * <p>返回的行数超过 {@link #MAX_MIDDLE_LINES}、或某行超过
         * {@link #MAX_LINE_LENGTH} 字符时，框架会<b>照常显示</b>但在控制台警告一次
         * （不是每 tick 刷屏）。规范 9.2 那两条是「应当」不是「必须」，
         * 所以不强行截断 —— 截断会让人看到半截字却不知道为什么。
         */
        @NotNull Builder lines(@NotNull Function<Player, List<Component>> perViewer);

        /** 内容不随观看者变时的简写。 */
        @NotNull Builder lines(@NotNull java.util.function.Supplier<List<Component>> supplier);

        /**
         * 自动重绘周期（tick）。<b>有人在看的时候才跑</b>，没人看时开销为零。
         *
         * <p>倒计时这类每秒变的内容给 20 就够。给 1 是没必要的 ——
         * 计分板每 tick 重发一次包，一百人的服就是每秒两千个包。
         */
        @NotNull Builder autoRefresh(int periodTicks);

        /**
         * 要不要同时设置 Tab 底部的 {@code ==游戏名称==}（规范 9.1）。默认 true。
         *
         * <p>只在「Tab 已经被别的东西占了」时才关掉，并且要在合规声明里说明。
         */
        @NotNull Builder tabFooter(boolean enabled);

        @NotNull GameBoard build();
    }
}
