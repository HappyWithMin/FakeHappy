package maybe_c.happy.api.economy;

import net.kyori.adventure.text.Component;
import org.bukkit.OfflinePlayer;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.math.BigDecimal;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;

/**
 * 货币。<b>FakeHappy 自己就是这个服的经济后端</b>，不再通过 Vault 绕一圈。
 *
 * <p>Vault 仍然注册着 —— 那是给商店、领地这些第三方插件用的门面。
 * FakeHappy 内部（奖励发放、小游戏结算）一律走这个接口，
 * 少一跳、拿得到 {@link TxnResult} 这种带原因的结果，而 Vault 的
 * {@code EconomyResponse} 分不清「余额不足」和「数据库挂了」。
 *
 * <h2>读是同步的，写是异步的</h2>
 * <ul>
 *   <li>{@link #balance} <b>不查库</b>，读的是内存里那份。可以在主线程随便调 ——
 *       计分板每 tick 显示余额、商店 GUI 一次渲染 54 格，都不会产生一次数据库往返。
 *       这是上一代最主要的性能问题</li>
 *   <li>{@link #deposit} / {@link #withdraw} 返回 future。真正的加减在数据库里
 *       用<b>相对增量</b>做（{@code balance = balance + ?}），所以别的子服同时改
 *       同一个人的钱不会互相覆盖</li>
 * </ul>
 *
 * <h2>扣款的判定在哪</h2>
 * 同步那一步（{@link #has}）看的是内存值，异步那一步在数据库里再判一次
 * （{@code WHERE balance >= ?}）。两道都过了才算扣成功。
 *
 * <p>之所以要两道：Vault 的接口是同步的，商店插件等不了 future，
 * 所以必须有一个能立刻回答的判断；而内存值可能因为别处（管理员、跨服奖励）
 * 改过钱而偏旧，所以数据库那道才是最终裁决。<b>两道判定不一致时以数据库为准，
 * 并且会记一行 warning</b> —— 那说明有人在别处动了这个账户，
 * 不说出来的话就是一笔查不出来的错账。
 *
 * <h2>金额精度</h2>
 * 一律 {@code DECIMAL(30,2)}，入口处 HALF_UP 到两位小数。
 * <b>不要用 double 做累加</b>：{@code 0.1 + 0.2} 在二进制浮点下不是 {@code 0.3}，
 * 攒够笔数就会出现「余额比流水少一分」这种没法解释的差额。
 * Vault 门面被迫收发 double（它的接口如此），进来第一件事就是转成 BigDecimal。
 */
public interface EconomyService {

    /** 后端可用（数据库连上了）。不可用时读返回 0、写返回 {@link TxnResult.Status#UNAVAILABLE}。 */
    boolean available();

    /** 币种 ID，进数据库的 {@code currency} 列。改了等于换一套账，<b>不要改</b>。 */
    @NotNull String currencyId();

    /** 本服管它叫什么（石粒币）。展示用。 */
    @NotNull String currencyName();

    /** 带本服配色的货币名。 */
    @NotNull Component currencyDisplay();

    /** {@code 1,250 石粒币}，带配色。 */
    @NotNull Component format(@NotNull BigDecimal amount);

    /** 纯文本版，日志和命令回执用。 */
    @NotNull String formatPlain(@NotNull BigDecimal amount);

    // ---------------------------------------------------------------- 读

    /**
     * 余额。<b>读内存，不查库，主线程可调。</b>
     *
     * <p>没缓存过的玩家（离线的、刚进服还没加载完的）返回 {@link BigDecimal#ZERO}
     * 并触发一次后台加载。要确切值请用 {@link #fetch}。
     */
    @NotNull BigDecimal balance(@NotNull UUID player);

    /** 这个人的余额够不够。同 {@link #balance}，看的是内存值。 */
    boolean has(@NotNull UUID player, @NotNull BigDecimal amount);

    /**
     * 从数据库取确切余额，绕过缓存。查离线玩家、或者要做对账时用。
     *
     * <p>顺带把结果写回缓存。
     */
    @NotNull CompletableFuture<BigDecimal> fetch(@NotNull UUID player);

    // ---------------------------------------------------------------- 写

    /**
     * 入账。
     *
     * @param reason 进审计表的原因（{@code level-reward} / {@code admin-give} / {@code shop-sell}）。
     *               <b>务必如实填</b> —— 「凭什么我的钱多了/少了」只能靠它回答
     */
    @NotNull CompletableFuture<TxnResult> deposit(@NotNull UUID player, @NotNull BigDecimal amount,
                                                  @NotNull String reason);

    /**
     * 扣款。余额不足时<b>一分都不扣</b>，返回 {@link TxnResult.Status#INSUFFICIENT}。
     */
    @NotNull CompletableFuture<TxnResult> withdraw(@NotNull UUID player, @NotNull BigDecimal amount,
                                                   @NotNull String reason);

    /**
     * 直接设成某个值。<b>只给管理命令用。</b>
     *
     * <p>它是绝对写而不是相对增量，所以两个人同时设同一个账户时后写的赢 ——
     * 日常发钱扣钱请用 {@link #deposit} / {@link #withdraw}。
     */
    @NotNull CompletableFuture<TxnResult> set(@NotNull UUID player, @NotNull BigDecimal amount,
                                              @NotNull String reason);

    /**
     * 转账。<b>先扣后加</b>：扣失败就整笔不做，加失败会把扣掉的退回去。
     *
     * <p>不是数据库事务 —— 两个账户可能被不同子服并发操作，
     * 真开事务会把行锁扩散到整张表最热的两行上。补偿式回滚在这里够用：
     * 加款那一步只有数据库整个不可用才会失败，而那时候退款也做不了，
     * 所以退款失败会记一条<b>显式的 error 日志</b>带上双方 UUID 和金额，
     * 让运维能手工补 —— 静默吞掉才是真的丢钱。
     */
    @NotNull CompletableFuture<TxnResult> transfer(@NotNull UUID from, @NotNull UUID to,
                                                   @NotNull BigDecimal amount, @NotNull String reason);

    // ---------------------------------------------------------------- 排行

    /**
     * 排行榜的一行。
     *
     * @param name 落库时记下的名字，可能是旧名。展示时优先用在线玩家的当前名
     */
    record Entry(@NotNull UUID uuid, @Nullable String name, @NotNull BigDecimal balance) {
    }

    /**
     * 余额排行。<b>有缓存</b>（默认 60 秒）——
     * 这是个全表 ORDER BY，让每个点开排行榜的人都真查一次会很难看。
     */
    @NotNull CompletableFuture<List<Entry>> top(int limit);

    // ---------------------------------------------------------------- 便利重载

    default @NotNull BigDecimal balance(@NotNull OfflinePlayer player) {
        return balance(player.getUniqueId());
    }

    default @NotNull CompletableFuture<TxnResult> deposit(@NotNull OfflinePlayer player,
                                                          @NotNull BigDecimal amount,
                                                          @NotNull String reason) {
        return deposit(player.getUniqueId(), amount, reason);
    }

    default @NotNull CompletableFuture<TxnResult> withdraw(@NotNull OfflinePlayer player,
                                                           @NotNull BigDecimal amount,
                                                           @NotNull String reason) {
        return withdraw(player.getUniqueId(), amount, reason);
    }
}
