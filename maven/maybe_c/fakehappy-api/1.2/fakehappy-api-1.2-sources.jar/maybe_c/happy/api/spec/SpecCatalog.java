package maybe_c.happy.api.spec;

import maybe_c.happy.api.game.PartyMode;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import static maybe_c.happy.api.spec.SpecItem.Check.AUTO;
import static maybe_c.happy.api.spec.SpecItem.Check.DECLARED;
import static maybe_c.happy.api.spec.SpecItem.Check.FRAMEWORK;
import static maybe_c.happy.api.spec.SpecItem.Check.MANUAL;
import static maybe_c.happy.api.spec.SpecItem.Level.MAY;
import static maybe_c.happy.api.spec.SpecItem.Level.MUST;
import static maybe_c.happy.api.spec.SpecItem.Level.SHOULD;

/**
 * 《舰长服小游戏制作规范》v1.0 的机器可读版本。
 *
 * <p>这份清单就是 FakeHappy「告诉开发者你还缺什么」的依据 ——
 * 逐条对应规范 12.2 的验收清单，外加几条散落在正文里的硬性要求。
 *
 * <h2>改规范的时候要改这里</h2>
 * 规范文档改了版本，这个类要跟着改，否则检查器报的是旧版要求。
 * <b>ID 不要变</b>：报告、配置里的豁免名单都按 ID 引用。
 *
 * <h2>为什么不做成配置文件</h2>
 * 想过。但这份清单里有一半的项需要框架去<b>反射检查代码</b>
 * （{@link SpecItem.Check#AUTO}），检查逻辑必然写在 Java 里；
 * 把「有哪些项」放 yml、把「怎么查」放代码，两边就会对不上。
 * 规范一年改不了几次，写死在这里反而不会漂。
 */
public final class SpecCatalog {

    private SpecCatalog() {
    }

    /** 规范版本。合规报告里会打出来，方便对账。 */
    public static final String SPEC_VERSION = "v1.0";

    private static final Map<String, SpecItem> BY_ID = new LinkedHashMap<>();

    private static SpecItem add(SpecItem it) {
        BY_ID.put(it.id(), it);
        return it;
    }

    // ================================================================ 流程（12.2.1 / 第四章）

    public static final SpecItem FLOW_NODES = add(new SpecItem(
            "flow.nodes", "4 / 12.2.1", MUST,
            "六节点流程完整：主大厅 → 游戏大厅 → 等待大厅 → 开始 → 结算 → 返回大厅",
            "在 GameCompliance 里声明 flowComplete(true)，并确认每个节点玩家都有明确去处。",
            DECLARED));

    public static final SpecItem FLOW_BACK_TO_HUB = add(new SpecItem(
            "flow.back-to-hub", "4.6 / 12.2.1", MUST,
            "结算后返回「游戏大厅」，不自动开启下一局",
            "结算结束时把玩家送回游戏大厅，不要停在等待大厅直接开下一把 —— "
                    + "玩家要有明确的退出与再选择机会。",
            DECLARED));

    public static final SpecItem FLOW_SETTLEMENT = add(new SpecItem(
            "flow.settlement", "4.5 / 12.2.1", MUST,
            "结算界面展示每位玩家的排名与获得奖励",
            "最省事的做法是走框架结算：descriptor 里 settlement(FRAMEWORK)，"
                    + "一局结束调 api.settlement().settle(...)，界面框架画。"
                    + "自己画的话（settlement(CUSTOM)）要展示排名、关键数据、"
                    + "以及【实际到账】的石粒币与经验 —— 展示请求值的话，"
                    + "玩家会看到「获得 120」然后发现账上没变。",
            DECLARED));


    public static final SpecItem FLOW_BACK_ENTRY = add(new SpecItem(
            "flow.back-entry", "12.2.1", SHOULD,
            "游戏大厅、等待大厅提供明确的「返回上一级」入口",
            "别让玩家只能靠敲命令或者掉线来离开。",
            DECLARED));

    public static final SpecItem FLOW_HUB_NPC = add(new SpecItem(
            "flow.hub-npc", "4.2", MUST,
            "游戏大厅统一使用「NPC + 箱子菜单」进房间",
            "【这是服务器摆放的事，不是游戏代码的事】游戏大厅的 NPC 由运维配置，"
                    + "你的游戏只要正常注册到房间系统里就会出现在那个菜单里。"
                    + "你要做的只有一条：不要在玩家没主动操作时把他塞进房间"
                    + "（队长带队是例外，那条走 PartyService）。",
            FRAMEWORK));

    // ================================================================ 组队（12.2.2 / 第五章）

    public static final SpecItem PARTY_MODE_DECLARED = add(new SpecItem(
            "party.mode", "5", MUST,
            "声明编队形态（SOLO / 4×n / m×n / m×2 / 只送人自行分队）",
            "在 GameDescriptor 里 partyMode(...)。全服组队系统要按形态决定怎么编队，"
                    + "不声明的话它没法处理你的游戏。已经有自己一套分队逻辑的，"
                    + "声明 DELIVER_ONLY —— 框架照样把小队成员送到同一局，"
                    + "只是不替你编队。那也算声明过了 —— 但留空不算。",
            AUTO));

    public static final SpecItem PARTY_FOLLOW = add(new SpecItem(
            "party.follow", "5 / 12.2.2", MUST,
            "全服组队人员可跟随队长子服传送、加入 / 退出房间",
            "【框架负责，你不用写】PartyService 会把队员送到队长所在的子服和房间。"
                    + "你只要在 descriptor 里声明 partyMode，剩下的跨服传送、"
                    + "队员跟随、退队处理都是框架做的。",
            FRAMEWORK, d -> d.partyMode() != null && d.partyMode().needsParty()));

    public static final SpecItem PARTY_4N_SAME_TEAM = add(new SpecItem(
            "party.4n-same-team", "5.1 / 12.2.2", MUST,
            "4×n 游戏中全服队伍进房间后自动编为同一游戏内队伍",
            "别让一支全服队伍被拆到不同队里 —— 那是玩家最直观的「这游戏没适配」。",
            DECLARED, d -> d.partyMode() == PartyMode.FOUR_BY_N));

    public static final SpecItem PARTY_M2_REJECT = add(new SpecItem(
            "party.m2-reject", "5.3 / 12.2.2", MUST,
            "m×2 游戏中两队剩余空位都不足时给出明确失败提示与替代方案",
            "提示要说清楚差多少人，并提供「解散全服队伍后单独加入」和「更换房间」两个选项。",
            DECLARED, d -> d.partyMode() == PartyMode.M_BY_2));

    public static final SpecItem PARTY_LEADER_QUIT = add(new SpecItem(
            "party.leader-quit", "5.4 / 12.2.2", MUST,
            "队长中途退出后队长身份自动转让，队员不受影响",
            "【框架负责，你不用写】PartyService 会把队长转给同队在线时长最长的队员，"
                    + "原队长按普通玩家流程离开，全服队伍保留。"
                    + "自己再实现一套只会和它打架。",
            FRAMEWORK, d -> d.partyMode() != null && d.partyMode().needsParty()));

    // ================================================================ 房间（12.2.3 / 第六章）

    public static final SpecItem ROOM_THREE_TYPES = add(new SpecItem(
            "room.three-types", "6 / 12.2.3", MUST,
            "支持普通、自定义、比赛三种房间类型",
            "GameRoom 上带 RoomType。自定义房就是「与岷同乐」私人房走的类型。",
            AUTO));

    public static final SpecItem ROOM_CUSTOM_NO_REWARD = add(new SpecItem(
            "room.custom-no-reward", "6.2 / 12.2.3", MUST,
            "自定义房间不发放石粒币与经验",
            "结算前查 RoomType.grantsRewards()，别自己按房间名判断。",
            DECLARED));

    public static final SpecItem ROOM_MATCH_REWARD = add(new SpecItem(
            "room.match-reward", "6.3 / 12.2.3", MUST,
            "比赛房间正常结算并发放奖励",
            "比赛房和普通房一样发奖，只是开局要房主手动触发。",
            DECLARED));

    public static final SpecItem ROOM_LIST_FIELDS = add(new SpecItem(
            "room.list-fields", "6.4 / 12.2.3", MUST,
            "房间列表展示：名称/编号、人数/容量、状态、地图",
            "GameRoom 里把 mapName 填上 —— 其余四项框架已经有了。",
            AUTO));

    public static final SpecItem ROOM_NAME_LIMIT = add(new SpecItem(
            "room.name-limit", "6.4", MUST,
            "房间名唯一且长度不超过 16 字符",
            "roomId 别用会重复的自增计数器，重启后会和跨服层里的残留对不上。",
            AUTO));

    public static final SpecItem ROOM_COUNT_BOUNDS = add(new SpecItem(
            "room.count-bounds", "6.4 / 12.2.3", SHOULD,
            "每种模式的房间数量存在上下限",
            "避免空房占用资源，也避免高峰期开不出房。",
            DECLARED));

    // ================================================================ 控制（12.2.4 / 第七章）

    public static final SpecItem CTRL_PAUSE = add(new SpecItem(
            "ctrl.pause", "7 / 12.2.4", MUST,
            "实现「暂停游戏」：冻结全部实体行为与倒计时，HUD 明确显示「已暂停」",
            "覆写 MiniGame.pause(boolean)。恢复后从暂停点继续。",
            AUTO));

    public static final SpecItem CTRL_STOP = add(new SpecItem(
            "ctrl.stop", "7 / 12.2.4", MUST,
            "实现「结束游戏」：关闭房间、踢回游戏大厅、不结算不发奖",
            "MiniGame.forceStop(...)。注意规范定义的语义是「不结算不发奖」，"
                    + "别走正常收局流程。",
            AUTO));

    public static final SpecItem CTRL_RESET = add(new SpecItem(
            "ctrl.reset", "7 / 12.2.4", MUST,
            "实现「重置游戏」：拉回游戏等待大厅重开本局，队伍与职业保持不变",
            "MiniGame.reset()。注意这不是「清场」—— 队伍和职业选择要留着。",
            AUTO));

    public static final SpecItem CTRL_PERMISSION = add(new SpecItem(
            "ctrl.permission", "7 / 12.2.4", MUST,
            "管理指令仅管理员（或自定义/比赛房房主）可用",
            "普通玩家无权触发。框架的场控面板已经做了权限判断，"
                    + "你自己另开的命令也要判。",
            DECLARED));

    // ================================================================ 观战 / 重连 / 中途加入（12.2.4 / 第八章）

    public static final SpecItem SPECTATE = add(new SpecItem(
            "spectate", "8.1 / 12.2.4", MUST,
            "局外观战功能可用，观战者对玩家不可见、不可干扰",
            "覆写 MiniGame.spectate(...)，并在 GameDescriptor 里 spectatable(true)。"
                    + "入口放在游戏大厅的独立 NPC 或菜单项。",
            AUTO));

    public static final SpecItem SPECTATE_CHAT = add(new SpecItem(
            "spectate.chat", "8.1 / 10.2", MUST,
            "观战者聊天与局内玩家聊天隔离",
            "【框架负责，你不用写】GameChatService 把观战者恒定在观战频道，"
                    + "局内玩家收不到、观战者也发不进局内。两个方向都挡 —— "
                    + "只挡一边的话观战者仍能通过「看得见对方说什么」推断局势。",
            FRAMEWORK));

    public static final SpecItem SPECTATE_VIEW = add(new SpecItem(
            "spectate.view", "8.1", MUST,
            "观战者可切换视角至任意在场玩家，默认第三人称",
            "【框架负责，你不用写】进入观战时框架强制切成原版 SPECTATOR —— "
                    + "那本来就是「默认自由视角、点谁进谁的第一人称、Shift 退出」。"
                    + "你自己在 spectate() 里设过也没关系，那一步是幂等的。",
            FRAMEWORK, d -> d.spectatorTakeover()));

    public static final SpecItem SPECTATE_SELF_MANAGED = add(new SpecItem(
            "spectate.self-managed", "8.1", MUST,
            "自管观战：观战者默认第三人称可切视角，且对局内玩家不可见",
            "你在 descriptor 里声明了 spectatorTakeover(false)，框架就不再强制 SPECTATOR、"
                    + "也不再把观战者对场内隐藏 —— 这两条归你自己实现。"
                    + "（观战索引仍然由框架登记，所以聊天隔离、语音闭麦不受影响。）"
                    + "做到了在 compliance 里 done(\"spectate.self-managed\")。",
            DECLARED, d -> !d.spectatorTakeover()));

    public static final SpecItem RECONNECT = add(new SpecItem(
            "reconnect", "8.2 / 12.2.4", SHOULD,
            "支持断线重连，或明确说明不支持的原因",
            "支持的话：有效期默认 120 秒（不得低于 30 秒），重连后恢复位置/血量/物品/"
                    + "队伍/职业，期间名额保留不许别人占。",
            DECLARED));

    public static final SpecItem MIDJOIN = add(new SpecItem(
            "midjoin", "8.3 / 12.2.4", MAY,
            "支持中途加入",
            "支持的话：仅限进度未过半，加入者要拿到与当前平均水平相当的初始资源，"
                    + "对抗类优先补人少的一方。",
            DECLARED));

    // ================================================================ UI（12.2.5 / 第九、十章）

    public static final SpecItem UI_TAB_FOOTER = add(new SpecItem(
            "ui.tab-footer", "9.1 / 12.2.5", MUST,
            "Tab 底部显示 ==游戏名称==（§6 金色，双等号包裹）",
            "用 api.ui().board(plugin, game) 建计分板，框架会自动按规范设 Tab 底部。"
                    + "玩法真占用了原版 Tab 的（如地图类）在 descriptor 里 scoreboardExempt(true)。",
            AUTO, d -> !d.scoreboardExempt()));

    public static final SpecItem UI_SCOREBOARD = add(new SpecItem(
            "ui.scoreboard", "9.1 / 12.2.5", MUST,
            "记分板顶行为游戏名称（§6），底行为 play.zimin.fan（§7）",
            "用 api.ui().board(plugin, game) 建计分板 —— 首尾三处框架锁死，你只给中间内容，"
                    + "所以走样不了，也插不进底行之前。",
            AUTO, d -> !d.scoreboardExempt()));

    public static final SpecItem UI_MESSAGE_PREFIX = add(new SpecItem(
            "ui.message-prefix", "10.1 / 12.2.5", MUST,
            "系统消息使用统一前缀与颜色",
            "走 api.text().sendPrefixed(...)，前缀取自 服务端的样式配置。"
                    + "击杀播报或阶段播报只允许一到两行。",
            DECLARED));

    public static final SpecItem UI_SOUND = add(new SpecItem(
            "ui.sound", "12.2.5", MUST,
            "倒计时最后 5 秒、开始/胜负、击杀事件有对应音效",
            "走 api.text().feedback(player, id)，音效在 服务端的样式配置 里按语义登记，全服一致。",
            DECLARED));

    public static final SpecItem UI_BOSSBAR = add(new SpecItem(
            "ui.bossbar", "12.2.5", SHOULD,
            "BossBar 同时不超过 2 条，ActionBar 提示不超过 3 秒",
            "屏幕顶上挂四条 BossBar 会把玩家的视野吃掉一大半。",
            DECLARED));

    public static final SpecItem UI_CHAT_CHANNEL = add(new SpecItem(
            "ui.chat-channel", "10.2", MUST,
            "聊天频道符合规范：竞技游戏禁止全局聊天，队伍聊天仅同队可见",
            "【框架负责】你只要做两件事：有队伍的游戏覆写 MiniGame.teamOf(...)，"
                    + "竞技游戏在 descriptor 里 competitive(true)。"
                    + "拦事件、按频道路由、观战隔离、禁全局都是 GameChatService 做的。"
                    + "⚠ 竞技游戏没覆写 teamOf 的话队伍频道会退化成全局 —— "
                    + "那等于把报点广播给对手，所以那种情况另有一条自动检测会报错。",
            FRAMEWORK));

    /**
     * 竞技游戏必须能说出「谁和谁是一队」，否则队伍频道无从隔离。
     *
     * <p>单独列一条而不是塞进上面那条的 how 里：这是<b>能自动验</b>的，
     * 而能自动验的东西不该只写在文档里等人读。
     */
    public static final SpecItem UI_CHAT_TEAM_KNOWN = add(new SpecItem(
            "ui.chat-team-known", "10.2", MUST,
            "竞技游戏必须覆写 MiniGame.teamOf(...)",
            "不覆写的话框架不知道谁和谁一队，队伍频道会退化成全局 —— "
                    + "在竞技游戏里那等于把报点广播给对手。",
            AUTO, d -> d.competitive()));

    // ================================================================ 经济（12.2.6 / 第十一章）

    public static final SpecItem ECON_SIGMA = add(new SpecItem(
            "econ.sigma", "11.1 / 12.2.6", MUST,
            "石粒币按 11.1 公式发放，σ 取值有书面记录",
            "在 GameDescriptor 里 sigma(...) 声明，并用 RewardFormula.payout(...) 计算。"
                    + "娱乐 0.5~1.0 / 竞技 1.5~2.5 / 赢家通吃 ≥3.0。",
            AUTO));

    public static final SpecItem ECON_SUM = add(new SpecItem(
            "econ.sum", "11.1 / 12.2.6", MUST,
            "所有玩家石粒币之和 = n × a，不多不少",
            "用 RewardFormula.payout(...) 就是对的 —— 它做了取整余数补偿。"
                    + "自己照公式算很容易差几个币。",
            DECLARED));

    public static final SpecItem ECON_EXP = add(new SpecItem(
            "econ.exp", "11.3 / 12.2.6", MUST,
            "经验按 11.3 发放，胜利 +30% 与 MVP +50% 加成正确叠加",
            "用 RewardFormula.exp(...)。",
            DECLARED));

    public static final SpecItem ECON_NO_REWARD_CUSTOM = add(new SpecItem(
            "econ.custom-no-reward", "11.4 / 12.2.6", MUST,
            "自定义房间不发奖励；中途退出仅得 50% 经验、无石粒币",
            "用 RoomType.grantsRewards() 和 RewardFormula.expQuitEarly(...)。",
            DECLARED));

    public static final SpecItem ECON_DECAY = add(new SpecItem(
            "econ.decay", "11.4 / 12.2.6", MUST,
            "同一房间连开衰减生效（第 4 局 80%、第 7 局 50%）",
            "用 RewardFormula.applyDecay(coins, 连续第几局)。",
            DECLARED));

    public static final SpecItem ECON_ACHIEVEMENT_CAP = add(new SpecItem(
            "econ.achievement-cap", "11.2 / 12.2.6", SHOULD,
            "独立成就奖励总和不超过 n × a 的 50%",
            "上限用 RewardFormula.achievementCap(n, a) 取。",
            DECLARED));

    public static final SpecItem ECON_GRANT_VIA_API = add(new SpecItem(
            "econ.grant-via-api", "第十一章", MUST,
            "奖励一律通过 api.rewards().grant(...) 发放，不自己接经济插件",
            "算出来的数额包成 RewardBundle.of(币, 经验) 交给 grant(...)，"
                    + "第三个参数写 <游戏id>:<事由>（会进发放流水，事后能查）。\n"
                    + "不要自己去 hook Vault、也不要自己建等级表 —— 那样做有三个后果：\n"
                    + "  1) 你的 jar 就和某一个服绑死了。走 rewards() 的话同一个 jar "
                    + "石粒币、石粒等级、贡献积分的发放口径都归这一层管；\n"
                    + "  2) 发出去的东西不进 fh_reward_log，「凭什么给他这么多」查不了；\n"
                    + "  3) 经济插件没装时你会拿到 null 或者异常，而 grant(...) 是"
                    + "「能发的都发掉、发不掉的记进 skipped」，玩家该拿的经验不会因为币发不出去就跟着没了。\n"
                    + "展示奖励时用 GrantResult.granted() 而不是自己请求的数，"
                    + "玩家看到的就永远和实际到账一致；名字用 api.rewards().nameOf(kind) 取，"
                    + "别在代码里写死「石粒币」三个字。",
            DECLARED));

    // ================================================================ 美术（第三章）

    public static final SpecItem ART_ORIGINALITY = add(new SpecItem(
            "art.originality", "3.2 / 3.8", MUST,
            "非复刻游戏美术资产原创度 ≥ 70%",
            "框架验不了。上线前按 3.8 清单人工审核。",
            MANUAL));

    public static final SpecItem ART_NO_FOREIGN_NAME = add(new SpecItem(
            "art.no-foreign-name", "3.2 / 3.8", MUST,
            "全服搜索无其它游戏的名称、Logo、专有术语",
            "包括物品名、职业名、公告、NPC 对白、地图介绍。复刻模式除外。",
            MANUAL));

    public static final SpecItem ART_SOURCE = add(new SpecItem(
            "art.source", "3.5 / 3.8", MUST,
            "所有美术资产已完成来源登记，可提供出处清单",
            "原创 / 商业授权 / 开源协议 / AI 辅助，四类都要能追溯。",
            MANUAL));

    public static final SpecItem ART_STYLE = add(new SpecItem(
            "art.style", "3.6 / 3.8", SHOULD,
            "同一游戏内美术风格统一，UI 与舰长服整体基调协调",
            "像素风、写实风、卡通风不得混用。关键区分色不要只靠颜色（色弱可读性）。",
            MANUAL));

    // ================================================================ 查询

    /** 全部检查项，按声明顺序。 */
    public static @NotNull List<SpecItem> all() {
        return List.copyOf(BY_ID.values());
    }

    public static @Nullable SpecItem byId(@NotNull String id) {
        return BY_ID.get(id);
    }

    /** 「必须」项的数量。报告里打「x/y 必须项通过」用。 */
    public static long mandatoryCount() {
        return BY_ID.values().stream().filter(i -> i.level() == MUST).count();
    }
}
