package maybe_c.happy.api.reward;

import org.jetbrains.annotations.NotNull;

import java.util.EnumSet;
import java.util.Set;

/**
 * 一次 {@link RewardService#grant} 的结果。
 *
 * <h2>为什么「发一半」是正常结果而不是异常</h2>
 * 本服可能没装 Vault，或者等级系统被运维关掉了。这时候把整个发放
 * 回滚掉、或者抛异常让小游戏自己处理，都是错的 ——
 * 玩家该拿的经验不能因为「币发不出去」就跟着没了。
 *
 * <p>所以：<b>能发的都发掉</b>，发不掉的记在 {@link #skipped()} 里。
 * 小游戏一般不用管；要展示「你获得了 X」的时候读 {@link #granted()}
 * 而不是自己请求的数，玩家看到的就永远和实际到账一致。
 */
public record GrantResult(@NotNull RewardBundle requested,
                          @NotNull RewardBundle granted,
                          @NotNull Set<RewardKind> skipped,
                          int levelBefore,
                          int levelAfter,
                          int pointsLevelBefore,
                          int pointsLevelAfter) {

    public GrantResult {
        skipped = skipped.isEmpty() ? Set.of() : Set.copyOf(skipped);
    }

    /** 什么都没发（一般是 {@link RewardBundle#isEmpty()} 或者服务整体不可用）。 */
    public static @NotNull GrantResult nothing(@NotNull RewardBundle requested,
                                               @NotNull Set<RewardKind> skipped) {
        return new GrantResult(requested, RewardBundle.NOTHING, skipped, 0, 0, 0, 0);
    }

    /** 请求的三项一项不落全发到了。 */
    public boolean complete() {
        return skipped.isEmpty();
    }

    /** 这次发放让玩家升级了。跨多级也只算一次。 */
    public boolean leveledUp() {
        return levelAfter > levelBefore;
    }

    public boolean pointsLeveledUp() {
        return pointsLevelAfter > pointsLevelBefore;
    }

    /** 哪些项因为后端缺失被丢了。空集表示全发到了。 */
    public @NotNull Set<RewardKind> missing() {
        return skipped.isEmpty() ? EnumSet.noneOf(RewardKind.class) : EnumSet.copyOf(skipped);
    }
}
