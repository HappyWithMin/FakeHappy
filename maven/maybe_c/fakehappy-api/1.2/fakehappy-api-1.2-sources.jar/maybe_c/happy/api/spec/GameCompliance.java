package maybe_c.happy.api.spec;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

/**
 * 小游戏对规范检查项的<b>自查声明</b>。
 *
 * <p>规范里有一半的项框架验不了 —— 「结算界面有没有展示排名」「观战者能不能切视角」
 * 这些只有写的人知道。所以由开发者显式声明。
 *
 * <h2>默认是「没做」</h2>
 * 不声明 = 未实现。这是有意的：默认「已实现」的话，一个从来没读过规范的人
 * 注册进来会显示满分，那这套检查就没有意义了。
 *
 * <h2>声明不等于验收通过</h2>
 * 声明只代表<b>开发者这么说</b>。合规报告会把这类项标成「需声明」而不是「已验证」，
 * 上线验收仍然要人工过一遍 12.2 清单。框架的价值是<b>让人知道哪些还没做</b>，
 * 不是替代验收。
 *
 * <pre>{@code
 * GameCompliance.builder()
 *         .done("flow.back-to-hub", "flow.settlement", "room.custom-no-reward")
 *         .notApplicable("midjoin", "一局 90 秒，中途进来没意义")
 *         .notApplicable("reconnect", "单局太短，重连窗口比一局还长")
 *         .build();
 * }</pre>
 */
public final class GameCompliance {

    private static final GameCompliance EMPTY = builder().build();

    private final Set<String> done;
    private final Map<String, String> notApplicable;

    private GameCompliance(Builder b) {
        this.done = Set.copyOf(b.done);
        this.notApplicable = Map.copyOf(b.notApplicable);
    }

    /** 什么都没声明。{@code MiniGame.compliance()} 的默认返回值。 */
    public static @NotNull GameCompliance none() {
        return EMPTY;
    }

    public static @NotNull Builder builder() {
        return new Builder();
    }

    /** 开发者声明「这条我做了」。 */
    public boolean isDone(@NotNull String itemId) {
        return done.contains(itemId);
    }

    /** 开发者声明「这条对我不适用」，返回理由；没声明则返回 null。 */
    public @Nullable String notApplicableReason(@NotNull String itemId) {
        return notApplicable.get(itemId);
    }

    public boolean isNotApplicable(@NotNull String itemId) {
        return notApplicable.containsKey(itemId);
    }

    public @NotNull Set<String> declaredDone() {
        return done;
    }

    public @NotNull Map<String, String> declaredNotApplicable() {
        return notApplicable;
    }

    public static final class Builder {
        private final java.util.Set<String> done = new java.util.LinkedHashSet<>();
        private final Map<String, String> notApplicable = new LinkedHashMap<>();

        /**
         * 声明这些检查项已实现。ID 见 {@link SpecCatalog}。
         *
         * <p>写错的 ID 会在合规报告里被单独列出来提醒 —— 不会静默忽略，
         * 否则一个手滑的拼写会让人以为自己声明过了。
         */
        public @NotNull Builder done(@NotNull String... itemIds) {
            java.util.Collections.addAll(done, itemIds);
            return this;
        }

        /**
         * 声明这条对本游戏不适用，<b>必须给理由</b>。
         *
         * <p>只对「应当」和「可选」项有效。「必须」项声明不适用不会被接受 ——
         * 报告里仍然算缺失，因为那是全服统一的硬要求，个别游戏说不适用不作数。
         *
         * @param reason 一句话说清为什么。会原样出现在合规报告里给验收的人看
         */
        public @NotNull Builder notApplicable(@NotNull String itemId, @NotNull String reason) {
            notApplicable.put(itemId, reason);
            return this;
        }

        public @NotNull GameCompliance build() {
            return new GameCompliance(this);
        }
    }
}
