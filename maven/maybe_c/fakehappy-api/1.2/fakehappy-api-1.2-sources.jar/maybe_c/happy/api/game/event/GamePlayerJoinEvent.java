package maybe_c.happy.api.game.event;

import maybe_c.happy.api.game.MiniGame;
import net.kyori.adventure.text.Component;
import org.bukkit.entity.Player;
import org.bukkit.event.Cancellable;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/**
 * 玩家即将加入某局小游戏。在 {@code MiniGame.canJoin} 通过之后、
 * {@code MiniGame.join} 之前触发。
 *
 * <p>取消时请顺手 {@link #setDenyReason} 说明原因，否则玩家只会看到一句
 * 干巴巴的默认提示，运维排查也无从下手。
 */
public class GamePlayerJoinEvent extends Event implements Cancellable {

    private static final HandlerList HANDLERS = new HandlerList();

    private final Player player;
    private final MiniGame game;
    private boolean cancelled;
    private Component denyReason;

    public GamePlayerJoinEvent(@NotNull Player player, @NotNull MiniGame game) {
        this.player = player;
        this.game = game;
    }

    public @NotNull Player player() {
        return player;
    }

    public @NotNull MiniGame game() {
        return game;
    }

    /** 取消时展示给玩家的理由。 */
    public @Nullable Component denyReason() {
        return denyReason;
    }

    public void setDenyReason(@Nullable Component denyReason) {
        this.denyReason = denyReason;
    }

    @Override
    public boolean isCancelled() {
        return cancelled;
    }

    @Override
    public void setCancelled(boolean cancel) {
        this.cancelled = cancel;
    }

    @Override
    public @NotNull HandlerList getHandlers() {
        return HANDLERS;
    }

    public static @NotNull HandlerList getHandlerList() {
        return HANDLERS;
    }
}
