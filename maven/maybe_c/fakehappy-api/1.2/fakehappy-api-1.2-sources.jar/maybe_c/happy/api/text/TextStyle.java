package maybe_c.happy.api.text;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextColor;
import org.jetbrains.annotations.NotNull;

/**
 * 全服统一视觉风格。<b>「风格对齐」靠的就是所有小游戏都从这里取色和取图标，
 * 而不是各自硬编码 {@code &b}。</b>
 *
 * <p>所有取值都来自 服务端的样式配置，改一次配置全服（含所有附属小游戏）一起变，
 * 换资源包 / 换主题不需要重新编译任何插件。
 */
public interface TextStyle {

    // ------------------------------------------------------------ 配色

    /** 品牌主色。标题、强调项。 */
    @NotNull TextColor brand();

    /** 次要强调色，用于数值、玩家名。 */
    @NotNull TextColor accent();

    /** 正文色。 */
    @NotNull TextColor body();

    /** 弱化色，用于说明文字、次要信息。 */
    @NotNull TextColor muted();

    /** 成功 / 正向。 */
    @NotNull TextColor ok();

    /** 警告。 */
    @NotNull TextColor warn();

    /** 错误 / 拒绝。 */
    @NotNull TextColor error();

    /**
     * 按语义名取色，取不到时返回 {@link #body()}。
     * 给「颜色名写在配置里」的场景用，比如小游戏自己的 messages.yml。
     */
    @NotNull TextColor color(@NotNull String semanticName);

    // ------------------------------------------------------------ 图标

    /**
     * 按语义 ID 取一个图标 Component。
     *
     * <p>配置里既可以填 sprite（{@code <sprite:minecraft:icon/heart/full>}），
     * 也可以填资源包自定义字体的私用区字符，还可以退化成一个纯文本符号。
     * 调用方只认 ID，不关心底下是哪种实现 —— 这样以后上了自定义资源包，
     * 改 服务端的样式配置 就能让所有小游戏的图标一起换掉。
     *
     * @param iconId 如 {@code heart} / {@code coin} / {@code crown} / {@code warn}
     * @return 取不到时返回 {@link Component#empty()}，绝不返回 null，也不抛异常
     */
    @NotNull Component icon(@NotNull String iconId);

    // ------------------------------------------------------------ 渐变

    /** 品牌渐变的起点色。 */
    @NotNull TextColor gradientFrom();

    /** 品牌渐变的终点色。 */
    @NotNull TextColor gradientTo();

    /**
     * 给一段文本刷上品牌渐变。标题、面板抬头、分段标题用它。
     *
     * <p><b>只用在短文本上。</b>渐变是按字符插值的：一整段话刷渐变，每个字颜色都差一点，
     * 读起来累，而且在 TAB / 计分板这类窄容器里会糊成一片。
     * 正文该是白 + 灰，靠留白和图标分层，不是靠颜色。
     */
    @NotNull Component gradient(@NotNull String text);

    /** 系统消息前缀（已含尾随空格）。 */
    @NotNull Component prefix();

    /** 分隔线，用于 /help 之类的分段。 */
    @NotNull Component separator();

    /**
     * 统一样式的正文行：{@code prefix + body}。
     * 小游戏发系统提示统一走这个，玩家看到的前缀就永远一致。
     */
    @NotNull Component line(@NotNull Component body);
}
