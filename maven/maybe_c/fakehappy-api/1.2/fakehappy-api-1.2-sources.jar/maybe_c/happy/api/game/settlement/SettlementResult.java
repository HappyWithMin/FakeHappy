package maybe_c.happy.api.game.settlement;

import maybe_c.happy.api.reward.GrantResult;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * 结算的结果。
 *
 * <p><b>展示奖励时用这里的数，不要用你请求的数</b> —— 币可能因为自定义房、
 * 连开衰减、或者经济后端不可用而和「本该发多少」不一样。
 * 用实际到账的数，玩家看到的就永远和他账上的一致。
 * （框架自己画的结算界面已经这么做了，这份结果是给你事后记日志 / 发成就用的。）
 *
 * @param paid     每个玩家实际拿到的币与经验
 * @param rewarded 本局到底发没发奖。自定义房是 false
 * @param note     没发奖时的原因，给日志用；发了就是 null
 */
@ApiStatus.Experimental
public record SettlementResult(
        @NotNull Map<UUID, Payout> paid,
        boolean rewarded,
        @Nullable String note
) {

    /**
     * 一个人实际拿到的东西。
     *
     * @param coins  实际到账的石粒币（已经过衰减、自定义房归零）
     * @param exp    实际到账的经验
     * @param grant  底层发放结果。{@code skipped()} 里能看到「哪一项没发出去」，
     *               比如没装 Vault 时币发不掉但经验照常
     */
    public record Payout(int coins, int exp, @Nullable GrantResult grant) {
    }

    public @NotNull List<UUID> players() {
        return List.copyOf(paid.keySet());
    }
}
