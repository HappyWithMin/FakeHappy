package maybe_c.happy.api.module;

import org.bukkit.plugin.Plugin;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Collection;
import java.util.Optional;

/**
 * 模块注册与生命周期管理。
 *
 * <p>附属插件通常<b>不需要</b>用这个 —— 自己的功能自己在 onEnable/onDisable 里管就行。
 * 只有当你希望自己的功能出现在 {@code /fh module list}、能被 OP 在游戏内单独开关、
 * 并且跟着 FakeHappy 一起热重载时，才值得注册进来。
 */
public interface ModuleManager {

    /**
     * 注册一个模块。注册后不会立刻启用，会按依赖顺序在下一次 {@link #enableAll()}
     * 或立即（如果框架已经启动完毕）启用。
     *
     * @param owner 拥有者插件。该插件被卸载时它注册的模块会一起下线
     * @throws IllegalArgumentException id 重复
     */
    void register(@NotNull Plugin owner, @NotNull HappyModule module);

    /** 注销并关闭。id 不存在时静默返回 false。 */
    boolean unregister(@NotNull String moduleId);

    /** 注销某个插件注册的所有模块。FakeHappy 会在 PluginDisableEvent 时自动调用。 */
    void unregisterAll(@NotNull Plugin owner);

    @NotNull Optional<HappyModule> get(@NotNull String moduleId);

    /** 按注册顺序返回所有模块（含未启用的）。返回的是快照，可以安全遍历。 */
    @NotNull Collection<HappyModule> all();

    @NotNull ModuleState stateOf(@NotNull String moduleId);

    /** 上一次启用失败的原因；没失败过返回 null。 */
    @Nullable Throwable failureOf(@NotNull String moduleId);

    /**
     * 手动启用。会先递归启用它 {@code dependsOn} 的模块。
     *
     * @return 是否处于 ENABLED（本来就开着也算 true）
     */
    boolean enable(@NotNull String moduleId);

    /**
     * 手动关闭。<b>依赖它的模块会先被一起关掉</b>，避免留下悬空引用。
     */
    boolean disable(@NotNull String moduleId);

    /** 热重载单个模块。 */
    boolean reload(@NotNull String moduleId);

    /** 按依赖拓扑序启用所有 {@code enabled=true} 的模块。 */
    void enableAll();

    /** 按拓扑逆序关闭所有模块。FakeHappy 的 onDisable 走这个。 */
    void disableAll();
}
