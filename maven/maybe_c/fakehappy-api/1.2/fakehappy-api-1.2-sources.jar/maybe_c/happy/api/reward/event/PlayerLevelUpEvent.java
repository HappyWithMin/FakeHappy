package maybe_c.happy.api.reward.event;

import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;
import org.jetbrains.annotations.NotNull;

/**
 * 玩家等级提升（舰长服「石粒等级」）。<b>在主线程触发。</b>
 *
 * <h2>跨多级只触发一次</h2>
 * 一次结算发了一大笔经验、从 3 级直接跳到 6 级，只会触发一次，
 * {@code from=3, to=6}。要对中间每一级都做点什么，自己遍历
 * {@code from+1 .. to} —— 触发 4 次事件会让「升级音效」响 4 遍。
 *
 * <h2>不可取消</h2>
 * 经验已经加进去了，取消事件也退不回来。要控制「谁能拿经验」，
 * 在发放前就别发。
 */
public class PlayerLevelUpEvent extends Event {

    private static final HandlerList HANDLERS = new HandlerList();

    private final Player player;
    private final int from;
    private final int to;
    private final long totalExp;

    public PlayerLevelUpEvent(@NotNull Player player, int from, int to, long totalExp) {
        this.player = player;
        this.from = from;
        this.to = to;
        this.totalExp = totalExp;
    }

    public @NotNull Player player() {
        return player;
    }

    /** 升级前的等级。 */
    public int from() {
        return from;
    }

    /** 升级后的等级。 */
    public int to() {
        return to;
    }

    /** 这一跳跨了几级。 */
    public int levelsGained() {
        return to - from;
    }

    /** 升级后的累计总经验。 */
    public long totalExp() {
        return totalExp;
    }

    @Override
    public @NotNull HandlerList getHandlers() {
        return HANDLERS;
    }

    public static @NotNull HandlerList getHandlerList() {
        return HANDLERS;
    }
}
