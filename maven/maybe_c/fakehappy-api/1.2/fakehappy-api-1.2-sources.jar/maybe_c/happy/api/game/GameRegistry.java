package maybe_c.happy.api.game;

import net.kyori.adventure.text.Component;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Collection;
import java.util.Optional;
import java.util.UUID;

/**
 * 全服小游戏注册表。
 *
 * <p>注册进来的游戏才会被大厅 UI、OP 场控、可见性隔离、跨服排队看见。
 * <b>没注册的小游戏对本插件而言不存在</b>，它的参与者在大厅保护眼里就是普通玩家，
 * 会被拦下攻击、不会被隔离可见性 —— 这是很多「为什么我的小游戏在大厅里打不了人」
 * 的根因。
 *
 * <pre>{@code
 * // 在你自己插件的 onEnable 里
 * HappyApi api = Happy.api();
 * api.games().register(this, new MySpleefGame(api));
 *
 * // onDisable 不用手动注销 —— 框架监听 PluginDisableEvent 会自动清理
 * }</pre>
 */
public interface GameRegistry {

    /**
     * 注册一个小游戏。
     *
     * @param owner 拥有者插件。它被卸载时这个游戏会自动 {@link MiniGame#reset()} 并注销
     * @throws IllegalArgumentException descriptor id 与已注册的重复
     */
    void register(@NotNull Plugin owner, @NotNull MiniGame game);

    /**
     * 注销。会先把所有参与者请出去，再调一次 {@link MiniGame#reset()}。
     *
     * @return 是否真的注销了某个游戏
     */
    boolean unregister(@NotNull String gameId);

    /** 注销某插件注册的全部游戏。 */
    void unregisterAll(@NotNull Plugin owner);

    @NotNull Optional<MiniGame> get(@NotNull String gameId);

    /** 所有已注册的游戏。返回快照，遍历期间别人注册 / 注销不会导致并发异常。 */
    @NotNull Collection<MiniGame> all();

    /** 按 {@link GameDescriptor#category()} 过滤。 */
    @NotNull Collection<MiniGame> byCategory(@NotNull String category);

    /**
     * 取某个游戏最近一次的合规报告 —— 「照规范它还缺什么」。
     *
     * <p>注册时自动生成一次。想拿最新的（比如开了几局之后房间相关的项才有得查）
     * 用 {@link #recheck}。
     *
     * @return 游戏不存在时是空 Optional
     */
    @NotNull Optional<maybe_c.happy.api.spec.SpecReport> report(@NotNull String gameId);

    /** 重新跑一遍合规检查并更新报告。 */
    @NotNull Optional<maybe_c.happy.api.spec.SpecReport> recheck(@NotNull String gameId);

    // ------------------------------------------------------------ 玩家归属

    /**
     * 这个玩家现在在哪个游戏里（作为参与者）。
     *
     * <p>大厅保护、可见性隔离、传送拦截都问这个。实现里维护的是一张
     * {@code UUID -> MiniGame} 反向索引，是 O(1)，可以放心在事件里高频调用。
     */
    @NotNull Optional<MiniGame> gameOf(@NotNull UUID playerId);

    default @NotNull Optional<MiniGame> gameOf(@NotNull Player player) {
        return gameOf(player.getUniqueId());
    }

    /** 这个玩家在哪个游戏里旁观。 */
    @NotNull Optional<MiniGame> spectatingGameOf(@NotNull UUID playerId);

    /**
     * 玩家是不是正处在一局<b>进行中</b>的游戏里
     * （{@link GameState#inProgress()}）。这是判断「该不该豁免大厅保护」的标准问法。
     */
    boolean isInProgressGame(@NotNull UUID playerId);

    /** 两个玩家是不是在同一局游戏里。可见性隔离用它决定谁该看见谁。 */
    boolean sameGame(@NotNull UUID a, @NotNull UUID b);

    // ------------------------------------------------------------ 状态变更

    /**
     * 上报状态变化。<b>小游戏改状态必须走这里</b>，不能只改自己的字段。
     *
     * <p>框架会：发 {@code GameStateChangeEvent}、刷新所有打开着的相关 UI、
     * 更新跨服房间信息、按需调整参与者的可见性隔离。
     *
     * @return 是否被监听器取消
     */
    boolean setState(@NotNull MiniGame game, @NotNull GameState newState);

    /**
     * 让玩家加入某个游戏 —— <b>调用方应该走这个，而不是直接调
     * {@link MiniGame#join}</b>。这里会依次做：查 {@link MiniGame#canJoin}、
     * 发可取消的 {@code GamePlayerJoinEvent}、调 {@code join}、
     * 登记反向索引、应用可见性隔离。
     *
     * @return 拒绝理由；null = 加入成功
     */
    @Nullable Component join(@NotNull Player player, @NotNull MiniGame game);

    /**
     * 让玩家加入<b>指定的</b>那一局，其余与 {@link #join} 完全一致。
     *
     * <p>跨服排队把人分配过来时框架走这里。为什么不能直接调
     * {@link MiniGame#joinRoom}：那样绕过了反向索引，玩家人在局里、
     * 注册表却不知道 —— 表现是他掉线时没人替他 {@code quit}（局里留一个幽灵）、
     * {@code /fhleave} 说他不在任何游戏里、{@code %fh_ingame%} 是 false、
     * 大厅保护也不认他。本文档第七章那条「进出走 GameRegistry」对框架自己一样适用。
     *
     * @param roomId 目标房间 ID，转交给 {@link MiniGame#joinRoom}
     * @return 拒绝理由；null = 加入成功
     */
    @Nullable Component joinRoom(@NotNull Player player, @NotNull MiniGame game,
                                 @NotNull String roomId);

    /**
     * 让玩家以<b>旁观</b>身份进入某个游戏 —— 和 {@link #join} 一样，
     * <b>调用方应该走这个，而不是直接调 {@link MiniGame#spectate}</b>。
     *
     * <p>这里会：查 {@code descriptor().spectatable()}、调 {@code spectate}、
     * 登记旁观索引（{@link #spectatingGameOf} 靠它）、按规范 8.1 应用可见性 ——
     * <b>旁观者看得见场内玩家，场内玩家看不见旁观者</b>。
     *
     * <p>绕过去的后果和 join 一样：{@code spectatingGameOf} 查不到人，
     * 而 {@code isolateVisibility(true)} 的游戏会把旁观者和场内玩家<b>互相</b>隐藏，
     * 也就是他什么都看不到。
     *
     * <p>退出旁观走 {@link #quit}，和参与者用的是同一个方法。
     *
     * @return 拒绝理由；null = 开始旁观
     */
    @Nullable Component spectate(@NotNull Player player, @NotNull MiniGame game);

    /**
     * 让玩家离开他当前所在的游戏。不在任何游戏里时什么都不做。
     * 同样会处理反向索引与可见性恢复。
     */
    void quit(@NotNull UUID playerId);
}
