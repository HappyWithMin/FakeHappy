package maybe_c.happy.api.game.settlement;

import maybe_c.happy.api.game.MiniGame;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.NotNull;

import java.util.concurrent.CompletableFuture;

/**
 * 一局结束时把结果交给框架，剩下的它来做。
 *
 * <pre>{@code
 * api.settlement().settle(this, Settlement.builder()
 *         .minutes(elapsedMinutes)
 *         .room(room.id())
 *         .add(Placement.of(winner, 1).won().mvp().stat("击杀", 7))
 *         .add(Placement.of(second, 2).stat("击杀", 4))
 *         .add(Placement.of(leaver, 3).quitEarly())
 *         .build());
 * }</pre>
 *
 * <p>就这些。<b>不要自己算币、不要自己发奖、不要自己把人传回大厅</b> ——
 * 这三件事的规则写在《舰长服小游戏制作规范》第四、六、十一章里，
 * 每个游戏各实现一遍的结果是每个游戏都对一部分。
 *
 * <h2>它做了什么</h2>
 * 见 {@link Settlement} 的类注释，六件事。其中五件对应规范里的「必须」项 ——
 * 声明 {@code settlementMode(FRAMEWORK)} 并调这个方法，那五条自动通过。
 *
 * <h2>线程</h2>
 * <b>在主线程调用。</b>返回的 future 在异步线程完成（发奖要落库），
 * 回调里要碰 Bukkit 的话自己切回来。
 */
@ApiStatus.Experimental
public interface SettlementService {

    /**
     * 结算一局。
     *
     * @param game       哪个游戏。用来取 σ、人均基数、以及记「这个游戏走了框架结算」
     * @param settlement 名次与本局信息
     * @return 每个人实际拿到了什么
     */
    @NotNull CompletableFuture<SettlementResult> settle(@NotNull MiniGame game,
                                                        @NotNull Settlement settlement);
}
