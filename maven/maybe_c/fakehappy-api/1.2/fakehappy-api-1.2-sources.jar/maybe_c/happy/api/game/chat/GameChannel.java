package maybe_c.happy.api.game.chat;

import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.NotNull;

/**
 * 局内聊天频道（规范 10.2）。
 *
 * <p>规范对三类游戏的要求不一样：
 * <ul>
 *   <li><b>娱乐游戏</b>：默认全局，玩家可以切到队伍</li>
 *   <li><b>竞技游戏</b>：默认队伍，<b>禁止全局</b> —— 不然对手能听见你报点</li>
 *   <li><b>观战者</b>：独立频道，和局内玩家互不可见</li>
 * </ul>
 *
 * <p>在 {@code GameDescriptor} 里 {@code competitive(true)} 之后，
 * 框架自动按竞技规则处理，你不用写任何聊天代码。
 */
@ApiStatus.Experimental
public enum GameChannel {

    /** 全场可见（含观战者）。竞技游戏禁用。 */
    GLOBAL("全局"),

    /**
     * 只有同队看得见。队伍由 {@code MiniGame.teamOf(uuid)} 决定 ——
     * 没有队伍概念的游戏（返回 null）会退回 {@link #GLOBAL}。
     */
    TEAM("队伍"),

    /**
     * 观战者之间。<b>局内玩家看不见</b> ——
     * 否则观战者能给场上的人报点，那和开挂没区别。
     */
    SPECTATOR("观战");

    private final String display;

    GameChannel(String display) {
        this.display = display;
    }

    public @NotNull String display() {
        return display;
    }
}
