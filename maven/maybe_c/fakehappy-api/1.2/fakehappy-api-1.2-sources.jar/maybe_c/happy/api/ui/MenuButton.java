package maybe_c.happy.api.ui;

import net.kyori.adventure.text.Component;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Predicate;

/**
 * 一个按钮的<b>呈现无关</b>定义。同一个实例既能被箱子界面画成物品，
 * 也能被 Dialog 画成 ActionButton —— 这就是「Dialog 和箱子 UI 可混合搭配」
 * 却不用把逻辑写两遍的原因。
 *
 * <p>不可变。用 {@link #builder(Component)} 构造，{@link #toBuilder()} 派生变体。
 *
 * <pre>{@code
 * MenuButton start = MenuButton.builder(text.parse("<ok>开始游戏"))
 *         .tooltip(text.parse("<muted>人数够了就能开"))
 *         .icon(new ItemStack(Material.LIME_CONCRETE))
 *         .visibleIf(p -> p.hasPermission("yourgame.admin"))
 *         .enabledIf(p -> game.players().size() >= game.minPlayers())
 *         .disabledReason("人数不足")
 *         .onClick(ctx -> game.forceStart(ctx.player()))
 *         .build();
 * }</pre>
 */
public final class MenuButton {

    private final Component label;
    private final List<Component> tooltip;
    private final ItemStack icon;
    private final Consumer<ClickContext> onClick;
    private final Predicate<Player> visibleIf;
    private final Predicate<Player> enabledIf;
    private final String disabledReason;
    private final boolean glow;
    private final String feedbackId;

    private MenuButton(Builder b) {
        this.label = b.label;
        this.tooltip = List.copyOf(b.tooltip);
        this.icon = b.icon == null ? null : b.icon.clone();
        this.onClick = b.onClick;
        this.visibleIf = b.visibleIf;
        this.enabledIf = b.enabledIf;
        this.disabledReason = b.disabledReason;
        this.glow = b.glow;
        this.feedbackId = b.feedbackId;
    }

    public static @NotNull Builder builder(@NotNull Component label) {
        return new Builder(label);
    }

    /** 纯装饰用的占位按钮（无点击、无 tooltip）。箱子界面的填充格用它。 */
    public static @NotNull MenuButton filler(@NotNull ItemStack icon) {
        return builder(Component.empty()).icon(icon).build();
    }

    public @NotNull Component label() {
        return label;
    }

    public @NotNull List<Component> tooltip() {
        return tooltip;
    }

    /** 箱子界面用的图标；Dialog 呈现时忽略。返回的是副本。 */
    public @Nullable ItemStack icon() {
        return icon == null ? null : icon.clone();
    }

    public @Nullable Consumer<ClickContext> onClick() {
        return onClick;
    }

    /** 是否发光（箱子界面加附魔光效，Dialog 下无效果）。 */
    public boolean glow() {
        return glow;
    }

    /** 点击时播放的音效语义 id；null 表示用框架默认的 click。 */
    public @Nullable String feedbackId() {
        return feedbackId;
    }

    /** 该玩家能否看见这个按钮。 */
    public boolean visibleTo(@NotNull Player p) {
        return visibleIf == null || visibleIf.test(p);
    }

    /** 该玩家点得动吗。看得见但点不动时会灰掉并显示 {@link #disabledReason()}。 */
    public boolean enabledFor(@NotNull Player p) {
        return enabledIf == null || enabledIf.test(p);
    }

    public @Nullable String disabledReason() {
        return disabledReason;
    }

    public @NotNull Builder toBuilder() {
        Builder b = new Builder(label);
        b.tooltip.addAll(tooltip);
        b.icon = icon;
        b.onClick = onClick;
        b.visibleIf = visibleIf;
        b.enabledIf = enabledIf;
        b.disabledReason = disabledReason;
        b.glow = glow;
        b.feedbackId = feedbackId;
        return b;
    }

    public static final class Builder {
        private final Component label;
        private final List<Component> tooltip = new ArrayList<>(2);
        private ItemStack icon;
        private Consumer<ClickContext> onClick;
        private Predicate<Player> visibleIf;
        private Predicate<Player> enabledIf;
        private String disabledReason;
        private boolean glow;
        private String feedbackId;

        private Builder(Component label) {
            this.label = label == null ? Component.empty() : label;
        }

        /** 追加一行 tooltip / lore。 */
        public @NotNull Builder tooltip(@NotNull Component line) {
            this.tooltip.add(line);
            return this;
        }

        public @NotNull Builder tooltip(@NotNull List<Component> lines) {
            this.tooltip.addAll(lines);
            return this;
        }

        /** 箱子界面的图标。传进来的 ItemStack 会被复制，之后改原对象不影响按钮。 */
        public @NotNull Builder icon(@Nullable ItemStack icon) {
            this.icon = icon;
            return this;
        }

        /**
         * 点击回调。<b>不设 = 这是个不可点的装饰按钮</b>，
         * 箱子界面下点它不会有任何反应，也不会有音效。
         */
        public @NotNull Builder onClick(@Nullable Consumer<ClickContext> onClick) {
            this.onClick = onClick;
            return this;
        }

        /** 条件不满足时按钮整个不出现（箱子界面下槽位留空）。 */
        public @NotNull Builder visibleIf(@Nullable Predicate<Player> p) {
            this.visibleIf = p;
            return this;
        }

        /** 条件不满足时按钮仍显示但点不动，并提示 {@link #disabledReason(String)}。 */
        public @NotNull Builder enabledIf(@Nullable Predicate<Player> p) {
            this.enabledIf = p;
            return this;
        }

        public @NotNull Builder disabledReason(@Nullable String reason) {
            this.disabledReason = reason;
            return this;
        }

        public @NotNull Builder glow(boolean glow) {
            this.glow = glow;
            return this;
        }

        public @NotNull Builder feedback(@Nullable String feedbackId) {
            this.feedbackId = feedbackId;
            return this;
        }

        public @NotNull MenuButton build() {
            return new MenuButton(this);
        }
    }
}
