package maybe_c.happy.api.game.event;

import maybe_c.happy.api.game.MiniGame;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.UUID;

/**
 * 玩家已经离开某局小游戏。<b>不可取消</b> —— 走到这一步人已经出去了，
 * 让监听器把人留下只会造成状态不一致。
 *
 * <p>{@link #player()} 可能为 null（玩家掉线时框架也会发这个事件），
 * 所以要用玩家对象的话必须判空，只要身份的话用 {@link #playerId()}。
 */
public class GamePlayerQuitEvent extends Event {

    private static final HandlerList HANDLERS = new HandlerList();

    private final UUID playerId;
    private final Player player;
    private final MiniGame game;
    private final Reason reason;

    public GamePlayerQuitEvent(@NotNull UUID playerId, @Nullable Player player,
                               @NotNull MiniGame game, @NotNull Reason reason) {
        this.playerId = playerId;
        this.player = player;
        this.game = game;
        this.reason = reason;
    }

    public @NotNull UUID playerId() {
        return playerId;
    }

    /** 玩家已离线时为 null。 */
    public @Nullable Player player() {
        return player;
    }

    public @NotNull MiniGame game() {
        return game;
    }

    public @NotNull Reason reason() {
        return reason;
    }

    @Override
    public @NotNull HandlerList getHandlers() {
        return HANDLERS;
    }

    public static @NotNull HandlerList getHandlerList() {
        return HANDLERS;
    }

    public enum Reason {
        /** 玩家自己退出。 */
        SELF,
        /** 这局打完了。 */
        GAME_ENDED,
        /** 被 OP 请出去。 */
        KICKED,
        /** 掉线 / 换服。 */
        DISCONNECT,
        /** 游戏被注销或插件卸载。 */
        SHUTDOWN
    }
}
