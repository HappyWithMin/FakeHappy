package maybe_c.happy.api.net;

import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Collection;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.function.Consumer;

/**
 * 跨服层。与代理侧对话。
 *
 * <h2>整体降级原则</h2>
 * 跨服层没配的子服上 {@link #isAvailable()} 返回 false，此时：
 * <ul>
 *   <li>查询类方法返回<b>已完成的空结果</b>，不抛异常、不阻塞</li>
 *   <li>上报 / 广播类方法静默丢弃</li>
 *   <li>{@link #sendToServer} 退回到 BungeeCord 插件消息通道（只要有在线玩家当载体就能用）</li>
 * </ul>
 * 也就是说：<b>单机开发环境下这套 API 全都能调，只是什么也不会发生。</b>
 * 小游戏不需要为「跨服可不可用」写两套代码。
 *
 * <h2>线程</h2>
 * 所有方法都可以在主线程调用，内部走异步。回调默认在<b>异步线程</b>，
 * 要碰 Bukkit 对象请自己切回主线程。
 */
public interface NetworkService {

    /** 跨服层可用吗。false 时全部降级，见类注释。 */
    boolean isAvailable();

    /** 本子服 ID。等价于 {@code HappyApi.serverId()}。 */
    @NotNull String serverId();

    // ------------------------------------------------------------ 节点

    /**
     * 网络里所有子服节点。
     * 跨服层不可用时返回空集合。
     */
    @NotNull CompletableFuture<Collection<NodeInfo>> nodes();

    @NotNull CompletableFuture<Optional<NodeInfo>> node(@NotNull String serverId);

    // ------------------------------------------------------------ 房间

    /**
     * 上报本机某局游戏的状态。{@code GameDescriptor.crossServer()} 为 true 时
     * 框架会自动周期上报，<b>小游戏一般不需要手动调</b>；
     * 只有在状态突变需要立刻让别的节点看到时才手动催一次。
     */
    void publishRoom(@NotNull RemoteGameRoom room);

    /** 撤下本机某个房间的上报（这局结束了 / 这个游戏被卸载了）。 */
    void withdrawRoom(@NotNull String gameId, @NotNull String roomId);

    /**
     * 查全网某个小游戏的房间列表，用于大厅展示和跨服排队。
     *
     * @param gameId 传 null 查全部游戏
     */
    @NotNull CompletableFuture<Collection<RemoteGameRoom>> rooms(@Nullable String gameId);

    /**
     * 找一个最适合塞人进去的房间：优先「快满但没满」的，凑人快；
     * 都空的话选延迟最低的节点。
     *
     * @return 找不到合适房间时是空 Optional
     */
    @NotNull CompletableFuture<Optional<RemoteGameRoom>> findBestRoom(@NotNull String gameId);

    // ------------------------------------------------------------ 传送

    /**
     * 把玩家送到指定子服。跨服层不可用时退回 BungeeCord 插件消息。
     *
     * @return 是否已经把请求发出去（不代表玩家一定连上了）
     */
    boolean sendToServer(@NotNull Player player, @NotNull String targetServerId);

    /**
     * 把玩家送去某个具体房间。代理侧会先向目标子服确认还有位置，
     * 再执行切服；没位置的话玩家会收到一条提示而不是被扔到一个满员的服里。
     */
    @NotNull CompletableFuture<Boolean> sendToRoom(@NotNull Player player,
                                                   @NotNull RemoteGameRoom room);

    // ------------------------------------------------------------ 消息总线

    /**
     * 往一个频道发消息。频道名会自动加上框架的命名空间前缀。
     *
     * <p>payload 建议用 JSON。单条上限 64 KiB，超了会被丢弃并记 warning ——
     * 消息总线不是用来传大块数据的。
     */
    void publish(@NotNull String channel, @NotNull String payload);

    /**
     * 订阅一个频道。
     *
     * <p><b>返回的句柄必须在你的插件卸载时取消</b>，否则订阅线程会一直持有
     * 你的回调（连带整个插件类加载器）不放 —— 这是重载后内存涨的典型原因。
     * 如果你的功能是用 {@code HappyModule} 注册的，交给
     * {@code ctx.onCleanup(sub::cancel)} 就行。
     *
     * <p>回调在<b>订阅线程</b>执行，不是主线程。
     */
    @NotNull Subscription subscribe(@NotNull String channel, @NotNull Consumer<String> handler);

    /**
     * 玩家当前在哪个子服。
     * 查不到时是空 Optional（可能人不在线，也可能跨服层没在跑）。
     */
    @NotNull CompletableFuture<Optional<String>> locate(@NotNull UUID playerId);

    /** 订阅句柄。 */
    interface Subscription {
        void cancel();

        boolean isActive();

        @NotNull String channel();
    }
}
