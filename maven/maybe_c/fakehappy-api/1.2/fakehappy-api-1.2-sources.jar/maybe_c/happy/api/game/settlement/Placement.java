package maybe_c.happy.api.game.settlement;

import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;

/**
 * 一个玩家在本局的名次与表现。
 *
 * <h2>你只需要填「他打得怎么样」</h2>
 * <b>不要自己算钱</b>。名次交给框架，币和经验由 {@link SettlementService} 按
 * 《舰长服小游戏制作规范》第十一章算 —— 包括总额守恒、胜利与 MVP 加成、
 * 以及同房连开的衰减。
 *
 * <p>这不是「框架比你算得好」，是「算法只有一份才不会分叉」。
 * 十个游戏各照公式抄一遍，就能凑出十种舍入方式，
 * 然后运营要回答「为什么同样第二名，A 游戏给 120、B 游戏给 87」。
 *
 * @param player 玩家
 * @param rank   名次，<b>从 1 开始</b>。允许并列 —— 两个人都填 2 就是并列第二，
 *               框架按并列里最靠前的那个名次发钱
 * @param won    是否属于胜方。经验 +30%
 * @param mvp    是否本局 MVP。经验 +50%，可与 {@code won} 叠加
 * @param quitEarly 是否中途退出。规范 11.4：只给 50% 经验、<b>不给币</b>
 * @param stats  结算界面上展示的数据（击杀、伤害、存活时间……）。
 *      顺序即展示顺序，所以用 {@code LinkedHashMap}
 */
@ApiStatus.Experimental
public record Placement(
        @NotNull UUID player,
        int rank,
        boolean won,
        boolean mvp,
        boolean quitEarly,
        @NotNull Map<String, String> stats
) {

    public Placement {
        if (rank < 1) throw new IllegalArgumentException("名次从 1 开始，收到 " + rank);
        stats = Map.copyOf(stats);
    }

    /** 最常见的写法：只有名次。 */
    public static @NotNull Builder of(@NotNull UUID player, int rank) {
        return new Builder(player, rank);
    }

    public static final class Builder {

        private final UUID player;
        private final int rank;
        private boolean won;
        private boolean mvp;
        private boolean quitEarly;
        private final Map<String, String> stats = new LinkedHashMap<>();

        private Builder(UUID player, int rank) {
            this.player = player;
            this.rank = rank;
        }

        /** 属于胜方。经验 +30%。 */
        public @NotNull Builder won() {
            this.won = true;
            return this;
        }

        /** 本局 MVP。经验 +50%，和 {@link #won()} 叠加。 */
        public @NotNull Builder mvp() {
            this.mvp = true;
            return this;
        }

        /**
         * 中途退出的人。
         *
         * <p><b>别把他们从名单里去掉</b> —— 规范 11.4 要求他们仍得 50% 经验，
         * 漏掉等于少发。而且结算界面上少一个人，其他人会以为是 bug。
         */
        public @NotNull Builder quitEarly() {
            this.quitEarly = true;
            return this;
        }

        /** 结算界面上展示一项数据。按调用顺序展示。 */
        public @NotNull Builder stat(@NotNull String label, @Nullable Object value) {
            if (value != null) stats.put(label, String.valueOf(value));
            return this;
        }

        public @NotNull Placement build() {
            return new Placement(player, rank, won, mvp, quitEarly, stats);
        }
    }
}
