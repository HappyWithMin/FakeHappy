package maybe_c.happy.api.ui;

import io.papermc.paper.registry.data.dialog.input.DialogInput;
import net.kyori.adventure.text.Component;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

import java.util.function.Consumer;

/**
 * Dialog 形态的菜单（Paper Dialog API）。
 *
 * <p>比箱子界面强的地方：能放<b>真正的输入控件</b>——文本框、开关、滑条、下拉框。
 * 改配置、填坐标、写公告这类操作用它比用箱子界面顺手得多，OP 不用退出去敲命令。
 *
 * <p><b>版本要求</b>：客户端 1.21.6+。低版本客户端调 {@code showDialog} 会被静默忽略，
 * 玩家什么都看不到。所以：<b>任何 Dialog 菜单都必须有一条命令行的等价路径</b>，
 * 或者用 {@link UiService#adaptive} 让框架在客户端不支持时自动退回箱子界面。
 *
 * <p><b>输入值的取用</b>：在按钮回调里通过
 * {@link ClickContext#text} / {@link ClickContext#bool} /
 * {@link ClickContext#number} / {@link ClickContext#option} 按 key 取，
 * key 就是你建 {@link DialogInput} 时给的那个。
 */
public interface DialogMenu extends Menu {

    interface Builder {

        /** 加一段说明文字（会按 SYSTEM 级解析，支持全部标签）。 */
        @NotNull Builder body(@NotNull String raw);

        @NotNull Builder body(@NotNull Component component);

        /**
         * 加一段<b>每次打开都重新求值</b>的说明文字。
         *
         * <p>要显示「随数据变化的内容」（某个玩家的档案、某条反馈的当前状态）
         * 必须用这个。理由和 {@link #input(java.util.function.Function)} 完全一样：
         * Dialog 没有可靠的关闭事件，所以<b>不能靠「每次打开新建一个菜单」</b>
         * 来刷新内容 —— 那些菜单再也等不到 dispose，开一次漏一个。
         *
         * <p>返回的 Component 可以自带换行（{@code Component.newline()}），
         * 于是「行数本身随数据变化」的列表也画得出来 —— 一次 {@code body} 调用
         * 对应一段可变高度的正文，而不是一行。
         *
         * <p>求值抛异常时这一段会被跳过并打一行警告，不会把整个对话框弄没。
         */
        @NotNull Builder body(@NotNull java.util.function.Function<Player, Component> perViewer);

        /**
         * 加一个输入控件。直接用 Paper 的 {@link DialogInput} 构造，
         * 框架不再包一层 —— 少一层抽象，Paper 加了新控件类型能立刻用上。
         *
         * <pre>{@code
         * .input(DialogInput.bool("pvp", label).initial(true).build())
         * .input(DialogInput.text("motd", label).maxLength(256).build())
         * }</pre>
         *
         * <p><b>初始值在这里就定死了。</b>要显示「当前配置是什么」的编辑界面，
         * 用下面那个按打开时求值的重载，否则 OP 改完保存、再打开看到的还是
         * 建菜单那一刻的旧值，会以为没保存成功。
         */
        @NotNull Builder input(@NotNull DialogInput input);

        /**
         * 加一个<b>每次打开都重新求值</b>的输入控件。
         *
         * <p>编辑现有配置的界面必须用这个。参数是即将看到这个对话框的玩家，
         * 所以也能做「每个人看到自己那一份设置」。
         *
         * <p>没有这个重载的话，唯一的办法是每次打开都新建一个 DialogMenu ——
         * 而 <b>Dialog 没有可靠的关闭事件</b>（玩家按 ESC 时服务端收不到任何包），
         * 那些菜单就再也没机会被 dispose，开一次漏一个。
         */
        @NotNull Builder input(@NotNull java.util.function.Function<Player, DialogInput> perViewer);

        /** 加一个动作按钮。同一个 {@link MenuButton} 也能给箱子界面用。 */
        @NotNull Builder button(@NotNull MenuButton button);

        /** 按钮排几列。默认 1。 */
        @NotNull Builder columns(int columns);

        /** 能否按 ESC 关掉。默认 true。设 false 时务必留一个「取消」按钮。 */
        @NotNull Builder canCloseWithEscape(boolean canClose);

        /**
         * 玩家不点任何按钮直接关掉时的回调。
         * 与 {@link ChestMenu.Builder#onClose} 一样，框架内部导航不会触发它。
         */
        @NotNull Builder onClose(@NotNull Consumer<Player> onClose);

        /** 覆盖标题。 */
        @NotNull Builder title(@NotNull Component title);

        @NotNull DialogMenu build();
    }
}
