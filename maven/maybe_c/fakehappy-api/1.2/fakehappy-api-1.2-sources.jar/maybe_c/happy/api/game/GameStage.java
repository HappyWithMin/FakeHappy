package maybe_c.happy.api.game;

/**
 * 小游戏的开发阶段 —— 《舰长服小游戏制作规范》3.1 与 12.1。
 *
 * <p><b>合规检查的严格度按这个走。</b>规范自己就写了阶段差异：
 * Alpha 允许占位素材和半成品，Beta 是过渡期，正式上线才要求全部满足。
 * 所以框架不能一上来就把所有「必须」项当硬性门槛 —— 那样任何游戏
 * 在开发第一天就是一片红，报告也就没人看了。
 */
public enum GameStage {

    /**
     * 内测。占位模型、临时音效、半成品玩法都允许。
     * 合规检查只提示，不刷屏。
     */
    ALPHA("内测"),

    /**
     * 公测过渡期。应当逐步向上线要求靠拢，可暴露部分未完成状态。
     * 合规检查会把缺失项列出来。
     */
    BETA("公测"),

    /**
     * 正式上线。规范 12.2 清单里所有「必须」项都要满足。
     * 有「必须」项没过时，启动日志里会给出醒目警告。
     */
    RELEASE("正式");

    private final String display;

    GameStage(String display) {
        this.display = display;
    }

    public String display() {
        return display;
    }

    /** 正式上线阶段才对「必须」项动真格。 */
    public boolean enforcesMandatory() {
        return this == RELEASE;
    }
}
