package maybe_c.happy.api.ui;

import net.kyori.adventure.text.Component;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.jetbrains.annotations.NotNull;

/**
 * UI 层入口。全服所有菜单都从这里建，好处有三：
 * <ol>
 *   <li><b>风格统一</b>：标题、边框、返回按钮、音效由框架统一套，各小游戏不用各画各的</li>
 *   <li><b>清理统一</b>：菜单绑在创建它的插件上，插件卸载 / 服务器关闭时框架
 *       会把所有打开的界面关掉，不会把玩家卡在一个已经没有后端逻辑的死界面里</li>
 *   <li><b>互斥统一</b>：与资源包确认框、Mod 检测告示牌等外部界面协调，
 *       不会互相顶掉（见 {@link #isScreenBusy}）</li>
 * </ol>
 */
public interface UiService {

    /**
     * 建一个箱子形态的菜单。
     *
     * @param owner 拥有者插件，用于卸载时回收
     * @param rows  1~6
     */
    @NotNull ChestMenu.Builder chest(@NotNull Plugin owner, @NotNull Component title, int rows);

    /** 建一个 Dialog 形态的菜单。客户端 1.21.6+ 才看得到。 */
    @NotNull DialogMenu.Builder dialog(@NotNull Plugin owner, @NotNull Component title);

    /**
     * 自适应菜单：客户端支持 Dialog 就用 Dialog，否则退回箱子界面。
     *
     * <p>你只定义一份按钮列表，两种形态框架各画一遍。代价是<b>用不了输入控件</b>
     * ——箱子界面画不出文本框。需要输入控件时用 {@link #dialog} 并自己
     * 兜一条命令行路径。
     *
     * <p>客户端版本从 packetevents 拿；拿不到（比如玩家刚连上还没握手完）时
     * 按「不支持」处理，退回箱子界面 —— 宁可退化也不要让人看不到界面。
     */
    @NotNull AdaptiveMenu.Builder adaptive(@NotNull Plugin owner, @NotNull Component title);

    /**
     * 建一个小游戏侧边栏计分板（规范第九章）。
     *
     * <p>顶部的游戏名、底部的 {@code play.zimin.fan}、Tab 底部的 {@code ==游戏名==}
     * 由框架按规范拼，你只提供中间内容。底层是 FastBoard，无闪烁。
     *
     * @param owner 拥有者插件，卸载时自动回收
     * @param game  取游戏名和合规登记用。传进来之后，框架就知道
     *              「这个游戏用了规范的计分板」，合规检查那两项会变成实测通过
     */
    @NotNull GameBoard.Builder board(@NotNull Plugin owner,
                                     @NotNull maybe_c.happy.api.game.MiniGame game);

    /** 该玩家的客户端是否支持 Dialog（1.21.6+）。 */
    boolean supportsDialog(@NotNull Player player);

    /**
     * 玩家当前是否正被某个界面占用 —— 包括本框架的菜单、原版容器、
     * 资源包确认框、Mod 检测用的告示牌编辑界面。
     *
     * <p>要在玩家面前弹东西（传送确认、活动通知）之前先问一下这个，
     * 不然会把对方正在填的资源包确认框顶掉。
     */
    boolean isScreenBusy(@NotNull Player player);

    /** 玩家当前打开的本框架菜单；没有则返回 null。 */
    Menu openMenu(@NotNull Player player);

    /** 关掉玩家打开的本框架菜单并清空他的导航栈。原版容器不受影响。 */
    void closeMenu(@NotNull Player player);

    /**
     * 关掉某插件创建的所有菜单。插件 disable 时框架会自动调，
     * 只有在需要提前清场（比如活动切换）时才手动调。
     */
    void closeAll(@NotNull Plugin owner);

    /**
     * 清空玩家的导航栈但不关当前菜单。
     * 用在「从子菜单直接跳到一个全新的顶层菜单」的场景，
     * 免得 back 一路退回到不相干的旧菜单。
     */
    void clearHistory(@NotNull Player player);
}
