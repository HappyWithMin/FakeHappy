package maybe_c.happy.api.game.chat;

import maybe_c.happy.api.game.MiniGame;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.NotNull;

/**
 * 局内聊天分频。<b>接上就有，不用写任何聊天代码。</b>
 *
 * <h2>你要做的只有一件事</h2>
 * 有队伍的游戏覆写 {@code MiniGame.teamOf(uuid)} 返回队伍标识。
 * 竞技游戏在 descriptor 里 {@code competitive(true)}。就这些。
 *
 * <p>剩下的 —— 拦聊天事件、按频道路由、观战者隔离、竞技游戏禁全局、
 * 给玩家切频道的命令 —— 全是框架的事。
 *
 * <h2>为什么要收进框架</h2>
 * 规范 10.2 那条「竞技游戏禁止全局聊天，队伍聊天仅同队可见」是条
 * <b>安全性质</b>的要求：漏了不是不好看，是对手能听见你报点。
 * 而它又完全是机械的 —— 没有哪个游戏需要用不一样的方式做隔离。
 *
 * <p>留给每个游戏自己实现的结果是每个游戏漏一点：这个忘了观战者，
 * 那个队伍频道其实发给了所有人（因为 {@code Bukkit.broadcast} 写起来最省事）。
 */
@ApiStatus.Experimental
public interface GameChatService {

    /** 这个人当前在哪个频道。不在任何一局里时返回 {@link GameChannel#GLOBAL}。 */
    @NotNull GameChannel channelOf(@NotNull Player player);

    /**
     * 切频道。
     *
     * @return 拒绝理由；null = 切成功。竞技游戏切 {@link GameChannel#GLOBAL} 会被拒
     */
    @org.jetbrains.annotations.Nullable String setChannel(@NotNull Player player,
                                                          @NotNull GameChannel channel);

    /**
     * 这局允许用全局频道吗。竞技游戏（{@code competitive(true)}）返回 false。
     */
    boolean allowsGlobal(@NotNull MiniGame game);
}
