package maybe_c.happy.api.spec;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;

/**
 * 一个小游戏的合规报告。
 *
 * <p>由框架在游戏注册时生成，回答的问题是：<b>照《舰长服小游戏制作规范》，
 * 这个游戏还缺什么。</b>
 */
public record SpecReport(
        @NotNull String gameId,
        @NotNull String specVersion,
        @NotNull List<Entry> entries,
        @NotNull List<String> unknownDeclarations
) {

    /** 一条检查结果。 */
    public record Entry(@NotNull SpecItem item, @NotNull Result result, @Nullable String note) {
    }

    public enum Result {
        /** 框架实测通过。 */
        PASS("通过"),
        /** 开发者声明已实现 —— 只代表他这么说，仍需人工验收。 */
        DECLARED("已声明"),
        /** 没做，或没声明。 */
        MISSING("缺失"),
        /** 开发者声明不适用，且理由被接受（仅「应当」「可选」项）。 */
        NOT_APPLICABLE("不适用"),
        /** 只能人工验收，框架不表态。 */
        MANUAL("待人工");

        private final String display;

        Result(String display) {
            this.display = display;
        }

        public String display() {
            return display;
        }

        /** 算不算「这条过了」。MANUAL 不算过也不算没过，单独统计。 */
        public boolean ok() {
            return this == PASS || this == DECLARED || this == NOT_APPLICABLE;
        }
    }

    /** 缺失的「必须」项 —— 报告里最该看的就是这一串。 */
    public @NotNull List<Entry> missingMandatory() {
        List<Entry> out = new ArrayList<>();
        for (Entry e : entries) {
            if (e.item().level() == SpecItem.Level.MUST && e.result() == Result.MISSING) {
                out.add(e);
            }
        }
        return out;
    }

    /** 缺失的「应当」项。 */
    public @NotNull List<Entry> missingRecommended() {
        List<Entry> out = new ArrayList<>();
        for (Entry e : entries) {
            if (e.item().level() == SpecItem.Level.SHOULD && e.result() == Result.MISSING) {
                out.add(e);
            }
        }
        return out;
    }

    /** 需要人工验收的项。 */
    public @NotNull List<Entry> manualItems() {
        List<Entry> out = new ArrayList<>();
        for (Entry e : entries) {
            if (e.result() == Result.MANUAL) out.add(e);
        }
        return out;
    }

    public int mandatoryTotal() {
        return (int) entries.stream()
                .filter(e -> e.item().level() == SpecItem.Level.MUST).count();
    }

    public int mandatoryPassed() {
        return (int) entries.stream()
                .filter(e -> e.item().level() == SpecItem.Level.MUST && e.result().ok()).count();
    }

    /** 所有「必须」项都过了吗（人工项不计入 —— 框架无从判断）。 */
    public boolean mandatoryClear() {
        return missingMandatory().isEmpty();
    }

    /** 一行摘要，日志和面板 tooltip 用。 */
    public @NotNull String summary() {
        return mandatoryPassed() + "/" + mandatoryTotal() + " 必须项"
                + (missingRecommended().isEmpty() ? "" : "，" + missingRecommended().size() + " 项应当未做")
                + (manualItems().isEmpty() ? "" : "，" + manualItems().size() + " 项待人工");
    }
}
