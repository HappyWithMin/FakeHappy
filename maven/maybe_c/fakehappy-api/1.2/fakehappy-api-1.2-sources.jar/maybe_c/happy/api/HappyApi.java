package maybe_c.happy.api;

import maybe_c.happy.api.game.GameRegistry;
import maybe_c.happy.api.module.ModuleManager;
import maybe_c.happy.api.net.NetworkService;
import maybe_c.happy.api.text.TextService;
import maybe_c.happy.api.ui.UiService;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/**
 * FakeHappy 对外的唯一入口。子服里所有小游戏 / 附属插件都从这里拿服务。
 *
 * <p><b>怎么拿</b>：优先用 {@link Happy#api()}（内部走 Bukkit ServicesManager，带缓存）。
 * 只在 FakeHappy 之后加载的插件里调用 —— 在自己的 {@code plugin.yml} 写
 * {@code depend: [FakeHappy]}（硬依赖）或 {@code softdepend: [FakeHappy]} + 判空。
 *
 * <p><b>线程</b>：本接口的方法都可以在主线程调用。凡是会阻塞的（网络 / 数据库）
 * 一律返回 {@link java.util.concurrent.CompletableFuture}，并且回调默认在异步线程，
 * 需要碰 Bukkit 对象时自己切回主线程。
 *
 * <p><b>兼容承诺</b>：本模块（fakehappy-api）遵循「只加不删」。要移除某个方法会先
 * 标 {@code @Deprecated} 并至少保留一个大版本。core 的内部实现随时可能重写，
 * 所以<b>不要</b>去 cast 成实现类。
 */
public interface HappyApi {

    /** api 契约版本号。每次对本模块做不兼容改动就 +1，下游可以据此拒绝启动。 */
    int API_VERSION = 1;

    /**
     * 本子服在整个网络里的唯一 ID（config.yml 的 {@code server-id}）。
     * 与 velocity.toml 里的子服 key 一致，跨服消息、房间注册都用它。
     */
    @NotNull String serverId();

    /** 本子服的角色，决定默认启用哪些模块。 */
    @NotNull ServerRole serverRole();

    /** 文本：&amp; 颜色码 / MiniMessage / sprite / shadow 混写的统一解析与全服统一风格。 */
    @NotNull TextService text();

    /** UI：Dialog 与箱子界面的统一按钮模型，两种呈现共用一套定义。 */
    @NotNull UiService ui();

    /** 小游戏注册表：注册进来才能被大厅 UI、OP 场控、跨服排队看见。 */
    @NotNull GameRegistry games();

    /** 跨服：节点、房间、消息总线。跨服层未配置时整体降级，见 {@link NetworkService#isAvailable()}。 */
    @NotNull NetworkService network();

    /** 持久化：战绩、跨服偏好、审计。未配置数据库时整体降级。 */
    @NotNull maybe_c.happy.api.data.DataService data();

    /**
     * 全服组队（规范第五章）。每个小游戏都必须适配 ——
     * 玩家进房间时查 {@code partyOf}，用 {@code PartyPlacement.plan} 算编队。
     * 跨服层未配置时整体降级。
     */
    @NotNull maybe_c.happy.api.party.PartyService party();

    /**
     * 货币 / 等级 / 积分的统一发放（规范第十一章）。
     *
     * <p>小游戏发奖励只调这里，<b>不要直接去 hook Vault 或者写自己的等级表</b> ——
     * 石粒币、石粒等级、贡献积分三套东西的发放口径都归这一层管，
     * 游戏代码不用关心它们各自存在哪。
     */
    @NotNull maybe_c.happy.api.reward.RewardService rewards();

    /**
     * 货币。<b>可能为 null</b> —— 经济模块默认是关的，而且它要数据库。
     *
     * <p>发奖励请优先用 {@link #rewards()}：那一层同时管货币、经验、积分，
     * 而且会把「哪一项没发出去」如实报给你。直接用这个接口的场景是
     * 「小游戏里要收门票 / 商店要扣钱」这种<b>只涉及货币</b>的操作。
     *
     * <p>拿到之后可以长期持有，但每次用前判一下 {@code available()} ——
     * 数据库可能中途断开。
     */
    @Nullable maybe_c.happy.api.economy.EconomyService economy();

    /**
     * 一局结束时把结果交给它，币、经验、结算界面全由框架做。
     *
     * <p>见 {@code SettlementService} —— 走这条路的话，规范里六条
     * 和结算 / 发奖相关的「必须」项自动通过。
     */
    @NotNull maybe_c.happy.api.game.settlement.SettlementService settlement();

    /**
     * 局内聊天分频（规范 10.2）。<b>接上就有，不用写聊天代码。</b>
     *
     * <p>有队伍的游戏覆写 {@code MiniGame.teamOf(...)}、竞技游戏
     * {@code competitive(true)}，剩下的隔离全是框架做的。
     */
    @NotNull maybe_c.happy.api.game.chat.GameChatService chat();

    /** 模块生命周期。附属插件一般用不到，自己管自己的生命周期即可。 */
    @NotNull ModuleManager modules();

    /** 子服角色。用于「大厅该开什么、小游戏服该开什么」这类默认值决策。 */
    enum ServerRole {
        /** 大厅 / 中转：开可见性管理、大厅保护、小游戏入口 UI。 */
        LOBBY,
        /** 小游戏子服：开小游戏框架，不开大厅保护。 */
        MINIGAME,
        /** 活动服（与岷同乐）：开场控 UI 与活动广播。 */
        EVENT,
        /** 生存等常规子服。 */
        SURVIVAL,
        /** 未声明。按最保守的默认值走。 */
        UNKNOWN
    }
}
