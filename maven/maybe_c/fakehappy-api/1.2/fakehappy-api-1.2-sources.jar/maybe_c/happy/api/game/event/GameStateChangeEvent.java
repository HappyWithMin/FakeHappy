package maybe_c.happy.api.game.event;

import maybe_c.happy.api.game.GameState;
import maybe_c.happy.api.game.MiniGame;
import org.bukkit.event.Cancellable;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;
import org.jetbrains.annotations.NotNull;

/**
 * 某局小游戏的状态即将变化。由 {@code GameRegistry.setState} 触发。
 *
 * <p>取消掉就不会变状态，{@code setState} 返回 false。
 * 常见用途：活动模式下禁止小游戏自动开局，全部改由 OP 手动开。
 */
public class GameStateChangeEvent extends Event implements Cancellable {

    private static final HandlerList HANDLERS = new HandlerList();

    private final MiniGame game;
    private final GameState from;
    private final GameState to;
    private boolean cancelled;

    public GameStateChangeEvent(@NotNull MiniGame game, @NotNull GameState from, @NotNull GameState to) {
        this.game = game;
        this.from = from;
        this.to = to;
    }

    public @NotNull MiniGame game() {
        return game;
    }

    public @NotNull GameState from() {
        return from;
    }

    public @NotNull GameState to() {
        return to;
    }

    @Override
    public boolean isCancelled() {
        return cancelled;
    }

    @Override
    public void setCancelled(boolean cancel) {
        this.cancelled = cancel;
    }

    @Override
    public @NotNull HandlerList getHandlers() {
        return HANDLERS;
    }

    public static @NotNull HandlerList getHandlerList() {
        return HANDLERS;
    }
}
