package maybe_c.happy.api.reward;

/**
 * 玩家在等级系统里的一个快照。取出来那一刻的值，不会自己更新。
 *
 * <p>等级从 <b>1</b> 起（不是 0），1 级需要 0 经验。这一点和
 * 积分等级不同 —— 积分等级从 0 起，一分没拿过就是 0 级。
 *
 * @param level        当前等级，最小 1
 * @param maxLevel     配置的等级上限
 * @param totalExp     累计总经验，从入服到现在
 * @param expIntoLevel 在当前这一级里已经攒了多少
 * @param expForNext   当前这一级一共需要多少才能升下一级；满级时为 0
 */
public record LevelInfo(int level, int maxLevel, long totalExp, long expIntoLevel, long expForNext) {

    /**
     * 还没有任何数据时的占位（数据库没连上、或者玩家档案还在异步加载）。
     *
     * <p>{@code maxLevel} 是 <b>0</b> 而不是 1：曲线的 {@code max-level} 至少是 1，
     * 所以 0 是一个真实曲线永远取不到的值，可以拿来当「没数据」的标记
     * （见 {@link #known()}）。写成 1 的后果实测过 —— 那一瞬间
     * {@link #isMax()} 是 true、{@link #progress()} 是 1.0，玩家刚进服时
     * TAB 上会闪一下「满级 / 进度条全满 / 上限 1」，档案载入完又跳回 1 级。
     */
    public static final LevelInfo UNKNOWN = new LevelInfo(1, 0, 0, 0, 0);

    /**
     * 这份快照有没有真的读到数据。{@link #UNKNOWN} 是 {@code false}。
     *
     * <p>展示层该判这一下：判不了的地方（比如直接吐数字的 PAPI 变量）
     * 宁可返回空串，也别把占位值当真值显示出去。
     */
    public boolean known() {
        return maxLevel > 0;
    }

    public boolean isMax() {
        return known() && level >= maxLevel;
    }

    /** 还差多少升级。满级返回 0。 */
    public long expToNext() {
        return isMax() ? 0 : Math.max(0, expForNext - expIntoLevel);
    }

    /**
     * 当前这一级的完成度，0.0 ~ 1.0。满级恒为 1.0。
     *
     * <p>进度条、圆环、TAB 上的百分比都用这个值渲染，不要自己拿
     * {@code totalExp / requiredExp} 去算 —— 那算出来是「整个生涯的完成度」，
     * 到了 50 级以后进度条几乎不动，玩家会以为卡住了。
     */
    public double progress() {
        if (!known()) return 0;
        if (isMax() || expForNext <= 0) return 1.0;
        double p = (double) expIntoLevel / (double) expForNext;
        return p < 0 ? 0 : Math.min(p, 1.0);
    }
}
