package maybe_c.happy.api.reward;

import org.jetbrains.annotations.NotNull;

/**
 * 领取一档奖励的结果。
 *
 * <h2>为什么不是一个 boolean</h2>
 * 老的 {@code claimReward} 对「档案还没载入」和「等级不够」都返回 {@code false}，
 * 界面只能统一打一句「领取失败」—— 而这两种情况玩家该做的事正好相反：
 * 一个是等一会儿，一个是去练级。{@link #NO_PROFILE} 在数据库抖一下的时候
 * 是<b>全服所有人</b>的状态，说成「领取失败」会让每个人都以为自己不够格。
 *
 * <p>{@link #DELIVERY_FAILED} 更关键：它意味着<b>记账已经回滚、可以再点</b>，
 * 和 {@link #ALREADY_CLAIMED} 要说的话完全相反。混成一个 false 的话，
 * 玩家会对着一个其实能领的奖励一直被告知「已经领过了」。
 */
public enum ClaimOutcome {

    /** 记账 + 落盘 + 至少一项真的发出去了。 */
    OK("已领取"),

    /** 界面快照过期了 —— 多半是自动领取抢在前面，或者他在另一台子服刚领过。 */
    ALREADY_CLAIMED("这一档你已经领过了"),

    /** 等级在界面打开之后被别处改低了。 */
    LEVEL_TOO_LOW("你的等级还不够"),

    /** OP 刚把这一档从档位表里删了，界面上还留着旧格子。 */
    NOT_FOUND("这一档奖励已经不存在了（管理员刚改过），重开一次界面"),

    /** 内存里没有这个玩家的档案：还在异步载入，或者进服时查库失败。 */
    NO_PROFILE("你的档案还没载入完，或者数据库暂时读不到，过一会儿再试"),

    /** 命令和货币一条都没成功，领取记录已经退回来了。 */
    DELIVERY_FAILED("奖励没能发出去，领取记录已经退回，换个子服再试一次");

    private final String reason;

    ClaimOutcome(String reason) {
        this.reason = reason;
    }

    public boolean ok() {
        return this == OK;
    }

    /** 可以直接发给玩家看的中文人话。 */
    public @NotNull String reason() {
        return reason;
    }
}
