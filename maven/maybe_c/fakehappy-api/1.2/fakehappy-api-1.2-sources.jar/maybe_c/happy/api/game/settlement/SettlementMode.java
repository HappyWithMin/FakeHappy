package maybe_c.happy.api.game.settlement;

import org.jetbrains.annotations.ApiStatus;

/**
 * 这个游戏的结算由谁做。在 {@code GameDescriptor} 里声明。
 *
 * <h2>这个声明骗不了人</h2>
 * 声明 {@link #FRAMEWORK} 却从不调 {@link SettlementService#settle} 的后果是
 * <b>没有人拿到奖励</b> —— 当场就会被玩家发现。
 *
 * <p>这一点是刻意的：规范里那些「需声明」的项，声明假的没有任何后果，
 * 所以对着一份满分报告看不出问题。而这一条只要撒谎就会立刻炸出来。
 */
@ApiStatus.Experimental
public enum SettlementMode {

    /**
     * <b>框架结算（推荐）。</b>你只提供名次和表现，币、经验、衰减、
     * 自定义房不发奖、结算界面、回游戏大厅全部由框架做。
     *
     * <p>规范里 {@code flow.settlement}、{@code flow.back-to-hub}、
     * {@code econ.sum}、{@code econ.exp}、{@code econ.decay} 五条自动通过。
     */
    FRAMEWORK("框架结算"),

    /**
     * 自己结算。适合结算形态特殊到框架界面表达不了的游戏。
     *
     * <p>上面那五条规范项回到「需声明」，由你自己实现并在
     * {@code GameCompliance} 里自查。<b>包括「所有玩家石粒币之和恰好等于 n×a」</b>——
     * 那是个浮点求和加取整的问题，自己写很容易差几个币。
     * 真要自己来的话，至少用 {@code RewardFormula.payout(...)} 算，别照公式手抄。
     */
    CUSTOM("自行结算");

    private final String display;

    SettlementMode(String display) {
        this.display = display;
    }

    public String display() {
        return display;
    }
}
