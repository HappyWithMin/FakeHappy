package maybe_c.happy.api.economy;

import maybe_c.happy.api.audit.AuditContext;
import net.kyori.adventure.text.Component;
import org.bukkit.OfflinePlayer;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.math.BigDecimal;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;

/**
 * 货币服务。余额查询读取本机缓存；{@link #fetch} 异步查询数据库。
 * <p>写操作返回真实提交结果。余额与审计流水在同一事务中提交，失败时回滚；
 * 扣款和转账以数据库余额为准。金额按 {@code DECIMAL(30,2)}、HALF_UP 处理。
 * <p>旧写入方法自动记录来源；{@link AuditContext} 重载支持明确的操作者与业务关联。
 * 后端不可用时返回 {@link TxnResult.Status#UNAVAILABLE}。调用方确认成功后再交付商品。
 */
public interface EconomyService {

    /** 后端可用（数据库连上了）。不可用时读返回 0、写返回 {@link TxnResult.Status#UNAVAILABLE}。 */
    boolean available();

    /** 币种 ID，进数据库的 {@code currency} 列。改了等于换一套账，<b>不要改</b>。 */
    @NotNull String currencyId();

    /** 本服管它叫什么（例如「金币」）。展示用。 */
    @NotNull String currencyName();

    /** 带本服配色的货币名。 */
    @NotNull Component currencyDisplay();

    /** {@code 1,250 金币} 这样，带配色。 */
    @NotNull Component format(@NotNull BigDecimal amount);

    /** 纯文本版，日志和命令回执用。 */
    @NotNull String formatPlain(@NotNull BigDecimal amount);

    // ---------------------------------------------------------------- 读

    /**
     * 余额。<b>读内存，不查库，主线程可调。</b>
     *
     * <p>没缓存过的玩家（离线的、刚进服还没加载完的）返回 {@link BigDecimal#ZERO}
     * 并触发一次后台加载。要确切值请用 {@link #fetch}。
     */
    @NotNull BigDecimal balance(@NotNull UUID player);

    /** 这个人的余额够不够。同 {@link #balance}，看的是内存值。 */
    boolean has(@NotNull UUID player, @NotNull BigDecimal amount);

    /**
     * 从数据库取确切余额，绕过缓存。查离线玩家、或者要做对账时用。
     *
     * <p>顺带把结果写回缓存。
     */
    @NotNull CompletableFuture<BigDecimal> fetch(@NotNull UUID player);

    // ---------------------------------------------------------------- 写

    /**
     * 入账。
     *
     * @param reason 进审计表的原因（{@code level-reward} / {@code admin-give} / {@code shop-sell}）。
     *               <b>务必如实填</b> —— 「凭什么我的钱多了/少了」只能靠它回答
     */
    @NotNull CompletableFuture<TxnResult> deposit(@NotNull UUID player, @NotNull BigDecimal amount,
                                                  @NotNull String reason);

    /** 带来源、操作者和关联编号的入账。旧实现可继续只实现原签名。 */
    default @NotNull CompletableFuture<TxnResult> deposit(@NotNull UUID player, @NotNull BigDecimal amount,
                                                          @NotNull String reason, @NotNull AuditContext context) {
        return deposit(player, amount, reason);
    }

    /**
     * 扣款。余额不足时<b>一分都不扣</b>，返回 {@link TxnResult.Status#INSUFFICIENT}。
     */
    @NotNull CompletableFuture<TxnResult> withdraw(@NotNull UUID player, @NotNull BigDecimal amount,
                                                   @NotNull String reason);

    /** 带审计上下文的扣款；余额与流水共同提交或共同回滚。 */
    default @NotNull CompletableFuture<TxnResult> withdraw(@NotNull UUID player, @NotNull BigDecimal amount,
                                                           @NotNull String reason, @NotNull AuditContext context) {
        return withdraw(player, amount, reason);
    }

    /**
     * 直接设成某个值。<b>只给管理命令用。</b>
     *
     * <p>它是绝对写而不是相对增量，所以两个人同时设同一个账户时后写的赢 ——
     * 日常发钱扣钱请用 {@link #deposit} / {@link #withdraw}。
     */
    @NotNull CompletableFuture<TxnResult> set(@NotNull UUID player, @NotNull BigDecimal amount,
                                              @NotNull String reason);

    /** 带审计上下文的管理设值。 */
    default @NotNull CompletableFuture<TxnResult> set(@NotNull UUID player, @NotNull BigDecimal amount,
                                                      @NotNull String reason, @NotNull AuditContext context) {
        return set(player, amount, reason);
    }

    /**
     * 转账。两个账户按 UUID 顺序锁定，在同一数据库事务中更新余额并写入双方流水。
     * 余额不足或任一余额、流水写入失败时整笔回滚。双方流水共享 transaction_id。
     */
    @NotNull CompletableFuture<TxnResult> transfer(@NotNull UUID from, @NotNull UUID to,
                                                   @NotNull BigDecimal amount, @NotNull String reason);

    /** 带审计上下文的转账，双方记录保留同一个关联编号和操作者。 */
    default @NotNull CompletableFuture<TxnResult> transfer(@NotNull UUID from, @NotNull UUID to,
                                                           @NotNull BigDecimal amount, @NotNull String reason,
                                                           @NotNull AuditContext context) {
        return transfer(from, to, amount, reason);
    }

    // ---------------------------------------------------------------- 排行

    /**
     * 排行榜的一行。
     *
     * @param name 落库时记下的名字，可能是旧名。展示时优先用在线玩家的当前名
     */
    record Entry(@NotNull UUID uuid, @Nullable String name, @NotNull BigDecimal balance) {
    }

    /**
     * 余额排行。<b>有缓存</b>（默认 60 秒）——
     * 这是个全表 ORDER BY，让每个点开排行榜的人都真查一次会很难看。
     */
    @NotNull CompletableFuture<List<Entry>> top(int limit);

    // ---------------------------------------------------------------- 便利重载

    default @NotNull BigDecimal balance(@NotNull OfflinePlayer player) {
        return balance(player.getUniqueId());
    }

    default @NotNull CompletableFuture<TxnResult> deposit(@NotNull OfflinePlayer player,
                                                          @NotNull BigDecimal amount,
                                                          @NotNull String reason) {
        return deposit(player.getUniqueId(), amount, reason);
    }

    default @NotNull CompletableFuture<TxnResult> withdraw(@NotNull OfflinePlayer player,
                                                           @NotNull BigDecimal amount,
                                                           @NotNull String reason) {
        return withdraw(player.getUniqueId(), amount, reason);
    }

    default @NotNull CompletableFuture<TxnResult> deposit(@NotNull OfflinePlayer player,
                                                          @NotNull BigDecimal amount, @NotNull String reason,
                                                          @NotNull AuditContext context) {
        return deposit(player.getUniqueId(), amount, reason, context);
    }

    default @NotNull CompletableFuture<TxnResult> withdraw(@NotNull OfflinePlayer player,
                                                           @NotNull BigDecimal amount, @NotNull String reason,
                                                           @NotNull AuditContext context) {
        return withdraw(player.getUniqueId(), amount, reason, context);
    }
}
