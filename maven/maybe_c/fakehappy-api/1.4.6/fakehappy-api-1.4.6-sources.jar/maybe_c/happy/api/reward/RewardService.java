package maybe_c.happy.api.reward;

import maybe_c.happy.api.audit.AuditContext;
import net.kyori.adventure.text.Component;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;

/**
 * 货币、经验与积分的统一发放接口。货币走本服的经济系统。
 * <p>写操作异步返回回执；不同资产可能部分成功，展示和补偿以 {@link GrantResult#granted()}
 * 及 {@link GrantResult#skipped()} 为准。调用方负责防止重复结算。
 * <p>查询使用缓存。Future 回调线程不固定，访问 Bukkit 对象时应切回主线程。
 * 后端缺失或事务失败按各方法约定返回失败结果。
 */
public interface RewardService {

    /** 三种后端至少有一种可用。全都不可用时 {@code grant} 仍然安全，只是什么都不发。 */
    boolean isAvailable();

    /**
     * 这一项在本服有没有后端接着。
     *
     * <p>用它来决定「要不要在结算界面上显示这一行」——
     * 发不出去还显示「获得 0 金币」比不显示更让人困惑。
     */
    boolean supports(@NotNull RewardKind kind);

    // ============================================================ 名字

    /**
     * 这一项叫什么（例如「金币」）。从配置读，别写死。
     *
     * <p>展示奖励时用它，不要在自己的代码里写死名字 —— 那样换个服就不对了。
     */
    @NotNull Component nameOf(@NotNull RewardKind kind);

    /** 同 {@link #nameOf}，纯文本形式。写日志、拼占位符变量时用。 */
    @NotNull String plainNameOf(@NotNull RewardKind kind);

    /**
     * 等级体系本身叫什么（例如「玩家等级」）。从配置读，别写死。
     *
     * <p>和 {@code nameOf(EXP)} 不是一回事 —— 那个是「经验」这种资源的名字，
     * 这个是等级体系的名字。计分板上写「玩家等级 12」用这个。
     */
    @NotNull Component levelName();

    /** 积分等级体系叫什么（例如「积分等级」）。从配置读，别写死。 */
    @NotNull Component pointsLevelName();

    /**
     * 拼成「1,250 金币」这样的一段，数字按本服配置的样式着色、加千分位。
     *
     * <p>结算界面直接用这个，全服的奖励展示样式就统一了。
     */
    @NotNull Component format(@NotNull RewardKind kind, double amount);

    // ============================================================ 发放

    /**
     * 发放。这是小游戏唯一需要用的写接口。
     *
     * <p>幂等性由调用方负责 —— 这里不去重。同一局结算被调两次就会发两次。
     *
     * @param reason 记进审计日志，出了「凭什么给他这么多币」的争议时能查。
     *               约定写成 {@code <游戏id>:<事由>}，例如 {@code miner:win}、
     *               {@code miner:quit-early}、{@code event:anniversary}
     */
    @NotNull CompletableFuture<GrantResult> grant(@NotNull UUID player,
                                                  @NotNull RewardBundle bundle,
                                                  @NotNull String reason);

    /** 带可检索的插件来源、操作者、业务单号及附加信息；旧实现仍可通过默认方法兼容。 */
    default @NotNull CompletableFuture<GrantResult> grant(@NotNull UUID player,
                                                          @NotNull RewardBundle bundle,
                                                          @NotNull String reason,
                                                          @NotNull AuditContext context) {
        return grant(player, bundle, reason);
    }

    default @NotNull CompletableFuture<GrantResult> grant(@NotNull UUID player,
                                                          @NotNull RewardBundle bundle,
                                                          @NotNull AuditContext context) {
        return grant(player, bundle, context.reason(), context);
    }

    /**
     * 扣钱。<b>刻意和 {@link #grant} 分开</b> —— 发放接口不接受负数，
     * 这样一个算错的公式最多是少发，不会把玩家余额清空。
     *
     * @return 余额不足或没有货币后端时返回 {@code false}，不会扣一部分
     */
    @NotNull CompletableFuture<Boolean> takeCurrency(@NotNull UUID player,
                                                     double amount,
                                                     @NotNull String reason);

    default @NotNull CompletableFuture<Boolean> takeCurrency(@NotNull UUID player,
                                                             double amount,
                                                             @NotNull String reason,
                                                             @NotNull AuditContext context) {
        return takeCurrency(player, amount, reason);
    }

    default @NotNull CompletableFuture<Boolean> takeCurrency(@NotNull UUID player,
                                                             double amount,
                                                             @NotNull AuditContext context) {
        return takeCurrency(player, amount, context.reason(), context);
    }

    /** 够不够扣。非阻塞缓存读，用于「买入场券」这类先判断再扣的场景。 */
    boolean hasCurrency(@NotNull UUID player, double amount);

    // ============================================================ 查询（非阻塞）

    /** 余额。没有货币后端时恒为 0。 */
    double balance(@NotNull UUID player);

    /** 等级快照。档案还没载入时返回 {@link LevelInfo#UNKNOWN}。 */
    @NotNull LevelInfo level(@NotNull UUID player);

    /** 累计积分。 */
    int points(@NotNull UUID player);

    /** 积分等级（从 0 起，没积分就是 0 级）。 */
    int pointsLevel(@NotNull UUID player);

    /**
     * 积分那条曲线的同步快照，<b>能判空</b>。
     *
     * <p>和 {@link #points(UUID)} 的区别：那个在档案没载入时返回 0，
     * 分不出「读不到」和「他真的一分没有」。展示端照着 0 打出「积分 0」是骗人 ——
     * 数据库抖一下就是全服所有人都这样。判 {@link LevelInfo#known()}。
     *
     * <p>{@link LevelInfo#totalExp()} 是积分总数，{@link LevelInfo#level()} 是积分等级。
     */
    @NotNull LevelInfo pointsInfo(@NotNull UUID player);

    /**
     * 离线玩家的等级。在线玩家优先用 {@link #level(UUID)}，那个不查库。
     *
     * <p>查不到（数据库没连上 / 这个人从来没登录过）时返回
     * {@link LevelInfo#UNKNOWN}，它的 {@link LevelInfo#known()} 是 {@code false}。
     */
    @NotNull CompletableFuture<LevelInfo> levelAsync(@NotNull UUID player);

    /**
     * 离线玩家的积分。在线玩家优先用 {@link #points(UUID)}，那个不查库。
     *
     * <p>返回的是<b>积分那条曲线</b>的快照：{@link LevelInfo#totalExp()} 是积分总数，
     * {@link LevelInfo#level()} 是积分等级。共用一个 record 是因为两条曲线本来
     * 就是同一套实现，再复制一份字段完全一样的类没有意义。
     *
     * <p>没有这个方法的时候，OP 面板对离线玩家只能打一句「积分需要他上线后再看」——
     * 而积分恰恰是活动结算之后最常要核对的那一项。
     */
    @NotNull CompletableFuture<LevelInfo> pointsAsync(@NotNull UUID player);

    // ============================================================ 升级奖励

    /**
     * 已达成但还没领的升级奖励 key。
     *
     * <p>服主开着「自动领取」的话（默认开）
     * 这里永远是空的，升级当场就发了。关掉之后奖励会攒着，玩家用
     * 领奖命令自己领，红点用 {@link #unclaimedCount}。
     *
     * <p><b>这个方法每次调用都新建列表</b>，只给命令、菜单这类低频调用方用。
     */
    @NotNull List<String> unclaimedRewards(@NotNull UUID player);

    /**
     * 未领奖励的<b>份数</b>，两条曲线加起来。
     *
     * <p>这是「待领奖励」红点占位符的后端，Tab 列表 / 计分板
     * <b>每 tick 每个玩家</b>会问一次。实现必须是一次字段读、零分配 ——
     * 要列表请用 {@link #unclaimedRewards}，那个每次调用都新建列表，
     * 只给命令、菜单这类低频调用方用。
     */
    int unclaimedCount(@NotNull UUID player);

    /**
     * 全部档位在这个玩家眼里的样子，给领取界面铺格子用。
     *
     * <p>已经按「先等级侧、后积分侧，组内按等级升序」排好，<b>调用方不要再排</b>
     * （排序在档位表构建时做过了）。
     *
     * <p>档案还没载入时返回的是<b>全部 LOCKED</b> 而不是空表 ——
     * 展示端才分得出「没配任何档位」和「读不到你的档案」，这两件事玩家该做的事不一样。
     */
    @NotNull List<RewardView> rewardViews(@NotNull UUID player);

    /**
     * 领取一档。<b>要明确说是哪条曲线</b>，不靠 key 猜。
     *
     * <p><b>返回的 future 有两种完成线程</b>：早期校验失败（等级不够、已领过）
     * 在插件的 IO 线程上完成，成功那条在主线程派发结束之后完成。
     * 所以回调里<b>一律先 {@code runTask} 回主线程再碰 Bukkit API</b>，
     * 不能想当然认为已经在主线程 —— 直接在 {@code whenComplete} 里操作玩家
     * 是随机踩雷，测试时多半看不出来。
     */
    @NotNull CompletableFuture<ClaimOutcome> claimOne(@NotNull UUID player,
                                                      @NotNull String rewardKey,
                                                      boolean pointsSide);

    /**
     * 一键领取所有能领的。
     *
     * @return 真正领到手的份数（发放失败并已回滚的不算）
     */
    @NotNull CompletableFuture<Integer> claimAll(@NotNull UUID player);

    /**
     * 领取一个升级奖励。
     *
     * <p>领取记录是<b>跨子服</b>的：在大厅领过的，切到小游戏服不会再出现。
     * 奖励里配的命令如果一条都没派发成功，领取记录会回滚，玩家可以再领。
     *
     * <p><b>兼容入口</b>：它按 key 猜是哪条曲线，两条曲线撞名时只会命中等级那一边。
     * 而且把「档案没载入」和「等级不够」都压成 {@code false}，
     * 展示端只能统一说「领取失败」。新代码请用 {@link #claimOne}。
     *
     * @return 没这个 key、等级不够、或者已经领过，都返回 {@code false}
     */
    @NotNull CompletableFuture<Boolean> claimReward(@NotNull UUID player, @NotNull String rewardKey);

    // ============================================================ 排行榜

    /**
     * 等级榜。结果有缓存（默认 60 秒），可以放心在菜单里每次打开都调。
     *
     * @param limit 取前几名，上限 100
     */
    @NotNull CompletableFuture<List<Ranked>> topLevels(int limit);

    /** 积分榜。同样有缓存。 */
    @NotNull CompletableFuture<List<Ranked>> topPoints(int limit);
}
