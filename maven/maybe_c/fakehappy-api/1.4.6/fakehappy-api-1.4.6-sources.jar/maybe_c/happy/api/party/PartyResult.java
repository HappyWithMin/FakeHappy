package maybe_c.happy.api.party;

import org.jetbrains.annotations.NotNull;

/**
 * 组队操作的结果。
 *
 * <p>每一项都自带一句给玩家看的话 —— 调用方直接
 * {@code text.sendPrefixed(player, result.message())} 就行，
 * 不用每个命令、每个菜单各写一遍文案。文案统一了，玩家在哪儿看到的说法都一样。
 */
public enum PartyResult {

    OK("操作成功", true),

    /** 跨服层没配 / 连不上，组队系统整体降级。 */
    UNAVAILABLE("组队功能暂时不可用", false),

    ALREADY_IN_PARTY("已加入队伍", false),
    NOT_IN_PARTY("尚未加入队伍", false),
    TARGET_ALREADY_IN_PARTY("对方已加入其他队伍", false),
    TARGET_OFFLINE("对方不在线", false),
    TARGET_NOT_IN_PARTY("对方不在你的队伍里", false),

    NOT_LEADER("仅队长可操作", false),
    CANNOT_TARGET_SELF("不能以自己为目标", false),

    PARTY_FULL("队伍满了", false),
    INVITE_EXPIRED("邀请已过期", false),
    NO_INVITE("没有人邀请你", false),
    ALREADY_INVITED("已发送邀请，等待回应", false),

    /** 目标子服不存在或没在线。 */
    NO_SUCH_SERVER("目标子服不可用", false),

    /** 并发冲突：写入时队伍已经被别人改了。调用方可以重试一次。 */
    CONFLICT("队伍状态已变更，请重试", false),

    ERROR("操作失败，请稍后重试", false);

    private final String message;
    private final boolean success;

    PartyResult(String message, boolean success) {
        this.message = message;
        this.success = success;
    }

    /** 给玩家看的话。 */
    public @NotNull String message() {
        return message;
    }

    public boolean isSuccess() {
        return success;
    }
}
