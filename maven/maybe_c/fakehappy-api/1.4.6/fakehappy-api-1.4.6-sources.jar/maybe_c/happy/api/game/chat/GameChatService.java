package maybe_c.happy.api.game.chat;

import maybe_c.happy.api.game.MiniGame;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.NotNull;

/**
 * 局内聊天分频服务。框架按房间、队伍及旁观状态路由消息。
 * <p>有队伍的游戏覆写 {@code MiniGame.teamOf(uuid)}；竞技游戏声明 {@code competitive(true)}，
 * 其全局频道不可用。多局游戏还需正确提供 {@code roomOf(uuid)}。
 */
@ApiStatus.Experimental
public interface GameChatService {

    /** 这个人当前在哪个频道。不在任何一局里时返回 {@link GameChannel#GLOBAL}。 */
    @NotNull GameChannel channelOf(@NotNull Player player);

    /**
     * 切频道。
     *
     * @return 拒绝理由；null = 切成功。竞技游戏切 {@link GameChannel#GLOBAL} 会被拒
     */
    @org.jetbrains.annotations.Nullable String setChannel(@NotNull Player player,
                                                          @NotNull GameChannel channel);

    /**
     * 这局允许用全局频道吗。竞技游戏（{@code competitive(true)}）返回 false。
     */
    boolean allowsGlobal(@NotNull MiniGame game);
}
