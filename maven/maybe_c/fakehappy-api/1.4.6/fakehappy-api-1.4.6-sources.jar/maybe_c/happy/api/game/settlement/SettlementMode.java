package maybe_c.happy.api.game.settlement;

import org.jetbrains.annotations.ApiStatus;

/**
 * 结算实现的声明。选择 FRAMEWORK 后仍需调用 {@link SettlementService#settle}；
 * 选择 CUSTOM 时，调用方负责奖励计算、结算展示、返回大厅及对应合规声明。
 */
@ApiStatus.Experimental
public enum SettlementMode {

    /**
     * <b>框架结算（推荐）。</b>你只提供名次和表现，币、经验、衰减、
     * 自定义房不发奖、回游戏大厅由框架做。
     *
     * <p>规范里 {@code econ.sum}、{@code econ.exp}、{@code econ.decay} 等发奖相关的项自动通过。
     * <b>结算画面（{@code flow.settlement}）游戏自己做</b>：{@code settle(...)} 返回的
     * {@code SettlementResult} 里是每人实际到账，拿它展示；框架只把这局记进子服日志给 OP 查。
     */
    FRAMEWORK("框架结算"),

    /**
     * 自己结算：奖励也自己算、自己发。
     *
     * <p>上面那五条规范项回到「需声明」，由你自己实现并在
     * {@code GameCompliance} 里自查。<b>包括「所有玩家货币之和恰好等于 n×a」</b>——
     * 那是个浮点求和加取整的问题，自己写很容易差几个币。
     * 真要自己来的话，至少用 {@code RewardFormula.payout(...)} 算，别照公式手抄。
     */
    CUSTOM("自行结算");

    private final String display;

    SettlementMode(String display) {
        this.display = display;
    }

    public String display() {
        return display;
    }
}
