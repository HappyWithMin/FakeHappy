package maybe_c.happy.api.access;

import net.kyori.adventure.text.Component;
import org.bukkit.plugin.Plugin;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;

/**
 * 子服准入锁：锁住的子服只让放行名单上的人和有豁免权限的人进。
 *
 * <p>和 {@link maybe_c.happy.api.event.EventApi} 无关：不受「同时只能有一场活动」和内置抽奖的限制，
 * 每台子服各锁各的，可以同时锁好几台。适合大厅插件自己办抽奖 / 报名活动、只把「谁能进目标子服」交给 FakeHappy。
 *
 * <h2>行为</h2>
 * <ul>
 *   <li><b>拦在哪</b>：代理在切服前拒绝，玩家留在原来的服并看到 denyMessage；
 *       直接登录到被锁子服的人改送到 fallbackServer。目标子服装了 FakeHappy 的话进服时再查一遍兜底。</li>
 *   <li><b>豁免</b>：{@link #BYPASS_PERMISSION} 或活动的豁免权限（默认 OP 都有）。
 *       子服上的权限会同步给代理，直接在代理上给也认。
 *       锁的 {@link LockOptions#exemptMayEnter()} 为 false 时豁免不算数：OP 也要在放行名单上才能进、能上场，清人也一起清。</li>
 *   <li><b>持久化</b>：锁存在跨服层，没有过期时间；子服、大厅、代理重启后仍然有效。</li>
 *   <li><b>持有者失效</b>：插件卸载 / 崩溃时锁保留。插件重启后用 {@link #locks()} 找回自己的锁；
 *       管理员可以在 FakeHappy 的管理面板里强制解锁。</li>
 *   <li><b>清人范围</b>：{@link #evacuate} 只处理此刻已经在该子服上的人。锁生效后才连过去的人
 *       （包括锁之前就在路上的）会在进服那一刻被代理送去锁上记录的 fallbackServer。</li>
 *   <li><b>测试局积分</b>：子服锁着就不发（货币、经验照发），与 eventRound 无关。</li>
 *   <li><b>活动局</b>：{@link LockOptions#eventRound()} 为 true（默认）时，被锁子服的游戏按活动目标子服对待：
 *       {@code HappyApi.eventModeHere()} 为 true、不自动开局（OP 强制开始照常）、只有放行名单和豁免的人能上场、
 *       自定义房照常发奖。</li>
 * </ul>
 *
 * <h2>线程</h2>
 * 方法可以在任意线程调用；返回的 future 一般在 IO 线程完成，碰 Bukkit 对象前自己切回主线程。
 * 失败不抛异常，看 {@link Result#status()}。
 */
public interface AccessService {

    /** 不在放行名单也能进被锁子服的权限。 */
    String BYPASS_PERMISSION = "fakehappy.access.bypass";

    /** 跨服层可用。false 时所有写操作返回 {@link Status#UNAVAILABLE}。 */
    boolean isAvailable();

    /**
     * 锁定子服。没锁过就新建（放行名单为空）；自己已经持有就只更新选项，放行名单和锁定时间不变；
     * 被别的插件锁着返回 {@link Status#NOT_OWNER}。
     *
     * <p>{@code evacuateOnLock} 为 true 时会等清人做完再完成，结果写在 {@link Result#message()}，
     * 需要逐人结果就自己再调一次 {@link #evacuate}。
     *
     * @param serverId 子服 ID（代理配置里的子服名），也认子服显示名
     */
    @NotNull CompletableFuture<Result> lock(@NotNull Plugin owner, @NotNull String serverId, @NotNull LockOptions options);

    /** 解锁。只有持有者能解；没锁着返回 {@link Status#NOT_LOCKED}。 */
    @NotNull CompletableFuture<Result> unlock(@NotNull Plugin owner, @NotNull String serverId);

    /** 整体替换放行名单（例如开奖后写入中奖者）。只有持有者能改，最多 {@link #MAX_ALLOWLIST} 人。 */
    @NotNull CompletableFuture<Result> setAllowlist(@NotNull Plugin owner, @NotNull String serverId,
                                                    @NotNull Collection<UUID> players);

    /**
     * 把该子服上此刻在线、不在放行名单、也没有豁免权限的人送到 fallbackServer。
     * 由每台代理处理自己手上的人，回执汇总所有代理的结果；最多等 10 秒。
     * 只有持有者能调，子服没锁着时什么也不做。
     */
    @NotNull CompletableFuture<EvacuateReceipt> evacuate(@NotNull Plugin owner, @NotNull String serverId,
                                                         @NotNull String fallbackServer);

    /**
     * 同 {@link #evacuate(Plugin, String, String)}。{@code includeExempt} 为 true 时有豁免权限的人（OP 默认有）也送走，
     * 只留放行名单上的人 —— 名单上的 OP 照样留下。之后豁免的人自己再连过来不拦。
     *
     * @since 1.4.2
     */
    default @NotNull CompletableFuture<EvacuateReceipt> evacuate(@NotNull Plugin owner, @NotNull String serverId,
                                                                 @NotNull String fallbackServer, boolean includeExempt) {
        if (!includeExempt) return evacuate(owner, serverId, fallbackServer);
        return CompletableFuture.completedFuture(new EvacuateReceipt(serverId, fallbackServer, Status.UNAVAILABLE,
                "服务器上的 FakeHappy 太老，不支持连豁免的人一起清", List.of(), 0, 0));
    }

    /** 直接读跨服层的当前状态。没锁着是 {@code Optional.empty()}；读不到（跨服层断了）future 异常完成。 */
    @NotNull CompletableFuture<Optional<LockState>> state(@NotNull String serverId);

    /** 全网所有的锁。插件重启后据此恢复自己的状态。读不到时 future 异常完成。 */
    @NotNull CompletableFuture<List<LockState>> locks();

    /** 放行名单上限。 */
    int MAX_ALLOWLIST = 2000;

    enum Status {
        SUCCEEDED,
        /** 被别的插件锁着；{@link Result#state()} 里能看到是谁。 */
        NOT_OWNER,
        /** 这台子服没锁着。 */
        NOT_LOCKED,
        /** 参数不对：子服 ID 为空、名单超上限、插件没启用、要清人却没给 fallbackServer。 */
        INVALID,
        /** 跨服层没连上或写入一直冲突，什么都没改。 */
        UNAVAILABLE
    }

    /** @param state 操作后的锁；解锁成功、或读不到时为 null */
    record Result(@NotNull Status status, @NotNull String message, @Nullable LockState state) {
        public boolean succeeded() {
            return status == Status.SUCCEEDED;
        }
    }

    /**
     * @param evacuateOnLock 锁定的同时清人
     * @param fallbackServer 清人目的地；直接登录到被锁子服、或锁生效时还在路上的人也送去这里。可以为 null（不清人时）
     * @param denyMessage    被拒时给玩家看的文字；null 用默认的「本场活动暂不可进入」
     * @param eventRound     游戏按活动局对待：不自动开局等（见类注释）；不影响测试局积分，锁着就不发
     * @param exemptMayEnter 有豁免权限的人（OP 默认有）不在放行名单上也能进、能上场。false = 只认名单，
     *                       OP 没在名单上也进不去，清人时也一起清（三个参数的 evacuate 也清）。默认 true
     */
    record LockOptions(boolean evacuateOnLock, @Nullable String fallbackServer, @Nullable Component denyMessage,
                       boolean eventRound, boolean exemptMayEnter) {
        /** eventRound、exemptMayEnter 默认 true。 */
        public LockOptions(boolean evacuateOnLock, @Nullable String fallbackServer, @Nullable Component denyMessage) {
            this(evacuateOnLock, fallbackServer, denyMessage, true, true);
        }

        /** exemptMayEnter 默认 true。 */
        public LockOptions(boolean evacuateOnLock, @Nullable String fallbackServer, @Nullable Component denyMessage,
                           boolean eventRound) {
            this(evacuateOnLock, fallbackServer, denyMessage, eventRound, true);
        }
    }

    /**
     * @param serverId 子服 ID（统一成小写）
     * @param owner    持有锁的插件名
     * @param lockedAt 第一次锁上的时间（毫秒）
     */
    record LockState(@NotNull String serverId, @NotNull String owner, @NotNull Set<UUID> allowlist, long lockedAt,
                     @Nullable String fallbackServer, @Nullable Component denyMessage, boolean eventRound,
                     boolean exemptMayEnter) {
        public LockState {
            allowlist = Set.copyOf(allowlist);
        }

        public LockState(@NotNull String serverId, @NotNull String owner, @NotNull Set<UUID> allowlist, long lockedAt,
                         @Nullable String fallbackServer, @Nullable Component denyMessage, boolean eventRound) {
            this(serverId, owner, allowlist, lockedAt, fallbackServer, denyMessage, eventRound, true);
        }
    }

    enum EvacuateStatus { MOVED, FAILED }

    record EvacuatedPlayer(@NotNull UUID id, @NotNull String name, @NotNull EvacuateStatus status,
                           @NotNull String message) { }

    /**
     * @param players         被处理的人（放行的不在里面；豁免的只有 includeExempt 时才在）
     * @param proxiesAnswered 回了结果的代理数
     * @param proxiesExpected 当时在线的代理数；answered &lt; expected 说明有代理超时，那台上的人可能没清
     */
    record EvacuateReceipt(@NotNull String serverId, @NotNull String fallbackServer, @NotNull Status status,
                           @NotNull String message, @NotNull List<EvacuatedPlayer> players,
                           int proxiesAnswered, int proxiesExpected) {
        public EvacuateReceipt {
            players = List.copyOf(players);
        }

        /** 所有代理都回了，且没有人失败。 */
        public boolean complete() {
            return status == Status.SUCCEEDED && proxiesAnswered >= proxiesExpected
                    && players.stream().allMatch(p -> p.status() == EvacuateStatus.MOVED);
        }
    }

    static @NotNull AccessService unavailable() {
        return new AccessService() {
            private Result no() { return new Result(Status.UNAVAILABLE, "子服准入服务不可用", null); }
            public boolean isAvailable() { return false; }
            public @NotNull CompletableFuture<Result> lock(@NotNull Plugin o, @NotNull String s, @NotNull LockOptions l) { return CompletableFuture.completedFuture(no()); }
            public @NotNull CompletableFuture<Result> unlock(@NotNull Plugin o, @NotNull String s) { return CompletableFuture.completedFuture(no()); }
            public @NotNull CompletableFuture<Result> setAllowlist(@NotNull Plugin o, @NotNull String s, @NotNull Collection<UUID> p) { return CompletableFuture.completedFuture(no()); }
            public @NotNull CompletableFuture<EvacuateReceipt> evacuate(@NotNull Plugin o, @NotNull String s, @NotNull String f) {
                return CompletableFuture.completedFuture(new EvacuateReceipt(s, f, Status.UNAVAILABLE, "子服准入服务不可用", List.of(), 0, 0));
            }
            public @NotNull CompletableFuture<Optional<LockState>> state(@NotNull String s) { return CompletableFuture.failedFuture(new IllegalStateException("子服准入服务不可用")); }
            public @NotNull CompletableFuture<List<LockState>> locks() { return CompletableFuture.failedFuture(new IllegalStateException("子服准入服务不可用")); }
        };
    }
}
