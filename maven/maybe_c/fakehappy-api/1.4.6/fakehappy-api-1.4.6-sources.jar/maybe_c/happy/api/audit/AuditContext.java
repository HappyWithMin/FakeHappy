package maybe_c.happy.api.audit;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/**
 * 后台资产流水的来源信息。由调用方在提交异步操作前创建，不向玩家展示。
 * referenceId 用来关联一局游戏、订单或工单；它不是防重复发放的幂等键。
 */
public record AuditContext(@NotNull String source, @NotNull String actor,
                           @NotNull String reason, @Nullable String referenceId,
                           @Nullable String metadata) {
    public AuditContext {
        source = required(source, "unknown", 128);
        actor = required(actor, "SYSTEM", 128);
        reason = required(reason, "unspecified", 256);
        referenceId = optional(referenceId, 128);
        metadata = optional(metadata, 8192);
    }

    public static @NotNull AuditContext plugin(@NotNull String source, @NotNull String reason) {
        return new AuditContext(source, "SYSTEM", reason, null, null);
    }

    public static @NotNull AuditContext system(@NotNull String reason) {
        return plugin("FakeHappy", reason);
    }

    public @NotNull AuditContext withActor(@NotNull String value) {
        return new AuditContext(source, value, reason, referenceId, metadata);
    }

    public @NotNull AuditContext withReference(@Nullable String value) {
        return new AuditContext(source, actor, reason, value, metadata);
    }

    public @NotNull AuditContext withReason(@NotNull String value) {
        return new AuditContext(source, actor, value, referenceId, metadata);
    }

    public @NotNull AuditContext withMetadata(@Nullable String value) {
        return new AuditContext(source, actor, reason, referenceId, value);
    }

    private static String required(String value, String fallback, int max) {
        String normalized = value == null || value.isBlank() ? fallback : value;
        return normalized.length() <= max ? normalized : normalized.substring(0, max);
    }

    private static String optional(String value, int max) {
        if (value == null || value.isBlank()) return null;
        return value.length() <= max ? value : value.substring(0, max);
    }
}
