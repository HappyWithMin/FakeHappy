package maybe_c.happy.api.ui;

import io.papermc.paper.registry.data.dialog.input.DialogInput;
import net.kyori.adventure.text.Component;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

import java.util.function.Consumer;
import java.util.function.Function;
import java.util.List;

/** Paper 对话框菜单，客户端需要 1.21.6 或以上。输入通过 ClickContext 按键读取。 */
public interface DialogMenu extends Menu {
    interface Builder {
        /** 固定正文，字符串使用系统文本解析器。 */
        @NotNull Builder body(@NotNull String raw);
        @NotNull Builder body(@NotNull Component component);

        /** 每次绘制读取观看者的快照。返回 null 跳过；回调中不要执行数据库查询。 */
        @NotNull Builder body(@NotNull Function<Player, Component> perViewer);

        /** 固定输入控件。需要显示最新数据时使用按观看者求值的重载。 */
        @NotNull Builder input(@NotNull DialogInput input);

        /** 每次绘制生成输入控件，返回 null 隐藏该控件。 */
        @NotNull Builder input(@NotNull Function<Player, DialogInput> perViewer);

        /** 每次绘制生成一组输入控件，按添加顺序展开；返回空列表可隐藏整组。 */
        @NotNull Builder inputs(@NotNull Function<Player, List<DialogInput>> perViewer);

        @NotNull Builder button(@NotNull MenuButton button);

        /** 每次绘制生成按钮。点击使用本次绘制的快照；返回 null 隐藏该项。 */
        @NotNull Builder dynamicButton(@NotNull Function<Player, MenuButton> perViewer);

        /** 每次绘制生成完整按钮列表。长列表由客户端滚动，点击绑定这次绘制的对象快照。 */
        @NotNull Builder buttons(@NotNull Function<Player, List<MenuButton>> perViewer);

        /** 正文宽度，单位为客户端 GUI 像素。默认 300，范围 1~1024。 */
        @NotNull Builder bodyWidth(int width);

        /** 按钮宽度，单位为客户端 GUI 像素。默认 150，范围 1~300。 */
        @NotNull Builder buttonWidth(int width);

        /** 独立底部按钮，同时响应 ESC。未指定时使用关闭按钮。 */
        @NotNull Builder exitButton(@NotNull MenuButton button);

        /** 默认 1 列，最多 2 列；宽按钮会自动改为单列以避免横向溢出。 */
        @NotNull Builder columns(int columns);

        /** 默认允许 ESC。设为 false 时需提供完成操作的按钮。 */
        @NotNull Builder canCloseWithEscape(boolean canClose);

        /** 关闭菜单时触发；框架内导航不触发。 */
        @NotNull Builder onClose(@NotNull Consumer<Player> onClose);

        @NotNull Builder title(@NotNull Component title);
        @NotNull DialogMenu build();
    }
}
