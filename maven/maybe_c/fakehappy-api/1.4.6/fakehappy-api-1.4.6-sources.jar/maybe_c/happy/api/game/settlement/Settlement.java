package maybe_c.happy.api.game.settlement;

import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * 一局的结算输入。结算服务计算奖励、应用连开衰减和房间规则，返回实际回执（不给玩家展示，游戏自己展示）。
 * @param placements 全部参与者，包含中途退出者
 * @param minutes 本局时长，单位分钟
 * @param baseCoins 人均基础币数；null 使用游戏 descriptor 的默认值
 * @param roomId 房间 ID，用于房间类型和衰减；null 按普通房间处理
 * @param returnToHub 展示结束后返回游戏大厅，默认 true
 * @param ownLineOnly 已不起作用：框架不再给玩家展示结算
 */
@ApiStatus.Experimental
public record Settlement(
        @NotNull List<Placement> placements,
        double minutes,
        @Nullable Integer baseCoins,
        @Nullable String roomId,
        boolean returnToHub,
        boolean ownLineOnly
) {

    /** 1.3 之前的形状（没有 {@code ownLineOnly}），留着给直接 new 的老代码。 */
    public Settlement(@NotNull List<Placement> placements, double minutes, @Nullable Integer baseCoins,
                      @Nullable String roomId, boolean returnToHub) {
        this(placements, minutes, baseCoins, roomId, returnToHub, false);
    }

    public Settlement {
        placements = List.copyOf(placements);
        if (placements.isEmpty()) {
            throw new IllegalArgumentException("结算名单不能为空");
        }
        if (minutes < 0) {
            throw new IllegalArgumentException("时长不能为负，收到 " + minutes);
        }
    }

    public static @NotNull Builder builder() {
        return new Builder();
    }

    public static final class Builder {

        private final List<Placement> placements = new ArrayList<>();
        private double minutes;
        private Integer baseCoins;
        private String roomId;
        private boolean returnToHub = true;
        private boolean ownLineOnly;

        private Builder() {
        }

        public @NotNull Builder add(@NotNull Placement placement) {
            placements.add(placement);
            return this;
        }

        public @NotNull Builder add(@NotNull Placement.Builder placement) {
            return add(placement.build());
        }

        /** 便捷写法：只有名次，没有额外数据。 */
        public @NotNull Builder add(@NotNull UUID player, int rank) {
            return add(Placement.of(player, rank).build());
        }

        /** 本局打了多久（分钟）。经验按它算，所以别忘了填。 */
        public @NotNull Builder minutes(double minutes) {
            this.minutes = minutes;
            return this;
        }

        /** 人均基础货币。不填则用 descriptor 里声明的。 */
        public @NotNull Builder baseCoins(int a) {
            this.baseCoins = a;
            return this;
        }

        public @NotNull Builder room(@Nullable String roomId) {
            this.roomId = roomId;
            return this;
        }

        /**
         * 结算完不要把人送回游戏大厅。
         *
         * <p><b>想清楚再用。</b>规范 4.6 明确要求结算后回游戏大厅，
         * 让玩家有明确的退出与再选择机会 —— 停在等待大厅直接开下一把是被禁的。
         * 这个开关是给「压根不在房间体系里」的玩法留的口子。
         */
        public @NotNull Builder stayHere() {
            this.returnToHub = false;
            return this;
        }

        /**
         * 已不起作用：框架不再给玩家展示结算，留着只为老代码能编译。
         */
        public @NotNull Builder ownLineOnly() {
            this.ownLineOnly = true;
            return this;
        }

        public @NotNull Settlement build() {
            return new Settlement(placements, minutes, baseCoins, roomId, returnToHub, ownLineOnly);
        }
    }
}
