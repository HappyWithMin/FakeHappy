package maybe_c.happy.api.reward;

import org.jetbrains.annotations.NotNull;

import java.util.EnumSet;
import java.util.Set;

/**
 * 一次奖励发放的回执。不同资产可能部分成功。
 * <p>{@link #requested()} 是请求值，{@link #granted()} 是实际发放值，
 * {@link #skipped()} 是未成功的资产类型。结算展示和补偿应使用实际回执。
 */
public record GrantResult(@NotNull RewardBundle requested,
                          @NotNull RewardBundle granted,
                          @NotNull Set<RewardKind> skipped,
                          int levelBefore,
                          int levelAfter,
                          int pointsLevelBefore,
                          int pointsLevelAfter) {

    public GrantResult {
        skipped = skipped.isEmpty() ? Set.of() : Set.copyOf(skipped);
    }

    /** 什么都没发（一般是 {@link RewardBundle#isEmpty()} 或者服务整体不可用）。 */
    public static @NotNull GrantResult nothing(@NotNull RewardBundle requested,
                                               @NotNull Set<RewardKind> skipped) {
        return new GrantResult(requested, RewardBundle.NOTHING, skipped, 0, 0, 0, 0);
    }

    /** 没有资产被标记为失败；实际数量仍以 {@link #granted()} 为准。 */
    public boolean complete() {
        return skipped.isEmpty();
    }

    /** 这次发放让玩家升级了。跨多级也只算一次。 */
    public boolean leveledUp() {
        return levelAfter > levelBefore;
    }

    public boolean pointsLeveledUp() {
        return pointsLevelAfter > pointsLevelBefore;
    }

    /** 未成功的资产类型，包括后端不可用和事务失败。 */
    public @NotNull Set<RewardKind> missing() {
        return skipped.isEmpty() ? EnumSet.noneOf(RewardKind.class) : EnumSet.copyOf(skipped);
    }
}
