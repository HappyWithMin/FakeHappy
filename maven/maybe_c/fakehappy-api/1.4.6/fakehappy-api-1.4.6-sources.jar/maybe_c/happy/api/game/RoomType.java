package maybe_c.happy.api.game;

/**
 * 房间类型，决定对应奖励规则。自定义房不发放规范中的币与经验；调用方应准确声明，结算服务读取该类型。
 */
public enum RoomType {

    /**
     * 普通房间（6.1）。无特殊规则，开局条件由系统自动接管，
     * 正常结算并发放局外奖励。
     */
    NORMAL("普通", true),

    /**
     * 自定义房间（6.2）。房主手动开局，<b>不发放任何局外奖励</b>
     * （含货币与经验）。玩家自娱、赛前练习用。
     *
     * <p>这也是活动私人房走的类型。
     */
    CUSTOM("自定义", false),

    /**
     * 比赛房间（6.3）。房主手动开局，正常结算并发放局外奖励。
     * 创建应限制在具备相应权限的账号。
     */
    MATCH("比赛", true);

    private final String display;
    private final boolean rewards;

    RoomType(String display, boolean rewards) {
        this.display = display;
        this.rewards = rewards;
    }

    public String display() {
        return display;
    }

    /**
     * 这类房间发不发局外奖励（货币 + 经验）。
     *
     * <p>结算时<b>必须</b>查这个再决定发不发 —— 别自己 if 房间名判断。
     */
    public boolean grantsRewards() {
        return rewards;
    }

    /** 需要房主手动触发开局的类型（6.2 / 6.3）。 */
    public boolean manualStart() {
        return this != NORMAL;
    }
}
