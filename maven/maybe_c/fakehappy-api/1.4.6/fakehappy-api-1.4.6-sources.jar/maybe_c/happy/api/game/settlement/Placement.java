package maybe_c.happy.api.game.settlement;

import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;

/**
 * 玩家在本局的名次、胜负、表现和展示数据，奖励由结算服务计算。
 * @param player 玩家 UUID
 * @param rank 名次，从 1 开始；允许并列
 * @param won 是否胜方，经验加成 30%
 * @param mvp 是否 MVP，经验加成 50%，可与胜利叠加
 * @param quitEarly 是否中途退出，按规范获得 50% 经验且不发币
 * @param stats 按迭代顺序展示的数据
 */
@ApiStatus.Experimental
public record Placement(
        @NotNull UUID player,
        int rank,
        boolean won,
        boolean mvp,
        boolean quitEarly,
        @NotNull Map<String, String> stats
) {

    public Placement {
        if (rank < 1) throw new IllegalArgumentException("名次从 1 开始，收到 " + rank);
        stats = Map.copyOf(stats);
    }

    /** 最常见的写法：只有名次。 */
    public static @NotNull Builder of(@NotNull UUID player, int rank) {
        return new Builder(player, rank);
    }

    public static final class Builder {

        private final UUID player;
        private final int rank;
        private boolean won;
        private boolean mvp;
        private boolean quitEarly;
        private final Map<String, String> stats = new LinkedHashMap<>();

        private Builder(UUID player, int rank) {
            this.player = player;
            this.rank = rank;
        }

        /** 属于胜方。经验 +30%。 */
        public @NotNull Builder won() {
            this.won = true;
            return this;
        }

        /** 本局 MVP。经验 +50%，和 {@link #won()} 叠加。 */
        public @NotNull Builder mvp() {
            this.mvp = true;
            return this;
        }

        /**
         * 中途退出的人。
         *
         * <p><b>别把他们从名单里去掉</b> —— 规范 11.4 要求他们仍得 50% 经验，
         * 漏掉等于少发。而且结算界面上少一个人，其他人会以为是 bug。
         */
        public @NotNull Builder quitEarly() {
            this.quitEarly = true;
            return this;
        }

        /** 结算界面上展示一项数据。按调用顺序展示。 */
        public @NotNull Builder stat(@NotNull String label, @Nullable Object value) {
            if (value != null) stats.put(label, String.valueOf(value));
            return this;
        }

        public @NotNull Placement build() {
            return new Placement(player, rank, won, mvp, quitEarly, stats);
        }
    }
}
