package maybe_c.happy.api.game;

import net.kyori.adventure.text.Component;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Set;
import java.util.UUID;

/**
 * 一个小游戏。<b>这是小游戏接入本服的唯一契约。</b>
 *
 * <p>实现它并 {@link GameRegistry#register 注册}之后，你的游戏会自动获得：
 * <ul>
 *   <li>出现在大厅的小游戏选择 UI 里</li>
 *   <li>出现在 OP 场控面板里，OP 能在游戏内强制开始 / 结束 / 重置</li>
 *   <li>参与者自动被可见性隔离（{@link GameDescriptor#isolateVisibility()}）</li>
 *   <li>参与者自动豁免大厅保护</li>
 *   <li>玩家退出 / 换服 / 死亡时框架帮你调 {@link #quit}，不会留下幽灵参与者</li>
 *   <li>{@code crossServer} 为 true 时房间状态自动上报，代理侧能跨节点排队</li>
 * </ul>
 *
 * <h2>实现要求</h2>
 * <ul>
 *   <li>所有方法都在<b>主线程</b>调用，实现里不要阻塞。</li>
 *   <li>{@link #players()} 必须便宜（大厅 UI 每秒会问很多次），
 *       返回内部集合的<b>不可变视图或副本</b>，不要让调用方能改。</li>
 *   <li>{@link #quit} 必须幂等，且要能处理「玩家对象已经离线」的情况 ——
 *       框架是在 PlayerQuitEvent 里调它的。</li>
 *   <li>状态变化请走 {@link GameRegistry#setState}，不要自己改字段后不通知，
 *       否则大厅 UI 和跨服房间信息会和实际不一致。</li>
 * </ul>
 */
public interface MiniGame {

    /** 静态元数据。同一个实例每次返回同一个对象即可，不要每次新建。 */
    @NotNull GameDescriptor descriptor();

    /**
     * 当前状态。
     *
     * <p>同时开好几局的游戏，这里返回的是<b>聚合状态</b>：
     * 有任何一局在跑就是 RUNNING，都空着就是 WAITING / IDLE。
     * 逐局的状态在 {@link #rooms()} 里。
     */
    @NotNull GameState state();

    /**
     * 本机当前开着的局。
     *
     * <p>默认实现按「整个游戏就是一局」返回单个房间，单局制的游戏不用管这个方法。
     * 同时开多局的（一个子服上几块场地各跑一局）要覆写它，否则大厅 UI
     * 和跨服排队只能看到一个笼统的总数，没法把玩家分配到具体某一局。
     *
     * <p>框架会周期性调用它做跨服上报，所以<b>要便宜</b>，
     * 别在里面查数据库。
     *
     * <p>覆写了它（同时开多局）就要一起覆写 {@link #roomOf}：框架靠它知道每个人在哪一局，
     * 聊天、大厅保护、语音、可见性隔离才能按局分开。
     */
    default @NotNull java.util.Collection<GameRoom> rooms() {
        return java.util.List.of(GameRoom.normal(
                "main", state(), players().size(),
                descriptor().maxPlayers(), descriptor().minPlayers()));
    }

    /**
     * 当前参与者（不含旁观者）。
     * 返回不可变视图或副本；调用方每 tick 都可能问，实现要便宜。
     */
    @NotNull Set<UUID> players();

    /** 当前旁观者。不支持旁观就返回空集。 */
    default @NotNull Set<UUID> spectators() {
        return Set.of();
    }

    /**
     * 这个玩家现在能加入吗。
     *
     * @return null = 可以加入；非 null = 拒绝理由（会直接展示给玩家，
     *         所以请写成人话，并且用 {@code TextService} 解析过的 Component）
     */
    default @Nullable Component canJoin(@NotNull Player player) {
        if (!state().joinable()) {
            return Component.text("这局现在不能加入");
        }
        if (players().size() >= descriptor().maxPlayers()) {
            return Component.text("人满了");
        }
        return null;
    }

    /**
     * 让玩家加入。<b>实现里不需要再查一遍 {@link #canJoin}</b> ——
     * 框架在调这个方法之前已经查过、并且发过 {@code GamePlayerJoinEvent} 了。
     *
     * @return 是否真的加进去了。返回 false 时框架会回滚它自己做的那部分登记
     */
    boolean join(@NotNull Player player);

    /**
     * 让玩家加入<b>指定的</b>那一局。跨服排队把人分配过来时框架调这个 ——
     * 代理是按房间分配的，送到子服却随便塞进另一局的话，
     * 队友就被拆散了，而这正是跨服排队最该保证的事。
     *
     * <p>默认实现忽略 roomId 直接走 {@link #join}，单局制的游戏不用管。
     *
     * @param roomId 目标房间；这一局已经不在了（打完了 / 被重置了）时，
     *               实现可以自行决定是拒绝还是塞进别的局
     */
    default boolean joinRoom(@NotNull Player player, @NotNull String roomId) {
        return join(player);
    }

    /**
     * 让玩家离开。玩家主动退、被踢、掉线、换服都会走到这里。
     *
     * <p><b>玩家可能已经离线</b>，所以不要假设 {@code Bukkit.getPlayer(uuid)} 非空。
     * 这也是这里收 UUID 而不是 Player 的原因。
     */
    void quit(@NotNull UUID playerId);

    /** 以旁观身份加入。不支持就返回 false（默认实现）。 */
    default boolean spectate(@NotNull Player player) {
        return false;
    }

    // ------------------------------------------------------------ OP 场控

    /**
     * 强制开始，跳过人数检查和倒计时。OP 场控面板的「立即开始」走这里。
     *
     * @param by 操作者，用于记日志和给反馈
     * @return 拒绝理由；null = 成功
     */
    @Nullable Component forceStart(@NotNull CommandSender by);

    /**
     * 强制结束当前这局。
     *
     * @param reason 给参与者看的理由，可为 null
     */
    void forceStop(@NotNull CommandSender by, @Nullable Component reason);

    /**
     * 暂停 / 恢复（规范 7 章「暂停游戏」，<b>必须实现</b>）。
     *
     * <p>规范定义的语义：<b>冻结全部实体行为与倒计时，恢复后从暂停点继续</b>，
     * 并且玩家 HUD 上要明确显示「已暂停」。
     *
     * <p>默认实现返回 false（不支持）。合规检查会把没覆写的游戏标为缺失。
     *
     * @return 是否真的切换了状态。不支持时返回 false
     */
    default boolean pause(boolean paused) {
        return false;
    }

    /** 当前是不是暂停中。 */
    default boolean isPaused() {
        return false;
    }

    /**
     * 重置本局（规范 7 章「重置游戏」，<b>必须实现</b>）。
     *
     * <p><b>规范定义的语义是「把所有玩家拉回游戏等待大厅、重新开始本局，
     * 队伍与职业选择保持不变」</b> —— 不是清场。想彻底关掉房间用
     * {@link #forceStop}，那条才是「不结算不发奖直接踢回游戏大厅」。
     *
     * <p>服务器关闭和模块卸载时框架也会调这个，所以它必须能在
     * 「世界正在卸载」的情况下安全执行 —— 别在里面做异步调度。
     */
    void reset();

    /**
     * 这个玩家属于哪一队。
     *
     * <p><b>有队伍的游戏一定要覆写它</b> —— 框架靠它做队伍聊天隔离
     * （规范 10.2）、以及把全服小队编进同一支游戏内队伍（规范 5.1）。
     * 不覆写的话队伍频道会退化成全局，而那在竞技游戏里等于把报点广播给对手。
     *
     * <p>返回什么无所谓，只要<b>同队相同、异队不同</b>即可：
     * {@code "red"} / {@code "blue"}、或者队伍对象的 id 都行。
     *
     * @return 队伍标识；{@code null} = 这个游戏没有队伍概念，或者他不在局里
     */
    default @Nullable String teamOf(@NotNull UUID playerId) {
        return null;
    }

    // ------------------------------------------------------------ 多局制

    /**
     * 这个玩家（参与者或旁观者）现在在<b>哪一局</b>，返回那一局的 {@link GameRoom#roomId()}。
     *
     * <p><b>同时开好几局的游戏一定要覆写它。</b>框架里凡是说「同一局」的地方都靠它分开：
     * <ul>
     *   <li>局内聊天（规范 10.2）：全局 / 观战频道只发给同一局的人。不覆写的话，
     *       一号房的话会发到二号房去 —— 两局人互相看得见对方的聊天；</li>
     *   <li>{@link GameRegistry#sameGame} / {@link GameRegistry#isInProgressGame}：
     *       大厅保护按「这一局」开没开判断，等人那一局的人照样受保护；</li>
     *   <li>语音分房：一局一间，队伍标识里不用再自己编进局号；</li>
     *   <li>全服小队：队长进了哪一局，本服的队友就进哪一局；</li>
     *   <li>OP 场控面板：逐局开始 / 结束 / 暂停 / 重置（见下面几个带 roomId 的方法）。</li>
     * </ul>
     *
     * <p>要便宜：聊天、大厅保护每个事件都会问。
     *
     * @return 房间 ID；null = 单局制，或者他不在任何一局里
     */
    default @Nullable String roomOf(@NotNull UUID playerId) {
        return null;
    }

    /**
     * 某一局现在的状态。默认在 {@link #rooms()} 里找，找不到返回 null。
     *
     * <p>大厅保护每个事件都可能问一次，多局制的游戏最好覆写成直接查表。
     */
    default @Nullable GameState roomState(@NotNull String roomId) {
        for (GameRoom room : rooms()) {
            if (room.roomId().equals(roomId)) {
                return room.state();
            }
        }
        return null;
    }

    /** 已传送并完成分队时可开始本局语音；有准备阶段的游戏可提前返回 true。 */
    default boolean voiceReady(@Nullable String roomId) {
        return (roomId == null ? state() : roomState(roomId)) == GameState.RUNNING;
    }

    /**
     * 只对<b>某一局</b>强制开始。OP 场控面板里点某一局时走这里。
     * 默认忽略 roomId 走 {@link #forceStart(CommandSender)}，单局制的游戏不用管。
     */
    default @Nullable Component forceStart(@NotNull CommandSender by, @NotNull String roomId) {
        return forceStart(by);
    }

    /** 只结束某一局。默认走 {@link #forceStop(CommandSender, Component)}。 */
    default void forceStop(@NotNull CommandSender by, @NotNull String roomId, @Nullable Component reason) {
        forceStop(by, reason);
    }

    /** 只暂停 / 恢复某一局。默认走 {@link #pause(boolean)}。 */
    default boolean pause(@NotNull String roomId, boolean paused) {
        return pause(paused);
    }

    /** 某一局是不是暂停中。默认走 {@link #isPaused()}。 */
    default boolean isPaused(@NotNull String roomId) {
        return isPaused();
    }

    /** 只重置某一局。默认走 {@link #reset()}。 */
    default void reset(@NotNull String roomId) {
        reset();
    }

    /**
     * 语音分房要不要管这个人（装了语音拓展时）。
     *
     * <p>返回 false = 这一局不把他拖进任何语音频道：<b>人人都是对手的局</b>（单人竞技）用这个 ——
     * 按局分一间的话，全场对手在同一个频道里，谁说什么大家都听得见。已经待在上一局频道里的，照常送回大厅频道。
     *
     * <p>跟 descriptor 的 {@code voiceManaged(false)} 不一样：那个是「语音整个归我自己管，框架一个人都别碰」，
     * 这个是按人、按局说「这一局他不需要语音分组」，同一个游戏里组队的局照常分。默认 true。
     */
    default boolean autoVoice(@NotNull UUID playerId) {
        return true;
    }

    /**
     * 对规范检查项的自查声明。
     *
     * <p>框架验不了的项（结算界面、观战视角、聊天隔离……）靠这个。
     * <b>默认什么都没声明</b>，也就是默认「都没做」—— 注册时合规报告会
     * 把它们全列出来。这不是刁难，是让人知道清单在哪。
     *
     * @see maybe_c.happy.api.spec.SpecCatalog
     */
    default @NotNull maybe_c.happy.api.spec.GameCompliance compliance() {
        return maybe_c.happy.api.spec.GameCompliance.none();
    }

    /**
     * 这个游戏是否被 OP 临时关停。关停后不出现在大厅 UI 的可选项里，
     * 但仍然出现在场控面板里（好让 OP 能把它开回来）。
     */
    default boolean isLocked() {
        return state() == GameState.DISABLED;
    }
}
