package maybe_c.happy.api.game.settlement;

import maybe_c.happy.api.reward.GrantResult;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * 结算回执。奖励展示、日志和成就使用实际发放值，避免把请求或理论奖励当作到账。
 * @param paid 各玩家实际奖励
 * @param rewarded 是否执行奖励发放；自定义房为 false
 * @param note 未发奖原因，正常发奖时为 null
 */
@ApiStatus.Experimental
public record SettlementResult(
        @NotNull Map<UUID, Payout> paid,
        boolean rewarded,
        @Nullable String note
) {

    /**
     * 一个人实际拿到的东西。
     *
     * @param coins  实际到账的货币（已经过衰减、自定义房归零）
     * @param exp    实际到账的经验
     * @param grant  底层发放结果。{@code skipped()} 里能看到「哪一项没发出去」，
     *               比如本服没有可用的经济系统时币发不掉但经验照常
     */
    public record Payout(int coins, int exp, @Nullable GrantResult grant) {
    }

    public @NotNull List<UUID> players() {
        return List.copyOf(paid.keySet());
    }
}
