package maybe_c.happy.api.event;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import java.util.UUID;
import java.util.function.ToDoubleFunction;

/** 可独立测试、可被小游戏复用的抽奖算法。候选资格由调用方决定。 */
public final class EventLottery {
    public static final EventLottery INSTANCE = new EventLottery();
    private EventLottery() { }

    public record Candidate(@NotNull UUID id, @NotNull String name, int contributionLevel,
                            long weight, boolean guaranteed) {
        public Candidate {
            java.util.Objects.requireNonNull(id, "id");
            java.util.Objects.requireNonNull(name, "name");
            name = name.strip();
            if (name.isEmpty()) throw new IllegalArgumentException("name 不能为空");
            if (weight < 1) weight = 1;
        }
    }

    public record Request(int slots, double contributionShare, @NotNull List<Candidate> candidates) {
        public Request {
            if (slots < 0) throw new IllegalArgumentException("slots 不能为负数");
            if (!Double.isFinite(contributionShare)) throw new IllegalArgumentException("contributionShare 无效");
            candidates = List.copyOf(candidates);
            java.util.Set<UUID> ids = new java.util.HashSet<>();
            java.util.Set<String> names = new java.util.HashSet<>();
            for (Candidate candidate : candidates) {
                if (!ids.add(candidate.id()) || !names.add(candidate.name().toLowerCase(java.util.Locale.ROOT)))
                    throw new IllegalArgumentException("候选身份重复");
            }
        }
    }

    public record Result(@NotNull List<Candidate> guaranteed, @NotNull List<Candidate> contribution,
                         @NotNull List<Candidate> open) {
        public Result {
            guaranteed = List.copyOf(guaranteed);
            contribution = List.copyOf(contribution);
            open = List.copyOf(open);
        }

        public @NotNull List<Candidate> all() {
            List<Candidate> out = new ArrayList<>(guaranteed);
            out.addAll(contribution);
            out.addAll(open);
            return List.copyOf(out);
        }
    }

    /** 先占用必中名额，再按贡献轮和全员轮填满剩余名额；总结果不会超过 slots。 */
    public static @NotNull Result draw(@NotNull Request request, @NotNull Random random) {
        List<Candidate> fixed = request.candidates().stream().filter(Candidate::guaranteed).toList();
        int fixedCount = Math.min(request.slots(), fixed.size());
        List<Candidate> guaranteed = fixed.subList(0, fixedCount);
        int room = Math.max(0, request.slots() - guaranteed.size());
        if (room == 0) return new Result(guaranteed, List.of(), List.of());

        List<Candidate> pool = new ArrayList<>(request.candidates());
        pool.removeAll(guaranteed);
        double share = Math.max(0, Math.min(1, request.contributionShare()));
        int contributionSlots = (int) Math.round(room * share);
        List<Candidate> withContribution = pool.stream().filter(c -> c.contributionLevel() > 0).toList();
        List<Candidate> contribution = pick(withContribution, Math.min(room, contributionSlots),
                c -> c.contributionLevel(), random);
        pool.removeAll(contribution);
        List<Candidate> open = pick(pool, room - contribution.size(), c -> c.weight(), random);
        return new Result(guaranteed, contribution, open);
    }

    private static <T> @NotNull List<T> pick(@NotNull List<T> source, int count,
                                             @NotNull ToDoubleFunction<T> weight, @NotNull Random random) {
        List<T> left = new ArrayList<>(source), out = new ArrayList<>();
        while (out.size() < count && !left.isEmpty()) {
            double total = left.stream().mapToDouble(x -> Math.max(0, weight.applyAsDouble(x))).sum();
            if (total <= 0) {
                Collections.shuffle(left, random);
                out.addAll(left.subList(0, Math.min(count - out.size(), left.size())));
                break;
            }
            double hit = random.nextDouble() * total, cursor = 0;
            int selected = left.size() - 1;
            for (int i = 0; i < left.size(); i++) {
                cursor += Math.max(0, weight.applyAsDouble(left.get(i)));
                if (hit < cursor) { selected = i; break; }
            }
            out.add(left.remove(selected));
        }
        return List.copyOf(out);
    }
}
