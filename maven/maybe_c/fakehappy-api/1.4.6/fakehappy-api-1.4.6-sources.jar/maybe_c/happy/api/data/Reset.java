package maybe_c.happy.api.data;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/**
 * 数据重置周期。到期时间按服务端配置的时区和统一重置时刻计算；读取时检查到期，无须为每个键创建任务。
 */
public enum Reset {

    /** 不自动作废。等同于不带过期时间的写入。 */
    NEVER,

    /** 下一个整点。适合命令冷却、限时提示这类短命的东西。 */
    HOURLY,

    /** 下一个重置时刻（默认每天 0 点）。签到、日常任务用这个。 */
    DAILY,

    /** 下一个重置日的重置时刻（默认周一 0 点）。周常用这个。 */
    WEEKLY,

    /** 下个月 1 号的重置时刻。月度榜单标记之类。 */
    MONTHLY;

    /** 配置里写错时用得上：认不出来的名字回落到 {@code def} 而不是抛异常。 */
    public static @NotNull Reset parse(@Nullable String s, @NotNull Reset def) {
        if (s == null) return def;
        for (Reset r : values()) {
            if (r.name().equalsIgnoreCase(s.trim())) return r;
        }
        return def;
    }
}
