package maybe_c.happy.api.reward;

import org.jetbrains.annotations.NotNull;

/**
 * 规范第十一章的奖励公式，纯计算，无 Bukkit 或数据库调用。
 * <p>{@link #payout} 计算整张名次表并补偿舍入余数，使总额等于 {@code n × a}。
 * 经验与连续开局衰减分别通过对应方法计算。
 */
public final class RewardFormula {

    private RewardFormula() {
    }

    // ================================================================ 货币

    /**
     * 幂次控制模型（规范 11.1）。
     *
     * <pre>
     *                       (n - r + 1)^σ
     *   S(r) = (n × a) × ───────────────────
     *                        Σ_{i=1..n} i^σ
     * </pre>
     *
     * 第一名的权重是 {@code n^σ}，末名是 {@code 1}。分母恰好等于所有权重之和，
     * 所以理论总额精确等于 {@code n × a}。
     *
     * <h3>为什么要一次算完整张表，而不是提供一个「算第 r 名」的方法</h3>
     * 单独算每一名再取整，误差会累积 —— n=7、a=100 时很容易多出或少掉几个币，
     * 而验收项要求「不多不少」。这里先算浮点分配，再把取整产生的余数<b>补给前几名</b>
     * （名次越靠前补得越早），保证 {@code sum == n * a}。
     *
     * @param n     参与人数，必须 ≥ 1
     * @param a     人均基础积分，总奖池 = n × a
     * @param sigma 差距控制系数 σ &gt; 0。娱乐 0.5~1.0 / 竞技 1.5~2.5 / 赢家通吃 ≥3.0
     * @return 长度为 n 的数组，下标 0 是第一名。总和恒等于 {@code n * a}
     * @throws IllegalArgumentException 参数不合法
     */
    public static int @NotNull [] payout(int n, int a, double sigma) {
        if (n < 1) throw new IllegalArgumentException("人数至少为 1，收到 " + n);
        if (a < 0) throw new IllegalArgumentException("人均基础积分不能为负，收到 " + a);
        if (!(sigma > 0) || !Double.isFinite(sigma)) {
            throw new IllegalArgumentException("σ 必须是大于 0 的有限数，收到 " + sigma);
        }

        final long pool = (long) n * a;
        int[] out = new int[n];
        if (pool == 0) return out;

        // 分母：Σ i^σ (i = 1..n)。同时它也是所有权重之和，
        // 因为 {n-r+1 : r=1..n} 就是 {1..n} 换了个顺序
        double denom = 0;
        for (int i = 1; i <= n; i++) denom += Math.pow(i, sigma);

        long assigned = 0;
        for (int r = 1; r <= n; r++) {
            double share = pool * Math.pow(n - r + 1, sigma) / denom;
            int v = (int) Math.floor(share);
            out[r - 1] = v;
            assigned += v;
        }

        // 取整丢掉的余数补给前几名。补给末名的话会出现「倒数第一比倒数第二拿得多」
        long remainder = pool - assigned;
        for (int i = 0; i < n && remainder > 0; i++, remainder--) {
            out[i]++;
        }
        return out;
    }

    /**
     * 单独取第 r 名该拿多少。内部仍然走 {@link #payout}，
     * 所以和整表算出来的结果<b>一致</b>。
     *
     * <p>只在「我只关心这一个人」的场景用。要发全场就直接用 payout，别循环调这个 ——
     * 那是 O(n²)。
     *
     * @param r 名次，1 起算
     */
    public static int payoutOf(int n, int a, double sigma, int r) {
        if (r < 1 || r > n) throw new IllegalArgumentException("名次超出 1.." + n + "，收到 " + r);
        return payout(n, a, sigma)[r - 1];
    }

    /**
     * 独立成就奖励的上限（规范 11.2）：单局所有独立成就之和不得超过 {@code n × a} 的 50%。
     *
     * @return 这一局最多还能发多少独立成就币
     */
    public static int achievementCap(int n, int a) {
        return (int) ((long) n * a / 2);
    }

    // ================================================================ 经验

    /** 默认每分钟经验（规范 11.3）。 */
    public static final int DEFAULT_RATE_PER_MIN = 5;

    /** 默认单局经验封顶对应的时长，分钟（规范 11.3）。 */
    public static final int DEFAULT_CAP_MINUTES = 30;

    /** 胜利方经验加成（规范 11.3）。 */
    public static final double WIN_BONUS = 0.30;

    /** MVP 经验加成，与胜利加成<b>叠加</b>（规范 11.3）。 */
    public static final double MVP_BONUS = 0.50;

    /** 中途退出只给已参与时长对应经验的一半，且不给货币（规范 11.4）。 */
    public static final double QUIT_EARLY_RATIO = 0.50;

    /**
     * 经验发放（规范 11.3）。
     *
     * <pre>EXP = base + rate × min(t, T_cap)</pre>
     *
     * 胜利 +30%、MVP +50%，两者叠加（即胜利的 MVP 拿 ×1.8）。
     *
     * @param base       参与奖励。<b>中途退出的玩家拿不到</b>，见 {@link #expQuitEarly}
     * @param ratePerMin 每分钟经验，默认 {@link #DEFAULT_RATE_PER_MIN}
     * @param minutes    实际参与时长（分钟）
     * @param capMinutes 封顶时长，默认 {@link #DEFAULT_CAP_MINUTES}
     * @param won        是不是胜利方
     * @param mvp        是不是 MVP
     */
    public static int exp(int base, int ratePerMin, double minutes, int capMinutes,
                          boolean won, boolean mvp) {
        double t = Math.max(0, Math.min(minutes, capMinutes));
        double v = base + ratePerMin * t;
        // 「叠加」按相加算：胜利的 MVP 是 ×(1 + 0.3 + 0.5) = ×1.8。
        // 若按相乘是 ×1.95，规范原文写的是「与胜利加成叠加」，取相加
        double bonus = (won ? WIN_BONUS : 0) + (mvp ? MVP_BONUS : 0);
        return (int) Math.round(v * (1 + bonus));
    }

    /** 用规范默认值的简写。 */
    public static int exp(int base, double minutes, boolean won, boolean mvp) {
        return exp(base, DEFAULT_RATE_PER_MIN, minutes, DEFAULT_CAP_MINUTES, won, mvp);
    }

    /**
     * 中途退出的经验（规范 11.4）：只给已参与时长对应经验的 50%，
     * <b>不含参与奖励 base</b>（那条明说了「未中途退出即可获得」），也不给任何加成。
     */
    public static int expQuitEarly(int ratePerMin, double minutes, int capMinutes) {
        double t = Math.max(0, Math.min(minutes, capMinutes));
        return (int) Math.round(ratePerMin * t * QUIT_EARLY_RATIO);
    }

    public static int expQuitEarly(double minutes) {
        return expQuitEarly(DEFAULT_RATE_PER_MIN, minutes, DEFAULT_CAP_MINUTES);
    }

    // ================================================================ 防刷

    /**
     * 同一房间连续开局的货币衰减系数（规范 11.4）。
     *
     * <p>第 1~3 局 100%，第 4~6 局 80%，第 7 局起 50%。
     *
     * @param consecutive 这是该玩家在同一房间连续的第几局，1 起算
     */
    public static double decay(int consecutive) {
        if (consecutive >= 7) return 0.50;
        if (consecutive >= 4) return 0.80;
        return 1.00;
    }

    /** 把衰减套到一个货币数额上。 */
    public static int applyDecay(int coins, int consecutive) {
        return (int) Math.round(coins * decay(consecutive));
    }
}
