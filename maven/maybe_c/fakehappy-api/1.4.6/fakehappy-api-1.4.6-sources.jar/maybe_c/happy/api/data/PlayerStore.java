package maybe_c.happy.api.data;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.time.Duration;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;

/**
 * 带命名空间的玩家键值存储，适合小型跨服偏好与进度。
 * <p>命名空间最多 20 字符，键名最多 36 字符，值最多 255 字符；非法键抛出异常。
 * 查询使用缓存，过期按统一重置规则检查；确认保存使用带回执的方法。
 */
public interface PlayerStore {

    /** 这个存储的命名空间。 */
    @NotNull String namespace();

    // ---------------------------------------------------------------- 读

    /**
     * 读。<b>只读本机内存，主线程可以随便调</b> —— 玩家进服时框架已经预热过。
     *
     * <p>已经过期的值读不到，返回 {@code def}。离线玩家同理（内存里没有），
     * 要读离线玩家请用 {@link #fetch}。
     */
    @NotNull String get(@NotNull UUID player, @NotNull String key, @NotNull String def);

    /** 异步读，内存没有就回落到跨服缓存 / 数据库。离线玩家用这个。 */
    @NotNull CompletableFuture<String> fetch(@NotNull UUID player, @NotNull String key,
                                             @NotNull String def);

    /**
     * 这个键什么时候过期，毫秒时间戳。{@code 0} 表示没设过或者永不过期。
     *
     * <p>用来显示「距离重置还有 3 小时 12 分」。同 {@link #get}，读的是内存。
     */
    long expiresAt(@NotNull UUID player, @NotNull String key);

    /** 这个玩家在本命名空间下的全部键值（已滤掉过期的）。内存读，键名不带前缀。 */
    @NotNull Map<String, String> all(@NotNull UUID player);

    // ---------------------------------------------------------------- 写

    /** 写，永不过期。 */
    void set(@NotNull UUID player, @NotNull String key, @NotNull String value);

    /**
     * 写，{@code ttl} 之后过期。
     *
     * <p>「从现在起多久」语义。要的是「每天 0 点重置」请用
     * {@link #set(UUID, String, String, Reset)}，别在这里传 24 小时 ——
     * 那会让每个玩家的重置时刻都不一样。
     *
     * @param ttl 传 {@code null} 或非正值等同于永不过期
     */
    void set(@NotNull UUID player, @NotNull String key, @NotNull String value,
             @Nullable Duration ttl);

    /** 写，到下一个重置时刻作废。签到、日常任务用这个，见 {@link Reset}。 */
    void set(@NotNull UUID player, @NotNull String key, @NotNull String value,
             @NotNull Reset cycle);

    /** 删。等同于写空串（框架里空串是「没有」的墓碑值）。 */
    void remove(@NotNull UUID player, @NotNull String key);

    /** 确认数据库已写入后返回 true；失败或旧实现不支持时返回 false。 */
    default @NotNull CompletableFuture<Boolean> setAsync(@NotNull UUID player, @NotNull String key,
                                                         @NotNull String value) {
        return CompletableFuture.completedFuture(false);
    }

    /** 有确认回执的相对时长写入。 */
    default @NotNull CompletableFuture<Boolean> setAsync(@NotNull UUID player, @NotNull String key,
                                                         @NotNull String value, @Nullable Duration ttl) {
        return CompletableFuture.completedFuture(false);
    }

    /** 有确认回执的重置周期写入。 */
    default @NotNull CompletableFuture<Boolean> setAsync(@NotNull UUID player, @NotNull String key,
                                                         @NotNull String value, @NotNull Reset cycle) {
        return CompletableFuture.completedFuture(false);
    }

    /** 有效值仍等于 expected 才保存；空串代表缺失、墓碑或过期，冲突或失败返回 false。 */
    default @NotNull CompletableFuture<Boolean> compareAndSet(@NotNull UUID player, @NotNull String key,
                                                              @NotNull String expected, @NotNull String value) {
        return CompletableFuture.completedFuture(false);
    }

    // ---------------------------------------------------------------- 便捷

    default int getInt(@NotNull UUID player, @NotNull String key, int def) {
        try {
            return Integer.parseInt(get(player, key, String.valueOf(def)));
        } catch (NumberFormatException e) {
            // 手工改过、或者上个版本存的是别的格式 —— 返回默认值比抛异常有用
            return def;
        }
    }

    default void setInt(@NotNull UUID player, @NotNull String key, int value) {
        set(player, key, String.valueOf(value));
    }

    default boolean getBool(@NotNull UUID player, @NotNull String key, boolean def) {
        return Boolean.parseBoolean(get(player, key, String.valueOf(def)));
    }

    default void setBool(@NotNull UUID player, @NotNull String key, boolean value) {
        set(player, key, String.valueOf(value));
    }

    /** 这个键现在有值吗（存在、非空、没过期）。 */
    default boolean has(@NotNull UUID player, @NotNull String key) {
        return !get(player, key, "").isEmpty();
    }
}
