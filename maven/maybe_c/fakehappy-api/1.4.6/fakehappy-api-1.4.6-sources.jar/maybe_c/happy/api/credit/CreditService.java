package maybe_c.happy.api.credit;

import org.jetbrains.annotations.NotNull;

import java.util.Optional;
import java.util.OptionalInt;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;

/**
 * 信用分与隐藏分的只读查询。用 {@code HappyApi.credit()} 拿；信用分模块没启用时拿到的是
 * {@link #unavailable()}（{@link #available()} 为 false，所有人都按满分、都放行）。
 *
 * <ul>
 *   <li><b>信用分</b>（0 ~ {@link #MAX}）：全网一份。分低了公屏不能说话、不能组队、进不了组队玩法 ——
 *       这些拦截由框架做，小游戏不用管。</li>
 *   <li><b>隐藏分</b>（0 ~ {@link #MAX}）：给 OP 和小游戏匹配参考的内部评分，{@link #MAX} 为正常。
 *       <b>不要显示给玩家</b>。</li>
 * </ul>
 *
 * <p><b>线程</b>：{@link #credit}、{@link #hiddenScore}、{@link #canJoinTeamGames} 只读本服缓存，
 * 主线程随便调；缓存里只有此刻在本服的玩家。别的人用 {@link #load}（异步查库，回调在 IO 线程）。
 *
 * <p>本接口只读。分数怎么变由框架按聊天和对局自己算，小游戏不用上报。
 */
public interface CreditService {

    /** 两种分的满分。 */
    int MAX = 100;

    /** 一个玩家的两种分。 */
    record Scores(int credit, int hiddenScore) {
    }

    /** 信用分模块开着、数据库连着。 */
    boolean available();

    /** 本服在线玩家的信用分；不在本服、还没读到、模块没开时为空。 */
    @NotNull OptionalInt credit(@NotNull UUID player);

    /** 本服在线玩家的隐藏分；不在本服、还没读到、模块没开时为空。 */
    @NotNull OptionalInt hiddenScore(@NotNull UUID player);

    /**
     * 这个人现在能不能进组队玩法 / 组队。读不到分数时返回 true（不因为数据库抖动拦人）。
     */
    boolean canJoinTeamGames(@NotNull UUID player);

    /**
     * 从数据库读，离线的人也查得到。没有记录的人按满分；模块没开时为空；读失败时 future 异常完成。
     */
    @NotNull CompletableFuture<Optional<Scores>> load(@NotNull UUID player);

    /** 模块没启用时的空实现。 */
    static @NotNull CreditService unavailable() {
        return new CreditService() {
            public boolean available() { return false; }
            public @NotNull OptionalInt credit(@NotNull UUID p) { return OptionalInt.empty(); }
            public @NotNull OptionalInt hiddenScore(@NotNull UUID p) { return OptionalInt.empty(); }
            public boolean canJoinTeamGames(@NotNull UUID p) { return true; }
            public @NotNull CompletableFuture<Optional<Scores>> load(@NotNull UUID p) {
                return CompletableFuture.completedFuture(Optional.empty());
            }
        };
    }
}
