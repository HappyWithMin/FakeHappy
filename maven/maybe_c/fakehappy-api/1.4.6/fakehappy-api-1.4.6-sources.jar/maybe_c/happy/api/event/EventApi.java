package maybe_c.happy.api.event;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.UUID;
import java.time.Duration;
import java.util.concurrent.CompletableFuture;
import java.util.function.Consumer;
import org.bukkit.command.CommandSender;
import org.bukkit.plugin.Plugin;

/** 活动快照、带全网租约的业务操作及纯抽奖算法；异步结果可能在 IO 线程完成。 */
public interface EventApi {
    boolean available();
    @Nullable Snapshot current();
    @NotNull List<Entry> roster();
    @NotNull List<String> guaranteedSignups();
    @NotNull EventLottery lottery();

    /** 当前抽奖控制权；空串表示 FakeHappy 内置流程。 */
    @NotNull String takeoverOwner();

    /** 外部插件声明接管。已有其他插件接管时返回 false。 */
    boolean claimTakeover(@NotNull String owner);

    /** 释放自己声明的接管权。 */
    boolean releaseTakeover(@NotNull String owner);

    /** 期限为 5–300 秒。插件启用期间自动续约；停用或模块重建后必须重新获取。 */
    default CompletableFuture<ControlLease> claimTakeover(Plugin owner, Duration ttl) { return CompletableFuture.completedFuture(null); }
    default CompletableFuture<Boolean> renewTakeover(ControlLease lease, Duration ttl) { return CompletableFuture.completedFuture(false); }
    default CompletableFuture<Boolean> releaseTakeover(ControlLease lease) { return CompletableFuture.completedFuture(false); }
    default CompletableFuture<ActionResult> open(ControlLease lease, RequestContext request, Settings settings) { return unsupported(request); }
    default CompletableFuture<ActionResult> update(ControlLease lease, RequestContext request, Snapshot expected, Settings settings) { return unsupported(request); }
    default CompletableFuture<ActionResult> end(ControlLease lease, RequestContext request, Snapshot expected) { return unsupported(request); }
    default CompletableFuture<ActionResult> signup(ControlLease lease, RequestContext request, Snapshot expected, PlayerTarget player) { return unsupported(request); }
    default CompletableFuture<ActionResult> withdraw(ControlLease lease, RequestContext request, Snapshot expected, PlayerTarget player) { return unsupported(request); }
    default CompletableFuture<ActionResult> replaceRoster(ControlLease lease, RequestContext request, Snapshot expected, List<RosterEntry> roster) { return unsupported(request); }
    default CompletableFuture<ActionResult> submitDraw(ControlLease lease, RequestContext request, Snapshot expected, DrawSubmission draw) { return unsupported(request); }
    default CompletableFuture<List<CandidateView>> candidates(Snapshot expected) { return CompletableFuture.completedFuture(List.of()); }
    default CompletableFuture<List<RosterEntry>> rosterWithIds(Snapshot expected) { return CompletableFuture.completedFuture(List.of()); }
    default CompletableFuture<TransferReceipt> transfer(ControlLease lease, RequestContext request, String eventId, String target, List<PlayerTarget> players) {
        return CompletableFuture.completedFuture(new TransferReceipt(request.requestId(), eventId, target, TransferStatus.FAILED, List.of()));
    }
    default Subscription subscribe(Plugin owner, Consumer<LifecycleEvent> listener) { return () -> { }; }
    default CompletableFuture<TransferReceipt> transferReceipt(String requestId) { return CompletableFuture.completedFuture(null); }

    private static CompletableFuture<ActionResult> unsupported(RequestContext request) {
        return CompletableFuture.completedFuture(new ActionResult(request.requestId(), ActionStatus.UNAVAILABLE, "活动服务不可用", null));
    }

    /** token 仅作为服务端能力使用；expiresAt 为获取时快照，续约后的有效期以服务端为准。 */
    record ControlLease(String owner, String node, String token, long generation, long expiresAt) { }
    /** actor 必须是真实在线玩家或服务器控制台；管理操作要求活动管理权限，报名可由本人发起。 */
    record RequestContext(String requestId, CommandSender actor) {
        public RequestContext {
            if (requestId == null || !requestId.matches("[A-Za-z0-9._:-]{8,64}")) throw new IllegalArgumentException("requestId 格式无效");
            java.util.Objects.requireNonNull(actor, "actor");
        }
    }
    /** null 字段使用开场默认值，或在更新时保留原值。 */
    record Settings(String name, Integer slots, String target, Long drawAt, Boolean certified,
                    Integer contributionPercent, String description) { }
    record PlayerTarget(UUID id, String name) {
        public PlayerTarget { java.util.Objects.requireNonNull(id); java.util.Objects.requireNonNull(name); }
    }
    /** 历史名称无法解析时 id 为 null；写入和传送须提供已确认 UUID。 */
    record RosterEntry(@Nullable UUID id, String name, boolean fixed) { }
    record CandidateView(UUID id, String name, boolean online, boolean eligible, String exclusion,
                         int contributionLevel, long weight, boolean guaranteed) { }
    /** 提交完整且合格的候选池；服务端复核报名、排除、认证、权重、轮次和名额后持久化原决定。 */
    record DrawSubmission(List<EventLottery.Candidate> candidates, EventLottery.Result result, boolean firstDraw) {
        public DrawSubmission { candidates = List.copyOf(candidates); java.util.Objects.requireNonNull(result); }
    }
    /** PENDING 表示结果待确认；重用相同请求号查询，不能更换请求号重抽。 */
    enum ActionStatus { SUCCEEDED, REJECTED, CONFLICT, FENCED, UNAVAILABLE, PENDING }
    record ActionResult(String requestId, ActionStatus status, String message, Snapshot event) {
        public boolean succeeded() { return status == ActionStatus.SUCCEEDED; }
    }
    enum TransferStatus { QUEUED, CONNECTING, SUCCEEDED, PARTIAL, FAILED, TIMED_OUT, CANCELLED }
    record TransferPlayerResult(UUID id, String name, TransferStatus status, int attempts, String message) { }
    record TransferReceipt(String requestId, String eventId, String target, TransferStatus status,
                           List<TransferPlayerResult> players) {
        public TransferReceipt { players = List.copyOf(players); }
    }
    record LifecycleEvent(String type, Snapshot previous, Snapshot current, String requestId) { }
    interface Subscription extends AutoCloseable { @Override void close(); }

    record Snapshot(@NotNull String id, @NotNull String name, @NotNull String phase,
                    int slots, @NotNull String target, long drawAt, boolean certified, String revision) {
        public Snapshot(String id, String name, String phase, int slots, String target, long drawAt, boolean certified) {
            this(id, name, phase, slots, target, drawAt, certified, null);
        }
    }
    record Entry(@NotNull String name, boolean fixed) { }

    static @NotNull EventApi unavailable() {
        return new EventApi() {
            public boolean available() { return false; }
            public @Nullable Snapshot current() { return null; }
            public @NotNull List<Entry> roster() { return List.of(); }
            public @NotNull List<String> guaranteedSignups() { return List.of(); }
            public @NotNull EventLottery lottery() { return EventLottery.INSTANCE; }
            public @NotNull String takeoverOwner() { return ""; }
            public boolean claimTakeover(@NotNull String owner) { return false; }
            public boolean releaseTakeover(@NotNull String owner) { return false; }
        };
    }
}
