package maybe_c.happy.api.reward;

/**
 * 奖励资产类型。显示名称由 {@link RewardService} 的配置提供。
 */
public enum RewardKind {

    /**
     * 货币。走本服的经济系统，各服都有自己的货币
    
     * 所以这一项天然跨服通用。
     */
    CURRENCY,

    /**
     * 等级经验。小游戏按规范 11.2 的公式算出来往这里发。
     *
     * <p><b>不是原版经验球</b>。原版经验（{@code Player#giveExp}）归小游戏自己
     * 玩法用，两者互不影响。
     */
    EXP,

    /**
     * 积分。这一项<b>通常不由小游戏发放</b> —— 它对应的是这类
     * 由管理员或外部系统授予的东西。留在这里是为了活动这类
     * 官方活动能一次性把三样发全。
     */
    POINTS
}
