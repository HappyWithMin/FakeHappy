package maybe_c.happy.api.economy;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.math.BigDecimal;

/**
 * 一笔资金变动的回执。调用方应等待回执并检查 {@link #ok()}，再交付商品。
 * @param status 结果类型
 * @param applied 实际变动，正数入账、负数扣款；失败为 0
 * @param balance 本次操作后的余额；后端不可用时为 0，表示未取得余额
 * @param message 失败原因；成功时为 null
 */
public record TxnResult(@NotNull Status status,
                        @NotNull BigDecimal applied,
                        @NotNull BigDecimal balance,
                        @Nullable String message) {

    public enum Status {
        /** 成功。 */
        SUCCESS,
        /** 余额不够。<b>钱一分没动</b> —— 不存在「扣了一部分」这种中间状态。 */
        INSUFFICIENT,
        /** 金额非法（零、负数、或者精度化之后变成零）。 */
        BAD_AMOUNT,
        /** 后端不可用（数据库没连上）。<b>和「余额不足」必须分开</b>： */
        UNAVAILABLE
    }

    public boolean ok() {
        return status == Status.SUCCESS;
    }

    public static @NotNull TxnResult success(@NotNull BigDecimal applied, @NotNull BigDecimal balance) {
        return new TxnResult(Status.SUCCESS, applied, balance, null);
    }

    public static @NotNull TxnResult insufficient(@NotNull BigDecimal balance) {
        return new TxnResult(Status.INSUFFICIENT, BigDecimal.ZERO, balance, "余额不足");
    }

    public static @NotNull TxnResult badAmount(@NotNull BigDecimal balance) {
        return new TxnResult(Status.BAD_AMOUNT, BigDecimal.ZERO, balance, "金额必须大于 0");
    }

    public static @NotNull TxnResult unavailable() {
        return new TxnResult(Status.UNAVAILABLE, BigDecimal.ZERO, BigDecimal.ZERO, "经济后端不可用");
    }
}
