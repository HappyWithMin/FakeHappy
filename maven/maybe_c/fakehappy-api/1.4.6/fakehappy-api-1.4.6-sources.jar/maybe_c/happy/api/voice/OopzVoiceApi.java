package maybe_c.happy.api.voice;

import org.bukkit.Bukkit;
import org.jetbrains.annotations.NotNull;

import java.util.Optional;
import java.util.Set;
import java.util.UUID;

/**
 * 自定义语音分组接口，通过 Bukkit {@code ServicesManager} 获取（或直接 {@link #find()}）。
 * <p>定时全量提交每个分组的成员；同一 key 更新成员，不重复创建频道。
 * 已托管成员不参与自动分房。散场调用 {@link #releaseGroup}。
 * <p>拓展未安装时注册项为 null，未连接或未配置可用频道时 {@link #available()} 为 false。
 * 调用方应允许游戏在语音服务不可用时继续运行。
 */
public interface OopzVoiceApi {

    /**
     * 拿拓展注册的实例。没装语音拓展时是空的。
     *
     * <p>等价于 {@code getServicesManager().load(OopzVoiceApi.class)}。别长期缓存「没装」这个结论 ——
     * 拓展可能比你的插件晚加载，在 onEnable 里拿不到不代表之后也拿不到。
     */
    static @NotNull Optional<OopzVoiceApi> find() {
        return Optional.ofNullable(Bukkit.getServicesManager().load(OopzVoiceApi.class));
    }

    /**
     * 现在提交分组有没有意义。
     *
     * <p>false 的原因可能是：语音平台还没连上 / 拓展没配好 / 没有可用的语音频道。这时候提交是安全的空操作。
     */
    boolean available();

    /**
     * 托管一个分组：<b>这一拍</b>这些人该在同一个语音频道里。
     *
     * <p>同一个 key 反复调只更新成员，不会重复建频道。成员里不在线的人会被忽略；
     * 没绑定语音账号的人拖不动（接口只能拖「已经在语音里的人」），
     * 拓展会隔一分钟提示他一次。
     *
     * <p>可以从任意线程调。
     *
     * @param key     稳定的分组标识，建议 {@code "<插件>:<房间>:<队伍>"}。
     *                拓展内部会再加一层前缀，所以不会和自动分房的分组撞车
     * @param label   频道显示名，<b>原样</b>用（不套配置里的 {@code name-format}）
     * @param members 这一拍该在这个频道里的人
     */
    void submitGroup(@NotNull String key, @NotNull String label, @NotNull Set<UUID> members);

    /**
     * 解散一个分组：频道还回池子，里面的人送回大厅频道。
     *
     * <p>忘了调也不会永远漏 —— 一个分组里的人全下线超过 5 分钟后会被自动收掉。
     * 但那是兜底，不是可以不调的理由：散场到超时之间那几分钟，频道一直占着。
     *
     * @return 本来就没有这个分组时返回 false
     */
    boolean releaseGroup(@NotNull String key);

    /**
     * 这个人绑没绑语音账号。
     *
     * <p>没绑的人分组分不动 —— 拿他做「语音里怎么怎么样」的判断之前先问这个。
     * 「没绑」和「还没读到」这里分不出来，都是 false；要分清楚用 {@link #voiceState}。
     */
    boolean isBound(@NotNull UUID playerId);

    /**
     * 这个人此刻在不在语音里、在哪个频道。只读，<b>不发请求、不阻塞，任意线程都能调</b>。
     *
     * <h2>数据从哪来</h2>
     * 拓展定时向语音平台查「每个语音频道有谁」，结果缓存在内存里：
     * 本服有局在分语音时每 2 秒一次，平时每 15 秒一次（本服没人绑语音账号时不查）。
     * 所以结果最多落后十几秒；{@link VoiceState#checkedAt()} 是查到的时间。
     *
     * <h2>什么时候是 UNKNOWN</h2>
     * <ul>
     *   <li>拓展没连上语音平台，或没配好；</li>
     *   <li>超过 45 秒没查到新数据（语音平台接口出错、刚重启）；</li>
     *   <li>这个人的绑定还没读到 —— 刚进服那一小会儿，或者他<b>不在这台子服</b>、
     *       本服也没读过他的绑定。别的子服的玩家要在他所在的那台子服上问。</li>
     * </ul>
     * 拿到 UNKNOWN 就当「不知道」，别当成「不在语音里」。
     *
     * <p>老版本拓展没有这个功能，一律返回 {@link VoiceState#UNKNOWN}。
     */
    default @NotNull VoiceState voiceState(@NotNull UUID playerId) {
        return VoiceState.UNKNOWN;
    }

    /**
     * {@code voiceState(playerId).inVoice()} 的简写：确定在语音里才是 true，
     * 不在和说不准都是 false。
     */
    default boolean isInVoice(@NotNull UUID playerId) {
        return voiceState(playerId).inVoice();
    }
}
