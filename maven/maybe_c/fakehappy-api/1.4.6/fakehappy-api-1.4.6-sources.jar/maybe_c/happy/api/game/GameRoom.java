package maybe_c.happy.api.game;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/**
 * 小游戏在一个子服上的房间快照，用于跨服上报与分配。多局游戏应为每局提供独立 ID、状态、人数和容量。
 */
public record GameRoom(
        @NotNull String roomId,
        @NotNull RoomType type,
        @NotNull GameState state,
        int players,
        int maxPlayers,
        int minPlayers,
        @Nullable String mapName
) {

    /** 规范 6.4 要求的房间名长度上限。 */
    public static final int MAX_ROOM_ID_LENGTH = 16;

    public GameRoom {
        if (roomId.isBlank()) {
            throw new IllegalArgumentException("房间 ID 不能为空");
        }
    }

    /**
     * 普通房间的简写 —— 单局制、没有地图概念的游戏用这个。
     */
    public static @NotNull GameRoom normal(@NotNull String roomId, @NotNull GameState state,
                                           int players, int maxPlayers, int minPlayers) {
        return new GameRoom(roomId, RoomType.NORMAL, state, players, maxPlayers, minPlayers, null);
    }

    /** 看起来还能进人吗。跨服分配的最终判定不在这里，见 NetworkService 的预约位机制。 */
    public boolean joinable() {
        return state.joinable() && players < maxPlayers;
    }

    public int freeSlots() {
        return Math.max(0, maxPlayers - players);
    }

    /**
     * 这一局结束时该不该发货币和经验（规范 6.2 / 11.4）。
     *
     * <p>结算前查这个，<b>别自己按房间名判断</b>。
     */
    public boolean grantsRewards() {
        return type.grantsRewards();
    }

    /** roomId 是否符合规范 6.4 的长度要求。合规检查用。 */
    public boolean roomIdWithinLimit() {
        return roomId.length() <= MAX_ROOM_ID_LENGTH;
    }
}
