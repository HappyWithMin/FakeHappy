package maybe_c.happy.api.spec;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

/**
 * 小游戏的规范声明。自动检查无法确认的实现由调用方逐项声明；未声明的项不视为已完成。声明结果不能代替运行验收。
 */
public final class GameCompliance {

    private static final GameCompliance EMPTY = builder().build();

    private final Set<String> done;
    private final Map<String, String> notApplicable;

    private GameCompliance(Builder b) {
        this.done = Set.copyOf(b.done);
        this.notApplicable = Map.copyOf(b.notApplicable);
    }

    /** 什么都没声明。{@code MiniGame.compliance()} 的默认返回值。 */
    public static @NotNull GameCompliance none() {
        return EMPTY;
    }

    public static @NotNull Builder builder() {
        return new Builder();
    }

    /** 开发者声明「这条我做了」。 */
    public boolean isDone(@NotNull String itemId) {
        return done.contains(itemId);
    }

    /** 开发者声明「这条对我不适用」，返回理由；没声明则返回 null。 */
    public @Nullable String notApplicableReason(@NotNull String itemId) {
        return notApplicable.get(itemId);
    }

    public boolean isNotApplicable(@NotNull String itemId) {
        return notApplicable.containsKey(itemId);
    }

    public @NotNull Set<String> declaredDone() {
        return done;
    }

    public @NotNull Map<String, String> declaredNotApplicable() {
        return notApplicable;
    }

    public static final class Builder {
        private final java.util.Set<String> done = new java.util.LinkedHashSet<>();
        private final Map<String, String> notApplicable = new LinkedHashMap<>();

        /**
         * 声明这些检查项已实现。ID 见 {@link SpecCatalog}。
         *
         * <p>写错的 ID 会在合规报告里被单独列出来提醒 —— 不会静默忽略，
         * 否则一个手滑的拼写会让人以为自己声明过了。
         */
        public @NotNull Builder done(@NotNull String... itemIds) {
            java.util.Collections.addAll(done, itemIds);
            return this;
        }

        /**
         * 声明这条对本游戏不适用，<b>必须给理由</b>。
         *
         * <p>「必须」项也可以声明（标正式时不再拦），但理由会标成「必须项、开发者声明不适用」
         * 出现在合规报告和管理面板里给服主看，所以要写真实理由。以前的说明：
         * 报告里仍然算缺失，因为那是全服统一的硬要求，个别游戏说不适用不作数。
         *
         * @param reason 一句话说清为什么。会原样出现在合规报告里给验收的人看
         */
        public @NotNull Builder notApplicable(@NotNull String itemId, @NotNull String reason) {
            notApplicable.put(itemId, reason);
            return this;
        }

        public @NotNull GameCompliance build() {
            return new GameCompliance(this);
        }
    }
}
