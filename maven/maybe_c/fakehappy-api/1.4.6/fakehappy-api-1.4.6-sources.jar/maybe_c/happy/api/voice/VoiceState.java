package maybe_c.happy.api.voice;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Objects;

/**
 * 一个玩家此刻的语音状态，{@link OopzVoiceApi#voiceState} 返回的只读快照。
 *
 * <p>先看 {@link #status()}：
 * <ul>
 *   <li>{@link Status#UNKNOWN} —— 现在说不准（拓展没连上、还没查过、数据太旧、
 *       这个人的绑定还没读到）。<b>别把它当成「不在语音里」</b>，按「不知道」处理。</li>
 *   <li>{@link Status#NOT_BOUND} —— 确定没绑语音账号。</li>
 *   <li>{@link Status#NOT_IN_VOICE} —— 绑了，但此刻不在任何语音频道里。</li>
 *   <li>{@link Status#IN_VOICE} —— 在某个语音频道里，频道名见 {@link #channelName()}。</li>
 * </ul>
 *
 * @param status            见上
 * @param channelName       所在语音频道的名字；只有 {@code IN_VOICE} 时非 null。名字查不到时是频道 ID
 * @param groupKey          他所在的频道正是你用 {@link OopzVoiceApi#submitGroup} 交的某个分组时，
 *                          那个分组的 key（就是你传进去的那个）；其它情况 null
 * @param inAssignedChannel 他在拓展这一局给他安排的频道里（自动分房的队伍频道，或你交的分组频道）
 * @param checkedAt         这份数据是什么时候从语音平台查到的（毫秒时间戳）；UNKNOWN 时为 0
 */
public record VoiceState(@NotNull Status status,
                         @Nullable String channelName,
                         @Nullable String groupKey,
                         boolean inAssignedChannel,
                         long checkedAt) {

    /** 四种情况，见类注释。 */
    public enum Status {
        UNKNOWN,
        NOT_BOUND,
        NOT_IN_VOICE,
        IN_VOICE
    }

    /** 说不准。 */
    public static final VoiceState UNKNOWN = new VoiceState(Status.UNKNOWN, null, null, false, 0L);

    public VoiceState {
        Objects.requireNonNull(status, "status");
        if (status != Status.IN_VOICE) {
            channelName = null;
            groupKey = null;
            inAssignedChannel = false;
        }
        if (status == Status.UNKNOWN) {
            checkedAt = 0L;
        }
    }

    public static @NotNull VoiceState notBound(long checkedAt) {
        return new VoiceState(Status.NOT_BOUND, null, null, false, checkedAt);
    }

    public static @NotNull VoiceState notInVoice(long checkedAt) {
        return new VoiceState(Status.NOT_IN_VOICE, null, null, false, checkedAt);
    }

    public static @NotNull VoiceState inVoice(@NotNull String channelName, @Nullable String groupKey,
                                              boolean inAssignedChannel, long checkedAt) {
        return new VoiceState(Status.IN_VOICE, channelName, groupKey, inAssignedChannel, checkedAt);
    }

    /** 不是 UNKNOWN。 */
    public boolean known() {
        return status != Status.UNKNOWN;
    }

    /** 确定绑了语音账号（UNKNOWN 时返回 false，要区分请先看 {@link #known()}）。 */
    public boolean bound() {
        return status == Status.NOT_IN_VOICE || status == Status.IN_VOICE;
    }

    /** 确定在语音里。 */
    public boolean inVoice() {
        return status == Status.IN_VOICE;
    }
}
