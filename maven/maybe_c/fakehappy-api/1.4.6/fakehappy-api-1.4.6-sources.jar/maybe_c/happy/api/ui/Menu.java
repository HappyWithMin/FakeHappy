package maybe_c.happy.api.ui;

import net.kyori.adventure.text.Component;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

import java.util.Set;
import java.util.UUID;

/**
 * 复用菜单的生命周期和显示接口。
 * <p>菜单可保存观看者 UUID，内容按需求值；回调避免长期捕获 Player、实体或世界。
 * 模块与插件卸载时框架回收菜单，手动 dispose 后不可继续使用。
 */
public interface Menu {

    /** 菜单标题。 */
    @NotNull Component title();

    /**
     * 给玩家打开，<b>立即生效</b>。会把该玩家已打开的本框架菜单压进导航栈。
     *
     * <p>用于<b>玩家主动触发</b>的场景：点了按钮、敲了命令。这种时候顶掉他当前的
     * 界面正是他要的结果，不该推迟。
     *
     * <p>玩家主动弹窗（进服提示、活动通知、传送确认）请改用 {@link #openWhenFree}。
     */
    void open(@NotNull Player player);

    /**
     * 给玩家打开，但<b>等他手头的界面关掉之后</b>再开。
     *
     * <p>用于<b>服务端主动</b>弹给玩家的东西。玩家可能正在填资源包确认框、
     * 正在看别的插件的 GUI —— 这时候硬塞一个菜单过去会把对方的操作打断，
     * 资源包确认框被顶掉更是会直接导致他进不了服。
     *
     * <p>等待有上限（约 2 分钟），超时后仍会打开，不会永久卡着不弹。
     */
    void openWhenFree(@NotNull Player player);

    /** 关掉指定玩家的这个菜单。他没在看就什么也不做。 */
    void close(@NotNull Player player);

    /** 关掉所有观看者。 */
    void closeAll();

    /**
     * 用最新数据重绘所有观看者的界面。
     *
     * <p>箱子界面是原地改 ItemStack，不会关窗口，所以不会闪、不会打断拖拽。
     * Dialog 会重新 show 一次（客户端表现为内容更新）。
     *
     * <p>可以安全地放进定时任务里每秒调一次；没有观看者时不重绘。
     */
    void refresh();

    /**
     * 只重绘指定观看者。异步查询结果应使用此方法，避免重置其他人的表单输入。
     * <p>玩家不在看这个菜单时什么都不做。
     */
    void refreshFor(@NotNull Player player);

    /**
     * 更新无输入页面的正文，保留当前按钮与点击身份。
     * Dialog 表单跳过此更新，避免丢失客户端尚未提交的输入；操作变化时使用完整刷新。
     * 旧实现默认不更新。
     */
    default void refreshBodyFor(@NotNull Player player) { }

    boolean isViewing(@NotNull Player player);

    /** 当前观看者的 UUID 快照。 */
    @NotNull Set<UUID> viewers();

    /**
     * 主动作废这个菜单：关掉所有观看者并解绑框架内部的注册。
     *
     * <p>一次性菜单（比如某局游戏的结算界面）在用完后调一下，
     * 免得它一直挂在框架的活动菜单表里。模块关闭时框架会自动 dispose
     * 该模块创建的所有菜单，所以常规情况下不用手动调。
     */
    void dispose();

    /** 是否已 {@link #dispose()}。已作废的菜单再 open 会被忽略并记一条 warning。 */
    boolean isDisposed();
}
