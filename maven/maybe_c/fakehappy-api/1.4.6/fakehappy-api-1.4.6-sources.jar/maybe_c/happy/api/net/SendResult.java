package maybe_c.happy.api.net;

import org.jetbrains.annotations.NotNull;

import java.util.List;
import java.util.UUID;

/**
 * {@link NetworkService#send} 的结果：每个人送没送到、为什么。
 *
 * @param target          目标子服 ID
 * @param entries         每个请求的人一条，顺序同传入
 * @param proxiesAnswered 回了结果的代理数
 * @param proxiesExpected 当时在线的代理数；answered &lt; expected 时，挂在没回应的代理上的人会是 {@link Status#NOT_FOUND}
 * @param message         给人看的一句话（成功几个 / 为什么整体没执行）
 */
public record SendResult(@NotNull String target, @NotNull List<Entry> entries, int proxiesAnswered,
                         int proxiesExpected, @NotNull String message) {

    public SendResult {
        entries = List.copyOf(entries);
    }

    public enum Status {
        /** 已经连到目标子服。 */
        MOVED,
        /** 本来就在目标子服。 */
        ALREADY,
        /** 找到了但没送过去：满人、被准入锁拦下、正在切服、目标子服拒绝等，见 {@link Entry#message()}。 */
        FAILED,
        /** 哪台代理都没找到他（不在线），或者他所在的代理没回应。 */
        NOT_FOUND
    }

    /** @param name 代理那边看到的名字；没找到时是 UUID 字符串 */
    public record Entry(@NotNull UUID id, @NotNull String name, @NotNull Status status, @NotNull String message) { }

    /** 每个人都到了目标子服（含本来就在的）。 */
    public boolean allArrived() {
        return !entries.isEmpty() && entries.stream().allMatch(e -> e.status() == Status.MOVED || e.status() == Status.ALREADY);
    }

    public static @NotNull SendResult unavailable(@NotNull String target, @NotNull List<UUID> players, @NotNull String why) {
        return new SendResult(target, players.stream().map(id -> new Entry(id, id.toString(), Status.NOT_FOUND, why)).toList(),
                0, 0, why);
    }
}
