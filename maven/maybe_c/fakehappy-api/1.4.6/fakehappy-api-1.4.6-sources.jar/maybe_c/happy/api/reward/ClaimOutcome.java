package maybe_c.happy.api.reward;

import org.jetbrains.annotations.NotNull;

/**
 * 领取结果。区分成功、已领取、条件不足、档案不可用与派发失败，供调用方处理重试和反馈。
 */
public enum ClaimOutcome {

    /** 记账 + 落盘 + 至少一项真的发出去了。 */
    OK("已领取"),

    /** 界面快照过期了 —— 多半是自动领取抢在前面，或者他在另一台子服刚领过。 */
    ALREADY_CLAIMED("这一档你已经领过了"),

    /** 等级在界面打开之后被别处改低了。 */
    LEVEL_TOO_LOW("你的等级还不够"),

    /** OP 刚把这一档从档位表里删了，界面上还留着旧格子。 */
    NOT_FOUND("这一档奖励已经不存在了（管理员刚改过），重开一次界面"),

    /** 内存里没有这个玩家的档案：还在异步载入，或者进服时查库失败。 */
    NO_PROFILE("你的档案还没载入完，或者数据库暂时读不到，过一会儿再试"),

    /** 命令和货币一条都没成功，领取记录已经退回来了。 */
    DELIVERY_FAILED("奖励没能发出去，领取记录已经退回，换个子服再试一次");

    private final String reason;

    ClaimOutcome(String reason) {
        this.reason = reason;
    }

    public boolean ok() {
        return this == OK;
    }

    /** 可以直接发给玩家看的中文人话。 */
    public @NotNull String reason() {
        return reason;
    }
}
