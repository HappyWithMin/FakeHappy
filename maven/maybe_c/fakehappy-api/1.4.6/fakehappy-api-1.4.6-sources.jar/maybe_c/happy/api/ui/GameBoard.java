package maybe_c.happy.api.ui;

import net.kyori.adventure.text.Component;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.function.Function;

/**
 * 小游戏侧边栏计分板。
 * <p>框架设置规范 9.1 要求的标题、底部地址和可选 Tab 底部；调用方提供按观看者求值的中间内容。
 * {@code GameDescriptor.scoreboardExempt(true)} 用于玩法占用计分板的例外。
 * <p>模块或插件卸载时，框架回收其创建的计分板。
 */
public interface GameBoard {

    /** 规范 9.2：单行文本不应超过的字符数。 */
    int MAX_LINE_LENGTH = 32;

    /** 规范 9.2：记分板总行数不宜超过的行数（含框架加的首尾）。 */
    int MAX_TOTAL_LINES = 15;

    /** 中间内容最多几行 —— 总行数减掉框架占的底部行。 */
    int MAX_MIDDLE_LINES = MAX_TOTAL_LINES - 1;


    /** 给这个玩家显示。同一个玩家重复调用是幂等的。 */
    void show(@NotNull Player player);

    /** 对这个玩家隐藏。 */
    void hide(@NotNull Player player);

    void hideAll();

    boolean isShownTo(@NotNull Player player);

    @NotNull Set<UUID> viewers();

    /**
     * 立刻用最新数据重绘所有观看者。
     *
     * <p>设了 {@code autoRefresh} 的话不用手动调。没有观看者时不重绘。
     */
    void refresh();

    /**
     * 作废。会对所有观看者隐藏并解绑框架内部登记。
     *
     * <p>模块 / 插件卸载时框架会自动 dispose 它创建的所有计分板，
     * 常规情况下不用手动调。
     */
    void dispose();

    boolean isDisposed();

    interface Builder {

        /**
         * 中间内容，每次重绘按观看者求值。
         *
         * <p><b>只给中间部分</b> —— 顶部的游戏名和底部的服务器地址
         * 由框架按规范加，你不用管也改不了。
         *
         * <p>返回的行数超过 {@link #MAX_MIDDLE_LINES}、或某行超过
         * {@link #MAX_LINE_LENGTH} 字符时，框架会<b>照常显示</b>但在控制台警告一次
         * （不是每 tick 刷屏）。规范 9.2 那两条是「应当」不是「必须」，
         * 所以不强行截断 —— 截断会让人看到半截字却不知道为什么。
         */
        @NotNull Builder lines(@NotNull Function<Player, List<Component>> perViewer);

        /** 内容不随观看者变时的简写。 */
        @NotNull Builder lines(@NotNull java.util.function.Supplier<List<Component>> supplier);

        /**
         * 自动重绘周期（tick）。<b>有人在看的时候才跑</b>，没有观看者时不重绘。
         *
         * <p>每秒变化的内容建议使用 20，避免无效重复发送。
         */
        @NotNull Builder autoRefresh(int periodTicks);

        /**
         * 要不要同时设置 Tab 底部的 {@code ==游戏名称==}（规范 9.1）。默认 true。
         *
         * <p>服务器装了接管 Tab 列表的插件时框架一律不写 Tab 头尾（写了会把它的头部清空），这个开关只在没装 TAB 的服上起作用。
         */
        @NotNull Builder tabFooter(boolean enabled);

        @NotNull GameBoard build();
    }
}
